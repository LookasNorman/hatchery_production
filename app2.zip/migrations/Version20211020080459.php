<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211020080459 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE chick_temperature (id INT AUTO_INCREMENT NOT NULL, input_id INT NOT NULL, hatcher_id INT NOT NULL, date DATE NOT NULL, temperature NUMERIC(4, 1) NOT NULL, INDEX IDX_152E2C8136421AD6 (input_id), INDEX IDX_152E2C8115A57138 (hatcher_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE chick_temperature ADD CONSTRAINT FK_152E2C8136421AD6 FOREIGN KEY (input_id) REFERENCES inputs (id)');
        $this->addSql('ALTER TABLE chick_temperature ADD CONSTRAINT FK_152E2C8115A57138 FOREIGN KEY (hatcher_id) REFERENCES hatchers (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE chick_temperature');
    }
}
