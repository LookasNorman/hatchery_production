<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211007065205 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD lighting_id INT NOT NULL');
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD CONSTRAINT FK_73F970919987DD4 FOREIGN KEY (lighting_id) REFERENCES lighting (id)');
        $this->addSql('CREATE INDEX IDX_73F970919987DD4 ON inputs_farm_delivery (lighting_id)');
        $this->addSql('ALTER TABLE lighting ADD lighting_eggs INT NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP FOREIGN KEY FK_73F970919987DD4');
        $this->addSql('DROP INDEX IDX_73F970919987DD4 ON inputs_farm_delivery');
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP lighting_id');
        $this->addSql('ALTER TABLE lighting DROP lighting_eggs');
    }
}
