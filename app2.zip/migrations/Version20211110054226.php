<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211110054226 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE input_delivery_lighting (input_delivery_id INT NOT NULL, lighting_id INT NOT NULL, INDEX IDX_3BD2851EE7D95564 (input_delivery_id), INDEX IDX_3BD2851E9987DD4 (lighting_id), PRIMARY KEY(input_delivery_id, lighting_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE input_delivery_transfers (input_delivery_id INT NOT NULL, transfers_id INT NOT NULL, INDEX IDX_B3D9FE6DE7D95564 (input_delivery_id), INDEX IDX_B3D9FE6DA14B7314 (transfers_id), PRIMARY KEY(input_delivery_id, transfers_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE input_delivery_selections (input_delivery_id INT NOT NULL, selections_id INT NOT NULL, INDEX IDX_23735B04E7D95564 (input_delivery_id), INDEX IDX_23735B04B94BCAD5 (selections_id), PRIMARY KEY(input_delivery_id, selections_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE input_delivery_lighting ADD CONSTRAINT FK_3BD2851EE7D95564 FOREIGN KEY (input_delivery_id) REFERENCES input_delivery (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE input_delivery_lighting ADD CONSTRAINT FK_3BD2851E9987DD4 FOREIGN KEY (lighting_id) REFERENCES lighting (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE input_delivery_transfers ADD CONSTRAINT FK_B3D9FE6DE7D95564 FOREIGN KEY (input_delivery_id) REFERENCES input_delivery (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE input_delivery_transfers ADD CONSTRAINT FK_B3D9FE6DA14B7314 FOREIGN KEY (transfers_id) REFERENCES transfers (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE input_delivery_selections ADD CONSTRAINT FK_23735B04E7D95564 FOREIGN KEY (input_delivery_id) REFERENCES input_delivery (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE input_delivery_selections ADD CONSTRAINT FK_23735B04B94BCAD5 FOREIGN KEY (selections_id) REFERENCES selections (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP FOREIGN KEY FK_73F970919987DD4');
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP FOREIGN KEY FK_73F97091A14B7314');
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP FOREIGN KEY FK_73F97091B94BCAD5');
        $this->addSql('DROP INDEX IDX_73F970919987DD4 ON inputs_farm_delivery');
        $this->addSql('DROP INDEX IDX_73F97091A14B7314 ON inputs_farm_delivery');
        $this->addSql('DROP INDEX IDX_73F97091B94BCAD5 ON inputs_farm_delivery');
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP lighting_id, DROP transfers_id, DROP selections_id');
        $this->addSql('ALTER TABLE user CHANGE roles roles JSON NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE input_delivery_lighting');
        $this->addSql('DROP TABLE input_delivery_transfers');
        $this->addSql('DROP TABLE input_delivery_selections');
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD lighting_id INT DEFAULT NULL, ADD transfers_id INT DEFAULT NULL, ADD selections_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD CONSTRAINT FK_73F970919987DD4 FOREIGN KEY (lighting_id) REFERENCES lighting (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD CONSTRAINT FK_73F97091A14B7314 FOREIGN KEY (transfers_id) REFERENCES transfers (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD CONSTRAINT FK_73F97091B94BCAD5 FOREIGN KEY (selections_id) REFERENCES selections (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_73F970919987DD4 ON inputs_farm_delivery (lighting_id)');
        $this->addSql('CREATE INDEX IDX_73F97091A14B7314 ON inputs_farm_delivery (transfers_id)');
        $this->addSql('CREATE INDEX IDX_73F97091B94BCAD5 ON inputs_farm_delivery (selections_id)');
        $this->addSql('ALTER TABLE `user` CHANGE roles roles LONGTEXT CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_bin`');
    }
}
