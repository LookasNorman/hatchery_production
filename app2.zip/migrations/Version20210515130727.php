<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210515130727 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE breed (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(20) NOT NULL, type VARCHAR(20) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE chicks_recipient (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(50) NOT NULL, email VARCHAR(50) DEFAULT NULL, phone_number VARCHAR(30) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE delivery (id INT AUTO_INCREMENT NOT NULL, herd_id INT NOT NULL, delivery_date DATE NOT NULL, eggs_number INT NOT NULL, first_laying_date DATE NOT NULL, last_laying_date DATE NOT NULL, eggs_on_warehouse INT DEFAULT NULL, part_index VARCHAR(6) DEFAULT NULL, INDEX IDX_3781EC10D35A8CCC (herd_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE egg_supplier (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(50) NOT NULL, email VARCHAR(50) DEFAULT NULL, phone_number VARCHAR(30) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE eggs_inputs (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(50) NOT NULL, input_date DATE NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE eggs_inputs_details (id INT AUTO_INCREMENT NOT NULL, egg_input_id INT NOT NULL, chicks_recipient_id INT DEFAULT NULL, chick_number INT NOT NULL, INDEX IDX_DE4221727F7B0ADD (egg_input_id), INDEX IDX_DE422172565687D0 (chicks_recipient_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE eggs_inputs_details_eggs_delivery (id INT AUTO_INCREMENT NOT NULL, eggs_input_details_id INT NOT NULL, eggs_deliveries_id INT NOT NULL, eggs_number INT NOT NULL, INDEX IDX_9073E5D27DDEB528 (eggs_input_details_id), INDEX IDX_9073E5D2623A171B (eggs_deliveries_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE eggs_inputs_lighting (id INT AUTO_INCREMENT NOT NULL, eggs_inputs_detail_id INT NOT NULL, waste_eggs INT NOT NULL, lighting_date DATE NOT NULL, INDEX IDX_78C20B77DF0E0DBC (eggs_inputs_detail_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE eggs_inputs_transfers (id INT AUTO_INCREMENT NOT NULL, eggs_inputs_detail_id INT NOT NULL, waste_eggs INT NOT NULL, transfer_date DATE NOT NULL, INDEX IDX_87F4371FDF0E0DBC (eggs_inputs_detail_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE eggs_selections (id INT AUTO_INCREMENT NOT NULL, eggs_inputs_detail_id INT NOT NULL, chick_number INT NOT NULL, cull_chicken INT NOT NULL, selection_date DATE NOT NULL, INDEX IDX_64CD3E80DF0E0DBC (eggs_inputs_detail_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE hatchers (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(20) NOT NULL, shortname VARCHAR(4) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE herds (id INT AUTO_INCREMENT NOT NULL, breeder_id INT NOT NULL, breed_id INT NOT NULL, name VARCHAR(20) NOT NULL, hatching_date DATE NOT NULL, INDEX IDX_FC70FEBB33C95BB1 (breeder_id), INDEX IDX_FC70FEBBA8B4A30F (breed_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE reset_password_request (id INT AUTO_INCREMENT NOT NULL, user_id INT NOT NULL, selector VARCHAR(20) NOT NULL, hashed_token VARCHAR(100) NOT NULL, requested_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', expires_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_7CE748AA76ED395 (user_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE setters (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(20) NOT NULL, shortname VARCHAR(4) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE delivery ADD CONSTRAINT FK_3781EC10D35A8CCC FOREIGN KEY (herd_id) REFERENCES herds (id)');
        $this->addSql('ALTER TABLE eggs_inputs_details ADD CONSTRAINT FK_DE4221727F7B0ADD FOREIGN KEY (egg_input_id) REFERENCES eggs_inputs (id)');
        $this->addSql('ALTER TABLE eggs_inputs_details ADD CONSTRAINT FK_DE422172565687D0 FOREIGN KEY (chicks_recipient_id) REFERENCES chicks_recipient (id)');
        $this->addSql('ALTER TABLE eggs_inputs_details_eggs_delivery ADD CONSTRAINT FK_9073E5D27DDEB528 FOREIGN KEY (eggs_input_details_id) REFERENCES eggs_inputs_details (id)');
        $this->addSql('ALTER TABLE eggs_inputs_details_eggs_delivery ADD CONSTRAINT FK_9073E5D2623A171B FOREIGN KEY (eggs_deliveries_id) REFERENCES delivery (id)');
        $this->addSql('ALTER TABLE eggs_inputs_lighting ADD CONSTRAINT FK_78C20B77DF0E0DBC FOREIGN KEY (eggs_inputs_detail_id) REFERENCES eggs_inputs_details (id)');
        $this->addSql('ALTER TABLE eggs_inputs_transfers ADD CONSTRAINT FK_87F4371FDF0E0DBC FOREIGN KEY (eggs_inputs_detail_id) REFERENCES eggs_inputs_details (id)');
        $this->addSql('ALTER TABLE eggs_selections ADD CONSTRAINT FK_64CD3E80DF0E0DBC FOREIGN KEY (eggs_inputs_detail_id) REFERENCES eggs_inputs_details (id)');
        $this->addSql('ALTER TABLE herds ADD CONSTRAINT FK_FC70FEBB33C95BB1 FOREIGN KEY (breeder_id) REFERENCES egg_supplier (id)');
        $this->addSql('ALTER TABLE herds ADD CONSTRAINT FK_FC70FEBBA8B4A30F FOREIGN KEY (breed_id) REFERENCES breed (id)');
        $this->addSql('ALTER TABLE reset_password_request ADD CONSTRAINT FK_7CE748AA76ED395 FOREIGN KEY (user_id) REFERENCES `user` (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE herds DROP FOREIGN KEY FK_FC70FEBBA8B4A30F');
        $this->addSql('ALTER TABLE eggs_inputs_details DROP FOREIGN KEY FK_DE422172565687D0');
        $this->addSql('ALTER TABLE eggs_inputs_details_eggs_delivery DROP FOREIGN KEY FK_9073E5D2623A171B');
        $this->addSql('ALTER TABLE herds DROP FOREIGN KEY FK_FC70FEBB33C95BB1');
        $this->addSql('ALTER TABLE eggs_inputs_details DROP FOREIGN KEY FK_DE4221727F7B0ADD');
        $this->addSql('ALTER TABLE eggs_inputs_details_eggs_delivery DROP FOREIGN KEY FK_9073E5D27DDEB528');
        $this->addSql('ALTER TABLE eggs_inputs_lighting DROP FOREIGN KEY FK_78C20B77DF0E0DBC');
        $this->addSql('ALTER TABLE eggs_inputs_transfers DROP FOREIGN KEY FK_87F4371FDF0E0DBC');
        $this->addSql('ALTER TABLE eggs_selections DROP FOREIGN KEY FK_64CD3E80DF0E0DBC');
        $this->addSql('ALTER TABLE delivery DROP FOREIGN KEY FK_3781EC10D35A8CCC');
        $this->addSql('DROP TABLE breed');
        $this->addSql('DROP TABLE chicks_recipient');
        $this->addSql('DROP TABLE delivery');
        $this->addSql('DROP TABLE egg_supplier');
        $this->addSql('DROP TABLE eggs_inputs');
        $this->addSql('DROP TABLE eggs_inputs_details');
        $this->addSql('DROP TABLE eggs_inputs_details_eggs_delivery');
        $this->addSql('DROP TABLE eggs_inputs_lighting');
        $this->addSql('DROP TABLE eggs_inputs_transfers');
        $this->addSql('DROP TABLE eggs_selections');
        $this->addSql('DROP TABLE hatchers');
        $this->addSql('DROP TABLE herds');
        $this->addSql('DROP TABLE reset_password_request');
        $this->addSql('DROP TABLE setters');
    }
}
