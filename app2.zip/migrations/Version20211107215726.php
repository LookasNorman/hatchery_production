<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211107215726 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE plan_input_herds');
        $this->addSql('ALTER TABLE plan_input ADD herd_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE plan_input ADD CONSTRAINT FK_8B8E772BD35A8CCC FOREIGN KEY (herd_id) REFERENCES herds (id)');
        $this->addSql('CREATE INDEX IDX_8B8E772BD35A8CCC ON plan_input (herd_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE plan_input_herds (plan_input_id INT NOT NULL, herds_id INT NOT NULL, INDEX IDX_B037EE6438272DAC (plan_input_id), INDEX IDX_B037EE6475706932 (herds_id), PRIMARY KEY(plan_input_id, herds_id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE plan_input_herds ADD CONSTRAINT FK_B037EE6438272DAC FOREIGN KEY (plan_input_id) REFERENCES plan_input (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE plan_input_herds ADD CONSTRAINT FK_B037EE6475706932 FOREIGN KEY (herds_id) REFERENCES herds (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE plan_input DROP FOREIGN KEY FK_8B8E772BD35A8CCC');
        $this->addSql('DROP INDEX IDX_8B8E772BD35A8CCC ON plan_input');
        $this->addSql('ALTER TABLE plan_input DROP herd_id');
    }
}
