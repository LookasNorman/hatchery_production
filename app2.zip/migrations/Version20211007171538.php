<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211007171538 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE plan_input (id INT AUTO_INCREMENT NOT NULL, input_date DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE plan_input_farm (id INT AUTO_INCREMENT NOT NULL, egg_input_id INT NOT NULL, chicks_farm_id INT NOT NULL, chick_number INT NOT NULL, INDEX IDX_761651647F7B0ADD (egg_input_id), INDEX IDX_761651649D85B828 (chicks_farm_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE plan_input_farm ADD CONSTRAINT FK_761651647F7B0ADD FOREIGN KEY (egg_input_id) REFERENCES plan_input (id)');
        $this->addSql('ALTER TABLE plan_input_farm ADD CONSTRAINT FK_761651649D85B828 FOREIGN KEY (chicks_farm_id) REFERENCES chicks_recipient (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE plan_input_farm DROP FOREIGN KEY FK_761651647F7B0ADD');
        $this->addSql('DROP TABLE plan_input');
        $this->addSql('DROP TABLE plan_input_farm');
    }
}
