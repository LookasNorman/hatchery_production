<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211027111834 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE vaccination (id INT AUTO_INCREMENT NOT NULL, farm_id INT NOT NULL, herd_id INT NOT NULL, eggs_number INT NOT NULL, INDEX IDX_1B09999965FCFA0D (farm_id), INDEX IDX_1B099999D35A8CCC (herd_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE vaccination ADD CONSTRAINT FK_1B09999965FCFA0D FOREIGN KEY (farm_id) REFERENCES chicks_recipient (id)');
        $this->addSql('ALTER TABLE vaccination ADD CONSTRAINT FK_1B099999D35A8CCC FOREIGN KEY (herd_id) REFERENCES herds (id)');
        $this->addSql('ALTER TABLE user CHANGE roles roles JSON NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE vaccination');
        $this->addSql('ALTER TABLE `user` CHANGE roles roles LONGTEXT CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_bin`');
    }
}
