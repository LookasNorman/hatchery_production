<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211111200003 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE transfers ADD farm_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE transfers ADD CONSTRAINT FK_802A391865FCFA0D FOREIGN KEY (farm_id) REFERENCES inputs_farm (id)');
        $this->addSql('CREATE INDEX IDX_802A391865FCFA0D ON transfers (farm_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE transfers DROP FOREIGN KEY FK_802A391865FCFA0D');
        $this->addSql('DROP INDEX IDX_802A391865FCFA0D ON transfers');
        $this->addSql('ALTER TABLE transfers DROP farm_id');
    }
}
