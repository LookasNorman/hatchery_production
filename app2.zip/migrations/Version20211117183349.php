<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211117183349 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE customer_phone (id INT AUTO_INCREMENT NOT NULL, customer_id INT NOT NULL, phone_number VARCHAR(20) NOT NULL, person VARCHAR(70) DEFAULT NULL, job_position VARCHAR(30) DEFAULT NULL, description LONGTEXT DEFAULT NULL, INDEX IDX_8A7AE2E69395C3F3 (customer_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE customer_phone_audit (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type VARCHAR(10) NOT NULL, object_id VARCHAR(255) NOT NULL, discriminator VARCHAR(255) DEFAULT NULL, transaction_hash VARCHAR(40) DEFAULT NULL, diffs LONGTEXT DEFAULT NULL, blame_id VARCHAR(255) DEFAULT NULL, blame_user VARCHAR(255) DEFAULT NULL, blame_user_fqdn VARCHAR(255) DEFAULT NULL, blame_user_firewall VARCHAR(100) DEFAULT NULL, ip VARCHAR(45) DEFAULT NULL, created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX type_b355ba48cddd8fb6ee840a212aa8ba40_idx (type), INDEX object_id_b355ba48cddd8fb6ee840a212aa8ba40_idx (object_id), INDEX discriminator_b355ba48cddd8fb6ee840a212aa8ba40_idx (discriminator), INDEX transaction_hash_b355ba48cddd8fb6ee840a212aa8ba40_idx (transaction_hash), INDEX blame_id_b355ba48cddd8fb6ee840a212aa8ba40_idx (blame_id), INDEX created_at_b355ba48cddd8fb6ee840a212aa8ba40_idx (created_at), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE farm_phone (id INT AUTO_INCREMENT NOT NULL, farm_id INT NOT NULL, phone_number VARCHAR(20) NOT NULL, person VARCHAR(70) DEFAULT NULL, job_position VARCHAR(30) DEFAULT NULL, description LONGTEXT DEFAULT NULL, INDEX IDX_FCAE88C65FCFA0D (farm_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE farm_phone_audit (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type VARCHAR(10) NOT NULL, object_id VARCHAR(255) NOT NULL, discriminator VARCHAR(255) DEFAULT NULL, transaction_hash VARCHAR(40) DEFAULT NULL, diffs LONGTEXT DEFAULT NULL, blame_id VARCHAR(255) DEFAULT NULL, blame_user VARCHAR(255) DEFAULT NULL, blame_user_fqdn VARCHAR(255) DEFAULT NULL, blame_user_firewall VARCHAR(100) DEFAULT NULL, ip VARCHAR(45) DEFAULT NULL, created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX type_12f51f519bc611e7da077980a4d22b00_idx (type), INDEX object_id_12f51f519bc611e7da077980a4d22b00_idx (object_id), INDEX discriminator_12f51f519bc611e7da077980a4d22b00_idx (discriminator), INDEX transaction_hash_12f51f519bc611e7da077980a4d22b00_idx (transaction_hash), INDEX blame_id_12f51f519bc611e7da077980a4d22b00_idx (blame_id), INDEX created_at_12f51f519bc611e7da077980a4d22b00_idx (created_at), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE transfers_inputs_farm (transfers_id INT NOT NULL, inputs_farm_id INT NOT NULL, INDEX IDX_F4076294A14B7314 (transfers_id), INDEX IDX_F4076294EE00BEEE (inputs_farm_id), PRIMARY KEY(transfers_id, inputs_farm_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE customer_phone ADD CONSTRAINT FK_8A7AE2E69395C3F3 FOREIGN KEY (customer_id) REFERENCES customer (id)');
        $this->addSql('ALTER TABLE farm_phone ADD CONSTRAINT FK_FCAE88C65FCFA0D FOREIGN KEY (farm_id) REFERENCES chicks_recipient (id)');
        $this->addSql('ALTER TABLE transfers_inputs_farm ADD CONSTRAINT FK_F4076294A14B7314 FOREIGN KEY (transfers_id) REFERENCES transfers (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE transfers_inputs_farm ADD CONSTRAINT FK_F4076294EE00BEEE FOREIGN KEY (inputs_farm_id) REFERENCES inputs_farm (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE transfers DROP FOREIGN KEY FK_802A391865FCFA0D');
        $this->addSql('DROP INDEX IDX_802A391865FCFA0D ON transfers');
        $this->addSql('ALTER TABLE transfers DROP farm_id');
        $this->addSql('ALTER TABLE user CHANGE roles roles JSON NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE customer_phone');
        $this->addSql('DROP TABLE customer_phone_audit');
        $this->addSql('DROP TABLE farm_phone');
        $this->addSql('DROP TABLE farm_phone_audit');
        $this->addSql('DROP TABLE transfers_inputs_farm');
        $this->addSql('ALTER TABLE transfers ADD farm_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE transfers ADD CONSTRAINT FK_802A391865FCFA0D FOREIGN KEY (farm_id) REFERENCES inputs_farm (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_802A391865FCFA0D ON transfers (farm_id)');
        $this->addSql('ALTER TABLE `user` CHANGE roles roles LONGTEXT CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_bin`');
    }
}
