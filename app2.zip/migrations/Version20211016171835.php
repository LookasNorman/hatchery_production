<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211016171835 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE inputs_farm DROP FOREIGN KEY FK_CDA3ADA7382975CB');
        $this->addSql('DROP TABLE plan_inputs');
        $this->addSql('DROP INDEX IDX_CDA3ADA7382975CB ON inputs_farm');
        $this->addSql('ALTER TABLE inputs_farm DROP plan_inputs_id');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE plan_inputs (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(50) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, input_date DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE inputs_farm ADD plan_inputs_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE inputs_farm ADD CONSTRAINT FK_CDA3ADA7382975CB FOREIGN KEY (plan_inputs_id) REFERENCES plan_inputs (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_CDA3ADA7382975CB ON inputs_farm (plan_inputs_id)');
    }
}
