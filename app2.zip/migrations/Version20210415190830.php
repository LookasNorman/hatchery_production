<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210415190830 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE eggs_inputs_details_eggs_delivery');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE eggs_inputs_details_eggs_delivery (eggs_inputs_details_id INT NOT NULL, eggs_delivery_id INT NOT NULL, INDEX IDX_9073E5D225794C8F (eggs_inputs_details_id), INDEX IDX_9073E5D2AFC9792E (eggs_delivery_id), PRIMARY KEY(eggs_inputs_details_id, eggs_delivery_id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE eggs_inputs_details_eggs_delivery ADD CONSTRAINT FK_9073E5D225794C8F FOREIGN KEY (eggs_inputs_details_id) REFERENCES eggs_inputs_details (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE eggs_inputs_details_eggs_delivery ADD CONSTRAINT FK_9073E5D2AFC9792E FOREIGN KEY (eggs_delivery_id) REFERENCES eggs_delivery (id) ON UPDATE NO ACTION ON DELETE CASCADE');
    }
}
