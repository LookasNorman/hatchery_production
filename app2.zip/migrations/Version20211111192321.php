<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211111192321 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE transfers_herds (transfers_id INT NOT NULL, herds_id INT NOT NULL, INDEX IDX_1B461CFCA14B7314 (transfers_id), INDEX IDX_1B461CFC75706932 (herds_id), PRIMARY KEY(transfers_id, herds_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE transfers_herds ADD CONSTRAINT FK_1B461CFCA14B7314 FOREIGN KEY (transfers_id) REFERENCES transfers (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE transfers_herds ADD CONSTRAINT FK_1B461CFC75706932 FOREIGN KEY (herds_id) REFERENCES herds (id) ON DELETE CASCADE');
        $this->addSql('DROP TABLE input_delivery_transfers');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE input_delivery_transfers (input_delivery_id INT NOT NULL, transfers_id INT NOT NULL, INDEX IDX_B3D9FE6DA14B7314 (transfers_id), INDEX IDX_B3D9FE6DE7D95564 (input_delivery_id), PRIMARY KEY(input_delivery_id, transfers_id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE input_delivery_transfers ADD CONSTRAINT FK_B3D9FE6DA14B7314 FOREIGN KEY (transfers_id) REFERENCES transfers (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE input_delivery_transfers ADD CONSTRAINT FK_B3D9FE6DE7D95564 FOREIGN KEY (input_delivery_id) REFERENCES input_delivery (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('DROP TABLE transfers_herds');
    }
}
