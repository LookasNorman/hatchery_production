<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211015085252 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE plans_breeds (plan_delivery_chick_id INT NOT NULL, breed_id INT NOT NULL, INDEX IDX_14C0E4106F31B5ED (plan_delivery_chick_id), INDEX IDX_14C0E410A8B4A30F (breed_id), PRIMARY KEY(plan_delivery_chick_id, breed_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE plans_breeds ADD CONSTRAINT FK_14C0E4106F31B5ED FOREIGN KEY (plan_delivery_chick_id) REFERENCES plan_delivery_chick (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE plans_breeds ADD CONSTRAINT FK_14C0E410A8B4A30F FOREIGN KEY (breed_id) REFERENCES breed (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE plan_delivery_chick DROP FOREIGN KEY FK_9A41D3EFA8B4A30F');
        $this->addSql('DROP INDEX IDX_9A41D3EFA8B4A30F ON plan_delivery_chick');
        $this->addSql('ALTER TABLE plan_delivery_chick DROP breed_id');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE plans_breeds');
        $this->addSql('ALTER TABLE plan_delivery_chick ADD breed_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE plan_delivery_chick ADD CONSTRAINT FK_9A41D3EFA8B4A30F FOREIGN KEY (breed_id) REFERENCES breed (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_9A41D3EFA8B4A30F ON plan_delivery_chick (breed_id)');
    }
}
