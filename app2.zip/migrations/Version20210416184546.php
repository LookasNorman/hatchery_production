<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210416184546 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE eggs_delivery DROP FOREIGN KEY FK_DBBBAAB675706932');
        $this->addSql('DROP INDEX IDX_DBBBAAB675706932 ON eggs_delivery');
        $this->addSql('ALTER TABLE eggs_delivery DROP herds_id');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE eggs_delivery ADD herds_id INT NOT NULL');
        $this->addSql('ALTER TABLE eggs_delivery ADD CONSTRAINT FK_DBBBAAB675706932 FOREIGN KEY (herds_id) REFERENCES herds (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_DBBBAAB675706932 ON eggs_delivery (herds_id)');
    }
}
