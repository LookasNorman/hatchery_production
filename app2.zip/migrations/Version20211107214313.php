<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211107214313 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE plan_input_chicks_recipient');
        $this->addSql('ALTER TABLE inputs ADD email VARCHAR(50) DEFAULT NULL, ADD phone_number VARCHAR(30) DEFAULT NULL, ADD postcode VARCHAR(15) DEFAULT NULL, ADD city VARCHAR(255) DEFAULT NULL, ADD street VARCHAR(255) DEFAULT NULL, ADD street_number VARCHAR(20) DEFAULT NULL');
        $this->addSql('ALTER TABLE plan_input ADD farm_id INT NOT NULL');
        $this->addSql('ALTER TABLE plan_input ADD CONSTRAINT FK_8B8E772B65FCFA0D FOREIGN KEY (farm_id) REFERENCES chicks_recipient (id)');
        $this->addSql('CREATE INDEX IDX_8B8E772B65FCFA0D ON plan_input (farm_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE plan_input_chicks_recipient (plan_input_id INT NOT NULL, chicks_recipient_id INT NOT NULL, INDEX IDX_67EDD79238272DAC (plan_input_id), INDEX IDX_67EDD792565687D0 (chicks_recipient_id), PRIMARY KEY(plan_input_id, chicks_recipient_id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE plan_input_chicks_recipient ADD CONSTRAINT FK_67EDD79238272DAC FOREIGN KEY (plan_input_id) REFERENCES plan_input (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE plan_input_chicks_recipient ADD CONSTRAINT FK_67EDD792565687D0 FOREIGN KEY (chicks_recipient_id) REFERENCES chicks_recipient (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE inputs DROP email, DROP phone_number, DROP postcode, DROP city, DROP street, DROP street_number');
        $this->addSql('ALTER TABLE plan_input DROP FOREIGN KEY FK_8B8E772B65FCFA0D');
        $this->addSql('DROP INDEX IDX_8B8E772B65FCFA0D ON plan_input');
        $this->addSql('ALTER TABLE plan_input DROP farm_id');
    }
}
