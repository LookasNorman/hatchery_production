<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211108195453 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE selling_egg (id INT AUTO_INCREMENT NOT NULL, delivery_id INT NOT NULL, date DATE NOT NULL, eggs_number INT NOT NULL, INDEX IDX_25405E8B12136921 (delivery_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE selling_egg_audit (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type VARCHAR(10) NOT NULL, object_id VARCHAR(255) NOT NULL, discriminator VARCHAR(255) DEFAULT NULL, transaction_hash VARCHAR(40) DEFAULT NULL, diffs LONGTEXT DEFAULT NULL, blame_id VARCHAR(255) DEFAULT NULL, blame_user VARCHAR(255) DEFAULT NULL, blame_user_fqdn VARCHAR(255) DEFAULT NULL, blame_user_firewall VARCHAR(100) DEFAULT NULL, ip VARCHAR(45) DEFAULT NULL, created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX type_b008dfe5198afbfb197d81084af2bd67_idx (type), INDEX object_id_b008dfe5198afbfb197d81084af2bd67_idx (object_id), INDEX discriminator_b008dfe5198afbfb197d81084af2bd67_idx (discriminator), INDEX transaction_hash_b008dfe5198afbfb197d81084af2bd67_idx (transaction_hash), INDEX blame_id_b008dfe5198afbfb197d81084af2bd67_idx (blame_id), INDEX created_at_b008dfe5198afbfb197d81084af2bd67_idx (created_at), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE selling_egg ADD CONSTRAINT FK_25405E8B12136921 FOREIGN KEY (delivery_id) REFERENCES delivery (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE selling_egg');
        $this->addSql('DROP TABLE selling_egg_audit');
    }
}
