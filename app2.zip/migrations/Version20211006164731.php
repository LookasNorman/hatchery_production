<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211006164731 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE details_delivery DROP FOREIGN KEY FK_5DD79F9B7DDEB528');
        $this->addSql('ALTER TABLE lighting DROP FOREIGN KEY FK_CB081573DF0E0DBC');
        $this->addSql('ALTER TABLE selections DROP FOREIGN KEY FK_32F2D70DF0E0DBC');
        $this->addSql('ALTER TABLE transfers DROP FOREIGN KEY FK_802A3918DF0E0DBC');
        $this->addSql('DROP TABLE details_delivery');
        $this->addSql('DROP TABLE inputs_delivery');
        $this->addSql('DROP TABLE inputs_details');
        $this->addSql('ALTER TABLE delivery DROP inputs_delivery_id');
        $this->addSql('DROP INDEX IDX_CB081573DF0E0DBC ON lighting');
        $this->addSql('ALTER TABLE lighting DROP eggs_inputs_detail_id');
        $this->addSql('DROP INDEX IDX_32F2D70DF0E0DBC ON selections');
        $this->addSql('ALTER TABLE selections DROP eggs_inputs_detail_id');
        $this->addSql('DROP INDEX IDX_802A3918DF0E0DBC ON transfers');
        $this->addSql('ALTER TABLE transfers DROP eggs_inputs_detail_id');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE details_delivery (id INT AUTO_INCREMENT NOT NULL, eggs_input_details_id INT NOT NULL, eggs_deliveries_id INT NOT NULL, eggs_number INT NOT NULL, INDEX IDX_5DD79F9B623A171B (eggs_deliveries_id), INDEX IDX_5DD79F9B7DDEB528 (eggs_input_details_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('CREATE TABLE inputs_delivery (id INT AUTO_INCREMENT NOT NULL, inputs_farm_id INT NOT NULL, eggs_number INT NOT NULL, INDEX IDX_E09A396EE00BEEE (inputs_farm_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('CREATE TABLE inputs_details (id INT AUTO_INCREMENT NOT NULL, egg_input_id INT NOT NULL, chicks_recipient_id INT DEFAULT NULL, chick_number INT NOT NULL, INDEX IDX_F9DA4F69565687D0 (chicks_recipient_id), INDEX IDX_F9DA4F697F7B0ADD (egg_input_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE details_delivery ADD CONSTRAINT FK_5DD79F9B623A171B FOREIGN KEY (eggs_deliveries_id) REFERENCES delivery (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE details_delivery ADD CONSTRAINT FK_5DD79F9B7DDEB528 FOREIGN KEY (eggs_input_details_id) REFERENCES inputs_details (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE inputs_delivery ADD CONSTRAINT FK_E09A396EE00BEEE FOREIGN KEY (inputs_farm_id) REFERENCES inputs_farm (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE inputs_details ADD CONSTRAINT FK_F9DA4F69565687D0 FOREIGN KEY (chicks_recipient_id) REFERENCES chicks_recipient (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE inputs_details ADD CONSTRAINT FK_F9DA4F697F7B0ADD FOREIGN KEY (egg_input_id) REFERENCES inputs (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE delivery ADD inputs_delivery_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE lighting ADD eggs_inputs_detail_id INT NOT NULL');
        $this->addSql('ALTER TABLE lighting ADD CONSTRAINT FK_CB081573DF0E0DBC FOREIGN KEY (eggs_inputs_detail_id) REFERENCES inputs_details (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_CB081573DF0E0DBC ON lighting (eggs_inputs_detail_id)');
        $this->addSql('ALTER TABLE selections ADD eggs_inputs_detail_id INT NOT NULL');
        $this->addSql('ALTER TABLE selections ADD CONSTRAINT FK_32F2D70DF0E0DBC FOREIGN KEY (eggs_inputs_detail_id) REFERENCES inputs_details (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_32F2D70DF0E0DBC ON selections (eggs_inputs_detail_id)');
        $this->addSql('ALTER TABLE transfers ADD eggs_inputs_detail_id INT NOT NULL');
        $this->addSql('ALTER TABLE transfers ADD CONSTRAINT FK_802A3918DF0E0DBC FOREIGN KEY (eggs_inputs_detail_id) REFERENCES inputs_details (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_802A3918DF0E0DBC ON transfers (eggs_inputs_detail_id)');
    }
}
