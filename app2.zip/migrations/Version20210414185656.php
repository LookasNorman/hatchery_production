<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210414185656 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE eggs_delivery ADD breeder_id INT NOT NULL');
        $this->addSql('ALTER TABLE eggs_delivery ADD CONSTRAINT FK_DBBBAAB633C95BB1 FOREIGN KEY (breeder_id) REFERENCES egg_supplier (id)');
        $this->addSql('CREATE INDEX IDX_DBBBAAB633C95BB1 ON eggs_delivery (breeder_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE eggs_delivery DROP FOREIGN KEY FK_DBBBAAB633C95BB1');
        $this->addSql('DROP INDEX IDX_DBBBAAB633C95BB1 ON eggs_delivery');
        $this->addSql('ALTER TABLE eggs_delivery DROP breeder_id');
    }
}
