<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211026202430 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE transport_list (id INT AUTO_INCREMENT NOT NULL, farm_id INT NOT NULL, car_id INT NOT NULL, distance INT NOT NULL, departure_hour TIME NOT NULL, arrival_hour_to_farm TIME NOT NULL, INDEX IDX_9918AF9D65FCFA0D (farm_id), INDEX IDX_9918AF9DC3C6F69F (car_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE transport_list_driver (transport_list_id INT NOT NULL, driver_id INT NOT NULL, INDEX IDX_1ED85DF0A979D67A (transport_list_id), INDEX IDX_1ED85DF0C3423909 (driver_id), PRIMARY KEY(transport_list_id, driver_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE transport_list ADD CONSTRAINT FK_9918AF9D65FCFA0D FOREIGN KEY (farm_id) REFERENCES inputs_farm (id)');
        $this->addSql('ALTER TABLE transport_list ADD CONSTRAINT FK_9918AF9DC3C6F69F FOREIGN KEY (car_id) REFERENCES car (id)');
        $this->addSql('ALTER TABLE transport_list_driver ADD CONSTRAINT FK_1ED85DF0A979D67A FOREIGN KEY (transport_list_id) REFERENCES transport_list (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE transport_list_driver ADD CONSTRAINT FK_1ED85DF0C3423909 FOREIGN KEY (driver_id) REFERENCES driver (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE transport_list_driver DROP FOREIGN KEY FK_1ED85DF0A979D67A');
        $this->addSql('DROP TABLE transport_list');
        $this->addSql('DROP TABLE transport_list_driver');
    }
}
