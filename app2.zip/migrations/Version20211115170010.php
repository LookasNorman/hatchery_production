<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211115170010 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE transport_list_inputs_farm (transport_list_id INT NOT NULL, inputs_farm_id INT NOT NULL, INDEX IDX_51A4E75CA979D67A (transport_list_id), INDEX IDX_51A4E75CEE00BEEE (inputs_farm_id), PRIMARY KEY(transport_list_id, inputs_farm_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE transport_list_inputs_farm ADD CONSTRAINT FK_51A4E75CA979D67A FOREIGN KEY (transport_list_id) REFERENCES transport_list (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE transport_list_inputs_farm ADD CONSTRAINT FK_51A4E75CEE00BEEE FOREIGN KEY (inputs_farm_id) REFERENCES inputs_farm (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE transport_list_inputs_farm');
    }
}
