<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211008205725 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE plan_input_farm DROP FOREIGN KEY FK_761651647F7B0ADD');
        $this->addSql('CREATE TABLE plan_delivery_chick (id INT AUTO_INCREMENT NOT NULL, chick_farm_id INT NOT NULL, chick_number INT NOT NULL, delivery_date DATETIME NOT NULL, input_date DATETIME NOT NULL, lighting_date DATETIME NOT NULL, transfer_date DATETIME NOT NULL, INDEX IDX_9A41D3EF29FA264A (chick_farm_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE plan_delivery_chick ADD CONSTRAINT FK_9A41D3EF29FA264A FOREIGN KEY (chick_farm_id) REFERENCES chicks_recipient (id)');
        $this->addSql('DROP TABLE plan_input');
        $this->addSql('DROP TABLE plan_input_farm');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE plan_input (id INT AUTO_INCREMENT NOT NULL, input_date DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('CREATE TABLE plan_input_farm (id INT AUTO_INCREMENT NOT NULL, egg_input_id INT NOT NULL, chicks_farm_id INT NOT NULL, chick_number INT NOT NULL, INDEX IDX_761651647F7B0ADD (egg_input_id), INDEX IDX_761651649D85B828 (chicks_farm_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE plan_input_farm ADD CONSTRAINT FK_761651647F7B0ADD FOREIGN KEY (egg_input_id) REFERENCES plan_input (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('ALTER TABLE plan_input_farm ADD CONSTRAINT FK_761651649D85B828 FOREIGN KEY (chicks_farm_id) REFERENCES chicks_recipient (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('DROP TABLE plan_delivery_chick');
    }
}
