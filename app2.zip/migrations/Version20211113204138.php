<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211113204138 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE delivery ADD waste_lighting INT DEFAULT NULL, ADD fertilization NUMERIC(5, 2) DEFAULT NULL, ADD waste_eggs_lighting INT DEFAULT NULL, ADD lighting_eggs INT DEFAULT NULL, ADD transfers_egg INT DEFAULT NULL, ADD chick_number INT DEFAULT NULL, ADD cull_chicken INT DEFAULT NULL, ADD unhatched INT DEFAULT NULL');
        $this->addSql('ALTER TABLE user CHANGE roles roles JSON NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE delivery DROP waste_lighting, DROP fertilization, DROP waste_eggs_lighting, DROP lighting_eggs, DROP transfers_egg, DROP chick_number, DROP cull_chicken, DROP unhatched');
        $this->addSql('ALTER TABLE `user` CHANGE roles roles LONGTEXT CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_bin`');
    }
}
