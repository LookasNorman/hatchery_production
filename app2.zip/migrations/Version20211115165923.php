<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211115165923 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE transport_list DROP FOREIGN KEY FK_9918AF9D65FCFA0D');
        $this->addSql('DROP INDEX IDX_9918AF9D65FCFA0D ON transport_list');
        $this->addSql('ALTER TABLE transport_list DROP farm_id');
        $this->addSql('ALTER TABLE user CHANGE roles roles JSON NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE transport_list ADD farm_id INT NOT NULL');
        $this->addSql('ALTER TABLE transport_list ADD CONSTRAINT FK_9918AF9D65FCFA0D FOREIGN KEY (farm_id) REFERENCES inputs_farm (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_9918AF9D65FCFA0D ON transport_list (farm_id)');
        $this->addSql('ALTER TABLE `user` CHANGE roles roles LONGTEXT CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_bin`');
    }
}
