<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211018195803 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE plan_indicators ADD hatchers_number INT DEFAULT NULL, ADD hatchers_capacity INT DEFAULT NULL, ADD setters_number INT DEFAULT NULL, ADD setters_capacity INT DEFAULT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE plan_indicators DROP hatchers_number, DROP hatchers_capacity, DROP setters_number, DROP setters_capacity');
    }
}
