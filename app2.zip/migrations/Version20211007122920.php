<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211007122920 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD selections_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD CONSTRAINT FK_73F97091B94BCAD5 FOREIGN KEY (selections_id) REFERENCES selections (id)');
        $this->addSql('CREATE INDEX IDX_73F97091B94BCAD5 ON inputs_farm_delivery (selections_id)');
        $this->addSql('ALTER TABLE selections ADD unhatched INT NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP FOREIGN KEY FK_73F97091B94BCAD5');
        $this->addSql('DROP INDEX IDX_73F97091B94BCAD5 ON inputs_farm_delivery');
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP selections_id');
        $this->addSql('ALTER TABLE selections DROP unhatched');
    }
}
