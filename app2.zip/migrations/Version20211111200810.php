<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211111200810 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE transfers_herds');
        $this->addSql('ALTER TABLE transfers ADD herd_id INT DEFAULT NULL, ADD input_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE transfers ADD CONSTRAINT FK_802A3918D35A8CCC FOREIGN KEY (herd_id) REFERENCES herds (id)');
        $this->addSql('ALTER TABLE transfers ADD CONSTRAINT FK_802A391836421AD6 FOREIGN KEY (input_id) REFERENCES inputs (id)');
        $this->addSql('CREATE INDEX IDX_802A3918D35A8CCC ON transfers (herd_id)');
        $this->addSql('CREATE INDEX IDX_802A391836421AD6 ON transfers (input_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE transfers_herds (transfers_id INT NOT NULL, herds_id INT NOT NULL, INDEX IDX_1B461CFC75706932 (herds_id), INDEX IDX_1B461CFCA14B7314 (transfers_id), PRIMARY KEY(transfers_id, herds_id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE transfers_herds ADD CONSTRAINT FK_1B461CFC75706932 FOREIGN KEY (herds_id) REFERENCES herds (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE transfers_herds ADD CONSTRAINT FK_1B461CFCA14B7314 FOREIGN KEY (transfers_id) REFERENCES transfers (id) ON UPDATE NO ACTION ON DELETE CASCADE');
        $this->addSql('ALTER TABLE transfers DROP FOREIGN KEY FK_802A3918D35A8CCC');
        $this->addSql('ALTER TABLE transfers DROP FOREIGN KEY FK_802A391836421AD6');
        $this->addSql('DROP INDEX IDX_802A3918D35A8CCC ON transfers');
        $this->addSql('DROP INDEX IDX_802A391836421AD6 ON transfers');
        $this->addSql('ALTER TABLE transfers DROP herd_id, DROP input_id');
    }
}
