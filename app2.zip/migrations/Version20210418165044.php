<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210418165044 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE eggs_inputs_details ADD chcicks_recipient_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE eggs_inputs_details ADD CONSTRAINT FK_DE422172540680A7 FOREIGN KEY (chcicks_recipient_id) REFERENCES chicks_recipient (id)');
        $this->addSql('CREATE INDEX IDX_DE422172540680A7 ON eggs_inputs_details (chcicks_recipient_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE eggs_inputs_details DROP FOREIGN KEY FK_DE422172540680A7');
        $this->addSql('DROP INDEX IDX_DE422172540680A7 ON eggs_inputs_details');
        $this->addSql('ALTER TABLE eggs_inputs_details DROP chcicks_recipient_id');
    }
}
