<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211007095643 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD transfers_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE inputs_farm_delivery ADD CONSTRAINT FK_73F97091A14B7314 FOREIGN KEY (transfers_id) REFERENCES transfers (id)');
        $this->addSql('CREATE INDEX IDX_73F97091A14B7314 ON inputs_farm_delivery (transfers_id)');
        $this->addSql('ALTER TABLE transfers CHANGE waste_eggs transfers_egg INT NOT NULL');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP FOREIGN KEY FK_73F97091A14B7314');
        $this->addSql('DROP INDEX IDX_73F97091A14B7314 ON inputs_farm_delivery');
        $this->addSql('ALTER TABLE inputs_farm_delivery DROP transfers_id');
        $this->addSql('ALTER TABLE transfers CHANGE transfers_egg waste_eggs INT NOT NULL');
    }
}
