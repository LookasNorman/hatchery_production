<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211108195241 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE input_delivery (id INT AUTO_INCREMENT NOT NULL, input_id INT NOT NULL, delivery_id INT NOT NULL, eggs_number INT NOT NULL, INDEX IDX_ACF0383936421AD6 (input_id), INDEX IDX_ACF0383912136921 (delivery_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE input_delivery ADD CONSTRAINT FK_ACF0383936421AD6 FOREIGN KEY (input_id) REFERENCES inputs (id)');
        $this->addSql('ALTER TABLE input_delivery ADD CONSTRAINT FK_ACF0383912136921 FOREIGN KEY (delivery_id) REFERENCES delivery (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE input_delivery');
    }
}
