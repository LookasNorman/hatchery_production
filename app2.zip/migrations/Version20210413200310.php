<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210413200310 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE eggs_delivery (id INT AUTO_INCREMENT NOT NULL, herd_id INT NOT NULL, delivery_date DATE NOT NULL, eggs_number INT NOT NULL, first_laying_date DATE NOT NULL, last_laying_date DATE NOT NULL, INDEX IDX_DBBBAAB6D35A8CCC (herd_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE eggs_delivery ADD CONSTRAINT FK_DBBBAAB6D35A8CCC FOREIGN KEY (herd_id) REFERENCES herds (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE eggs_delivery');
    }
}
