<?php

namespace App\Repository;

use App\Entity\Customer;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Customer|null find($id, $lockMode = null, $lockVersion = null)
 * @method Customer|null findOneBy(array $criteria, array $orderBy = null)
 * @method Customer[]    findAll()
 * @method Customer[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CustomerRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Customer::class);
    }

    public function customersWithPlan()
    {
        return $this->createQueryBuilder('c')
            ->addSelect('MAX(p.deliveryDate) as deliveryDate')
            ->leftJoin('c.chicksRecipients', 'cr')
            ->leftJoin('cr.planDeliveryChicks', 'p')
            ->orderBy('c.name', 'ASC')
            ->groupBy('c')
            ->getQuery()
            ->getResult()
        ;
    }

    public function customersIntegrationWithPlan($integration)
    {
        return $this->createQueryBuilder('c')
            ->addSelect('MAX(p.deliveryDate) as deliveryDate')
            ->leftJoin('c.chicksRecipients', 'cr')
            ->leftJoin('cr.planDeliveryChicks', 'p')
            ->andWhere('c.chickIntegration = :integration')
            ->setParameters(['integration' => $integration])
            ->orderBy('c.name', 'ASC')
            ->groupBy('c')
            ->getQuery()
            ->getResult()
            ;
    }

}
