<?php

namespace Container5hElkYd;

use Symfony\Component\DependencyInjection\Argument\RewindableGenerator;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\Exception\InvalidArgumentException;
use Symfony\Component\DependencyInjection\Exception\LogicException;
use Symfony\Component\DependencyInjection\Exception\RuntimeException;
use Symfony\Component\DependencyInjection\ParameterBag\FrozenParameterBag;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;

/*
 * This class has been auto-generated
 * by the Symfony Dependency Injection Component.
 *
 * @final
 */
class srcApp_KernelProdContainer extends Container
{
    private $buildParameters;
    private $containerDir;
    private $targetDir;
    private $parameters = [];
    private $getService;

    public function __construct(array $buildParameters = [], $containerDir = __DIR__)
    {
        $this->getService = \Closure::fromCallable([$this, 'getService']);
        $this->buildParameters = $buildParameters;
        $this->containerDir = $containerDir;
        $this->targetDir = \dirname($containerDir);
        $this->parameters = $this->getDefaultParameters();

        $this->services = $this->privates = [];
        $this->syntheticIds = [
            'kernel' => true,
        ];
        $this->methodMap = [
            'App\\Controller\\BreedController' => 'getBreedControllerService',
            'App\\Controller\\BreedStandardController' => 'getBreedStandardControllerService',
            'App\\Controller\\CarController' => 'getCarControllerService',
            'App\\Controller\\ChickIntegrationController' => 'getChickIntegrationControllerService',
            'App\\Controller\\ChickTemperatureController' => 'getChickTemperatureControllerService',
            'App\\Controller\\ChicksRecipientController' => 'getChicksRecipientControllerService',
            'App\\Controller\\ContactInfoController' => 'getContactInfoControllerService',
            'App\\Controller\\CustomerController' => 'getCustomerControllerService',
            'App\\Controller\\DefaultController' => 'getDefaultControllerService',
            'App\\Controller\\DeliveryController' => 'getDeliveryControllerService',
            'App\\Controller\\DriverController' => 'getDriverControllerService',
            'App\\Controller\\HatchersController' => 'getHatchersControllerService',
            'App\\Controller\\HerdsController' => 'getHerdsControllerService',
            'App\\Controller\\InputDeliveryController' => 'getInputDeliveryControllerService',
            'App\\Controller\\InputsController' => 'getInputsControllerService',
            'App\\Controller\\InputsFarmController' => 'getInputsFarmControllerService',
            'App\\Controller\\InputsFarmDeliveryPlanController' => 'getInputsFarmDeliveryPlanControllerService',
            'App\\Controller\\LightingController' => 'getLightingControllerService',
            'App\\Controller\\PlanBreederController' => 'getPlanBreederControllerService',
            'App\\Controller\\PlanController' => 'getPlanControllerService',
            'App\\Controller\\PlanDeliveryChickController' => 'getPlanDeliveryChickControllerService',
            'App\\Controller\\PlanDeliveryEggController' => 'getPlanDeliveryEggControllerService',
            'App\\Controller\\PlanDetailController' => 'getPlanDetailControllerService',
            'App\\Controller\\PlanHatchingDateController' => 'getPlanHatchingDateControllerService',
            'App\\Controller\\PlanIndicatorsController' => 'getPlanIndicatorsControllerService',
            'App\\Controller\\PlanInputController' => 'getPlanInputControllerService',
            'App\\Controller\\Production\\ProductionChickTemperatureController' => 'getProductionChickTemperatureControllerService',
            'App\\Controller\\Production\\ProductionController' => 'getProductionControllerService',
            'App\\Controller\\Production\\ProductionDeliveryController' => 'getProductionDeliveryControllerService',
            'App\\Controller\\Production\\ProductionInputsController' => 'getProductionInputsControllerService',
            'App\\Controller\\Production\\ProductionLightingController' => 'getProductionLightingControllerService',
            'App\\Controller\\Production\\ProductionSelectionController' => 'getProductionSelectionControllerService',
            'App\\Controller\\Production\\ProductionTransferController' => 'getProductionTransferControllerService',
            'App\\Controller\\RegistrationController' => 'getRegistrationControllerService',
            'App\\Controller\\ResetPasswordController' => 'getResetPasswordControllerService',
            'App\\Controller\\SecurityController' => 'getSecurityControllerService',
            'App\\Controller\\SelectionsController' => 'getSelectionsControllerService',
            'App\\Controller\\SellingEggController' => 'getSellingEggControllerService',
            'App\\Controller\\SettersController' => 'getSettersControllerService',
            'App\\Controller\\SupplierController' => 'getSupplierControllerService',
            'App\\Controller\\TransfersController' => 'getTransfersControllerService',
            'App\\Controller\\TransportListController' => 'getTransportListControllerService',
            'App\\Controller\\UserController' => 'getUserControllerService',
            'App\\Controller\\VaccinationController' => 'getVaccinationControllerService',
            'App\\Security\\AccessDeniedHandler' => 'getAccessDeniedHandlerService',
            'DH\\AuditorBundle\\Controller\\ViewerController' => 'getViewerControllerService',
            'Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController' => 'getRedirectControllerService',
            'Symfony\\Bundle\\FrameworkBundle\\Controller\\TemplateController' => 'getTemplateControllerService',
            'cache.app' => 'getCache_AppService',
            'cache.app_clearer' => 'getCache_AppClearerService',
            'cache.global_clearer' => 'getCache_GlobalClearerService',
            'cache.system' => 'getCache_SystemService',
            'cache.system_clearer' => 'getCache_SystemClearerService',
            'cache_clearer' => 'getCacheClearerService',
            'cache_warmer' => 'getCacheWarmerService',
            'console.command_loader' => 'getConsole_CommandLoaderService',
            'container.env_var_processors_locator' => 'getContainer_EnvVarProcessorsLocatorService',
            'doctrine' => 'getDoctrineService',
            'doctrine.dbal.default_connection' => 'getDoctrine_Dbal_DefaultConnectionService',
            'doctrine.orm.default_entity_manager' => 'getDoctrine_Orm_DefaultEntityManagerService',
            'error_controller' => 'getErrorControllerService',
            'event_dispatcher' => 'getEventDispatcherService',
            'filesystem' => 'getFilesystemService',
            'form.factory' => 'getForm_FactoryService',
            'form.type.file' => 'getForm_Type_FileService',
            'http_kernel' => 'getHttpKernelService',
            'knp_snappy.image' => 'getKnpSnappy_ImageService',
            'knp_snappy.pdf' => 'getKnpSnappy_PdfService',
            'request_stack' => 'getRequestStackService',
            'router' => 'getRouterService',
            'routing.loader' => 'getRouting_LoaderService',
            'security.authentication_utils' => 'getSecurity_AuthenticationUtilsService',
            'security.authorization_checker' => 'getSecurity_AuthorizationCheckerService',
            'security.csrf.token_manager' => 'getSecurity_Csrf_TokenManagerService',
            'security.password_encoder' => 'getSecurity_PasswordEncoderService',
            'security.token_storage' => 'getSecurity_TokenStorageService',
            'serializer' => 'getSerializerService',
            'services_resetter' => 'getServicesResetterService',
            'session' => 'getSessionService',
            'swiftmailer.mailer.default' => 'getSwiftmailer_Mailer_DefaultService',
            'swiftmailer.mailer.default.transport.real' => 'getSwiftmailer_Mailer_Default_Transport_RealService',
            'swiftmailer.transport' => 'getSwiftmailer_TransportService',
            'translator' => 'getTranslatorService',
            'twig' => 'getTwigService',
            'twig.controller.exception' => 'getTwig_Controller_ExceptionService',
            'twig.controller.preview_error' => 'getTwig_Controller_PreviewErrorService',
            'validator' => 'getValidatorService',
        ];
        $this->aliases = [
            'database_connection' => 'doctrine.dbal.default_connection',
            'doctrine.orm.entity_manager' => 'doctrine.orm.default_entity_manager',
            'mailer' => 'swiftmailer.mailer.default',
        ];
    }

    public function compile(): void
    {
        throw new LogicException('You cannot compile a dumped container that was already compiled.');
    }

    public function isCompiled(): bool
    {
        return true;
    }

    public function getRemovedIds(): array
    {
        return require $this->containerDir.\DIRECTORY_SEPARATOR.'removed-ids.php';
    }

    protected function createProxy($class, \Closure $factory)
    {
        class_exists($class, false) || class_alias(__NAMESPACE__."\\$class", $class, false);

        return $factory();
    }

    /*
     * Gets the public 'App\Controller\BreedController' shared autowired service.
     *
     * @return \App\Controller\BreedController
     */
    protected function getBreedControllerService()
    {
        $this->services['App\\Controller\\BreedController'] = $instance = new \App\Controller\BreedController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\BreedController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\BreedStandardController' shared autowired service.
     *
     * @return \App\Controller\BreedStandardController
     */
    protected function getBreedStandardControllerService()
    {
        $this->services['App\\Controller\\BreedStandardController'] = $instance = new \App\Controller\BreedStandardController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\BreedStandardController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\CarController' shared autowired service.
     *
     * @return \App\Controller\CarController
     */
    protected function getCarControllerService()
    {
        $this->services['App\\Controller\\CarController'] = $instance = new \App\Controller\CarController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\CarController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\ChickIntegrationController' shared autowired service.
     *
     * @return \App\Controller\ChickIntegrationController
     */
    protected function getChickIntegrationControllerService()
    {
        $this->services['App\\Controller\\ChickIntegrationController'] = $instance = new \App\Controller\ChickIntegrationController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\ChickIntegrationController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\ChickTemperatureController' shared autowired service.
     *
     * @return \App\Controller\ChickTemperatureController
     */
    protected function getChickTemperatureControllerService()
    {
        $this->services['App\\Controller\\ChickTemperatureController'] = $instance = new \App\Controller\ChickTemperatureController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\ChickTemperatureController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\ChicksRecipientController' shared autowired service.
     *
     * @return \App\Controller\ChicksRecipientController
     */
    protected function getChicksRecipientControllerService()
    {
        $this->services['App\\Controller\\ChicksRecipientController'] = $instance = new \App\Controller\ChicksRecipientController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\ChicksRecipientController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\ContactInfoController' shared autowired service.
     *
     * @return \App\Controller\ContactInfoController
     */
    protected function getContactInfoControllerService()
    {
        $this->services['App\\Controller\\ContactInfoController'] = $instance = new \App\Controller\ContactInfoController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\ContactInfoController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\CustomerController' shared autowired service.
     *
     * @return \App\Controller\CustomerController
     */
    protected function getCustomerControllerService()
    {
        $this->services['App\\Controller\\CustomerController'] = $instance = new \App\Controller\CustomerController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\CustomerController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\DefaultController' shared autowired service.
     *
     * @return \App\Controller\DefaultController
     */
    protected function getDefaultControllerService()
    {
        $this->services['App\\Controller\\DefaultController'] = $instance = new \App\Controller\DefaultController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\DefaultController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\DeliveryController' shared autowired service.
     *
     * @return \App\Controller\DeliveryController
     */
    protected function getDeliveryControllerService()
    {
        $this->services['App\\Controller\\DeliveryController'] = $instance = new \App\Controller\DeliveryController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\DeliveryController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\DriverController' shared autowired service.
     *
     * @return \App\Controller\DriverController
     */
    protected function getDriverControllerService()
    {
        $this->services['App\\Controller\\DriverController'] = $instance = new \App\Controller\DriverController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\DriverController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\HatchersController' shared autowired service.
     *
     * @return \App\Controller\HatchersController
     */
    protected function getHatchersControllerService()
    {
        $this->services['App\\Controller\\HatchersController'] = $instance = new \App\Controller\HatchersController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\HatchersController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\HerdsController' shared autowired service.
     *
     * @return \App\Controller\HerdsController
     */
    protected function getHerdsControllerService()
    {
        $this->services['App\\Controller\\HerdsController'] = $instance = new \App\Controller\HerdsController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\HerdsController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\InputDeliveryController' shared autowired service.
     *
     * @return \App\Controller\InputDeliveryController
     */
    protected function getInputDeliveryControllerService()
    {
        $this->services['App\\Controller\\InputDeliveryController'] = $instance = new \App\Controller\InputDeliveryController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\InputDeliveryController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\InputsController' shared autowired service.
     *
     * @return \App\Controller\InputsController
     */
    protected function getInputsControllerService()
    {
        $this->services['App\\Controller\\InputsController'] = $instance = new \App\Controller\InputsController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\InputsController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\InputsFarmController' shared autowired service.
     *
     * @return \App\Controller\InputsFarmController
     */
    protected function getInputsFarmControllerService()
    {
        $this->services['App\\Controller\\InputsFarmController'] = $instance = new \App\Controller\InputsFarmController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\InputsFarmController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\InputsFarmDeliveryPlanController' shared autowired service.
     *
     * @return \App\Controller\InputsFarmDeliveryPlanController
     */
    protected function getInputsFarmDeliveryPlanControllerService()
    {
        $this->services['App\\Controller\\InputsFarmDeliveryPlanController'] = $instance = new \App\Controller\InputsFarmDeliveryPlanController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\InputsFarmDeliveryPlanController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\LightingController' shared autowired service.
     *
     * @return \App\Controller\LightingController
     */
    protected function getLightingControllerService()
    {
        $this->services['App\\Controller\\LightingController'] = $instance = new \App\Controller\LightingController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\LightingController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanBreederController' shared autowired service.
     *
     * @return \App\Controller\PlanBreederController
     */
    protected function getPlanBreederControllerService()
    {
        $this->services['App\\Controller\\PlanBreederController'] = $instance = new \App\Controller\PlanBreederController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanBreederController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanController' shared autowired service.
     *
     * @return \App\Controller\PlanController
     */
    protected function getPlanControllerService()
    {
        $this->services['App\\Controller\\PlanController'] = $instance = new \App\Controller\PlanController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanDeliveryChickController' shared autowired service.
     *
     * @return \App\Controller\PlanDeliveryChickController
     */
    protected function getPlanDeliveryChickControllerService()
    {
        $this->services['App\\Controller\\PlanDeliveryChickController'] = $instance = new \App\Controller\PlanDeliveryChickController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanDeliveryChickController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanDeliveryEggController' shared autowired service.
     *
     * @return \App\Controller\PlanDeliveryEggController
     */
    protected function getPlanDeliveryEggControllerService()
    {
        $this->services['App\\Controller\\PlanDeliveryEggController'] = $instance = new \App\Controller\PlanDeliveryEggController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanDeliveryEggController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanDetailController' shared autowired service.
     *
     * @return \App\Controller\PlanDetailController
     */
    protected function getPlanDetailControllerService()
    {
        $this->services['App\\Controller\\PlanDetailController'] = $instance = new \App\Controller\PlanDetailController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanDetailController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanHatchingDateController' shared autowired service.
     *
     * @return \App\Controller\PlanHatchingDateController
     */
    protected function getPlanHatchingDateControllerService()
    {
        $this->services['App\\Controller\\PlanHatchingDateController'] = $instance = new \App\Controller\PlanHatchingDateController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanHatchingDateController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanIndicatorsController' shared autowired service.
     *
     * @return \App\Controller\PlanIndicatorsController
     */
    protected function getPlanIndicatorsControllerService()
    {
        $this->services['App\\Controller\\PlanIndicatorsController'] = $instance = new \App\Controller\PlanIndicatorsController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanIndicatorsController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\PlanInputController' shared autowired service.
     *
     * @return \App\Controller\PlanInputController
     */
    protected function getPlanInputControllerService()
    {
        $this->services['App\\Controller\\PlanInputController'] = $instance = new \App\Controller\PlanInputController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\PlanInputController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\Production\ProductionChickTemperatureController' shared autowired service.
     *
     * @return \App\Controller\Production\ProductionChickTemperatureController
     */
    protected function getProductionChickTemperatureControllerService()
    {
        $this->services['App\\Controller\\Production\\ProductionChickTemperatureController'] = $instance = new \App\Controller\Production\ProductionChickTemperatureController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\Production\\ProductionChickTemperatureController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\Production\ProductionController' shared autowired service.
     *
     * @return \App\Controller\Production\ProductionController
     */
    protected function getProductionControllerService()
    {
        $this->services['App\\Controller\\Production\\ProductionController'] = $instance = new \App\Controller\Production\ProductionController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\Production\\ProductionController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\Production\ProductionDeliveryController' shared autowired service.
     *
     * @return \App\Controller\Production\ProductionDeliveryController
     */
    protected function getProductionDeliveryControllerService()
    {
        $this->services['App\\Controller\\Production\\ProductionDeliveryController'] = $instance = new \App\Controller\Production\ProductionDeliveryController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\Production\\ProductionDeliveryController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\Production\ProductionInputsController' shared autowired service.
     *
     * @return \App\Controller\Production\ProductionInputsController
     */
    protected function getProductionInputsControllerService()
    {
        $this->services['App\\Controller\\Production\\ProductionInputsController'] = $instance = new \App\Controller\Production\ProductionInputsController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\Production\\ProductionInputsController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\Production\ProductionLightingController' shared autowired service.
     *
     * @return \App\Controller\Production\ProductionLightingController
     */
    protected function getProductionLightingControllerService()
    {
        $this->services['App\\Controller\\Production\\ProductionLightingController'] = $instance = new \App\Controller\Production\ProductionLightingController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\Production\\ProductionLightingController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\Production\ProductionSelectionController' shared autowired service.
     *
     * @return \App\Controller\Production\ProductionSelectionController
     */
    protected function getProductionSelectionControllerService()
    {
        $this->services['App\\Controller\\Production\\ProductionSelectionController'] = $instance = new \App\Controller\Production\ProductionSelectionController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\Production\\ProductionSelectionController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\Production\ProductionTransferController' shared autowired service.
     *
     * @return \App\Controller\Production\ProductionTransferController
     */
    protected function getProductionTransferControllerService()
    {
        $this->services['App\\Controller\\Production\\ProductionTransferController'] = $instance = new \App\Controller\Production\ProductionTransferController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\Production\\ProductionTransferController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\RegistrationController' shared autowired service.
     *
     * @return \App\Controller\RegistrationController
     */
    protected function getRegistrationControllerService()
    {
        $this->services['App\\Controller\\RegistrationController'] = $instance = new \App\Controller\RegistrationController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\RegistrationController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\ResetPasswordController' shared autowired service.
     *
     * @return \App\Controller\ResetPasswordController
     */
    protected function getResetPasswordControllerService()
    {
        $this->services['App\\Controller\\ResetPasswordController'] = $instance = new \App\Controller\ResetPasswordController(new \SymfonyCasts\Bundle\ResetPassword\ResetPasswordHelper(new \SymfonyCasts\Bundle\ResetPassword\Generator\ResetPasswordTokenGenerator($this->getEnv('APP_SECRET'), new \SymfonyCasts\Bundle\ResetPassword\Generator\ResetPasswordRandomGenerator()), ($this->privates['symfonycasts.reset_password.cleaner'] ?? $this->getSymfonycasts_ResetPassword_CleanerService()), ($this->privates['App\\Repository\\ResetPasswordRequestRepository'] ?? $this->getResetPasswordRequestRepositoryService()), 3600, 5));

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\ResetPasswordController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\SecurityController' shared autowired service.
     *
     * @return \App\Controller\SecurityController
     */
    protected function getSecurityControllerService()
    {
        $this->services['App\\Controller\\SecurityController'] = $instance = new \App\Controller\SecurityController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\SecurityController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\SelectionsController' shared autowired service.
     *
     * @return \App\Controller\SelectionsController
     */
    protected function getSelectionsControllerService()
    {
        $this->services['App\\Controller\\SelectionsController'] = $instance = new \App\Controller\SelectionsController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\SelectionsController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\SellingEggController' shared autowired service.
     *
     * @return \App\Controller\SellingEggController
     */
    protected function getSellingEggControllerService()
    {
        $this->services['App\\Controller\\SellingEggController'] = $instance = new \App\Controller\SellingEggController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\SellingEggController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\SettersController' shared autowired service.
     *
     * @return \App\Controller\SettersController
     */
    protected function getSettersControllerService()
    {
        $this->services['App\\Controller\\SettersController'] = $instance = new \App\Controller\SettersController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\SettersController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\SupplierController' shared autowired service.
     *
     * @return \App\Controller\SupplierController
     */
    protected function getSupplierControllerService()
    {
        $this->services['App\\Controller\\SupplierController'] = $instance = new \App\Controller\SupplierController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\SupplierController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\TransfersController' shared autowired service.
     *
     * @return \App\Controller\TransfersController
     */
    protected function getTransfersControllerService()
    {
        $this->services['App\\Controller\\TransfersController'] = $instance = new \App\Controller\TransfersController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\TransfersController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\TransportListController' shared autowired service.
     *
     * @return \App\Controller\TransportListController
     */
    protected function getTransportListControllerService()
    {
        $this->services['App\\Controller\\TransportListController'] = $instance = new \App\Controller\TransportListController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\TransportListController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\UserController' shared autowired service.
     *
     * @return \App\Controller\UserController
     */
    protected function getUserControllerService()
    {
        $this->services['App\\Controller\\UserController'] = $instance = new \App\Controller\UserController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\UserController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Controller\VaccinationController' shared autowired service.
     *
     * @return \App\Controller\VaccinationController
     */
    protected function getVaccinationControllerService()
    {
        $this->services['App\\Controller\\VaccinationController'] = $instance = new \App\Controller\VaccinationController();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Controller\\VaccinationController', $this));

        return $instance;
    }

    /*
     * Gets the public 'App\Security\AccessDeniedHandler' shared autowired service.
     *
     * @return \App\Security\AccessDeniedHandler
     */
    protected function getAccessDeniedHandlerService()
    {
        $this->services['App\\Security\\AccessDeniedHandler'] = $instance = new \App\Security\AccessDeniedHandler();

        $instance->setContainer(($this->privates['.service_locator.vdmMuyE'] ?? $this->get_ServiceLocator_VdmMuyEService())->withContext('App\\Security\\AccessDeniedHandler', $this));

        return $instance;
    }

    /*
     * Gets the public 'DH\AuditorBundle\Controller\ViewerController' shared service.
     *
     * @return \DH\AuditorBundle\Controller\ViewerController
     */
    protected function getViewerControllerService()
    {
        $this->services['DH\\AuditorBundle\\Controller\\ViewerController'] = $instance = new \DH\AuditorBundle\Controller\ViewerController(($this->services['twig'] ?? $this->getTwigService()));

        $instance->setContainer($this);

        return $instance;
    }

    /*
     * Gets the public 'Symfony\Bundle\FrameworkBundle\Controller\RedirectController' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Controller\RedirectController
     */
    protected function getRedirectControllerService()
    {
        return $this->services['Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController'] = new \Symfony\Bundle\FrameworkBundle\Controller\RedirectController(($this->services['router'] ?? $this->getRouterService()), 80, 443);
    }

    /*
     * Gets the public 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Controller\TemplateController
     */
    protected function getTemplateControllerService()
    {
        return $this->services['Symfony\\Bundle\\FrameworkBundle\\Controller\\TemplateController'] = new \Symfony\Bundle\FrameworkBundle\Controller\TemplateController(($this->services['twig'] ?? $this->getTwigService()), NULL);
    }

    /*
     * Gets the public 'cache.app' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\FilesystemAdapter
     */
    protected function getCache_AppService()
    {
        $this->services['cache.app'] = $instance = new \Symfony\Component\Cache\Adapter\FilesystemAdapter('mWAMu7XNwT', 0, ($this->targetDir.''.'/pools'), ($this->privates['cache.default_marshaller'] ?? ($this->privates['cache.default_marshaller'] = new \Symfony\Component\Cache\Marshaller\DefaultMarshaller(NULL))));

        $instance->setLogger(($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));

        return $instance;
    }

    /*
     * Gets the public 'cache.app_clearer' shared service.
     *
     * @return \Symfony\Component\HttpKernel\CacheClearer\Psr6CacheClearer
     */
    protected function getCache_AppClearerService()
    {
        return $this->services['cache.app_clearer'] = new \Symfony\Component\HttpKernel\CacheClearer\Psr6CacheClearer(['cache.app' => ($this->services['cache.app'] ?? $this->getCache_AppService()), 'doctrine.result_cache_pool' => ($this->privates['doctrine.result_cache_pool'] ?? $this->getDoctrine_ResultCachePoolService())]);
    }

    /*
     * Gets the public 'cache.global_clearer' shared service.
     *
     * @return \Symfony\Component\HttpKernel\CacheClearer\Psr6CacheClearer
     */
    protected function getCache_GlobalClearerService()
    {
        return $this->services['cache.global_clearer'] = new \Symfony\Component\HttpKernel\CacheClearer\Psr6CacheClearer(['cache.app' => ($this->services['cache.app'] ?? $this->getCache_AppService()), 'cache.system' => ($this->services['cache.system'] ?? $this->getCache_SystemService()), 'cache.validator' => ($this->privates['cache.validator'] ?? $this->getCache_ValidatorService()), 'cache.serializer' => ($this->privates['cache.serializer'] ?? $this->getCache_SerializerService()), 'cache.annotations' => ($this->privates['cache.annotations'] ?? $this->getCache_AnnotationsService()), 'cache.property_info' => ($this->privates['cache.property_info'] ?? $this->getCache_PropertyInfoService()), 'doctrine.result_cache_pool' => ($this->privates['doctrine.result_cache_pool'] ?? $this->getDoctrine_ResultCachePoolService()), 'doctrine.system_cache_pool' => ($this->privates['doctrine.system_cache_pool'] ?? $this->getDoctrine_SystemCachePoolService()), 'cache.property_access' => ($this->privates['cache.property_access'] ?? $this->getCache_PropertyAccessService()), 'cache.security_expression_language' => ($this->privates['cache.security_expression_language'] ?? $this->getCache_SecurityExpressionLanguageService())]);
    }

    /*
     * Gets the public 'cache.system' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getCache_SystemService()
    {
        return $this->services['cache.system'] = \Symfony\Component\Cache\Adapter\AbstractAdapter::createSystemCache('Hu262GBkxt', 0, $this->getParameter('container.build_id'), ($this->targetDir.''.'/pools'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the public 'cache.system_clearer' shared service.
     *
     * @return \Symfony\Component\HttpKernel\CacheClearer\Psr6CacheClearer
     */
    protected function getCache_SystemClearerService()
    {
        return $this->services['cache.system_clearer'] = new \Symfony\Component\HttpKernel\CacheClearer\Psr6CacheClearer(['cache.system' => ($this->services['cache.system'] ?? $this->getCache_SystemService()), 'cache.validator' => ($this->privates['cache.validator'] ?? $this->getCache_ValidatorService()), 'cache.serializer' => ($this->privates['cache.serializer'] ?? $this->getCache_SerializerService()), 'cache.annotations' => ($this->privates['cache.annotations'] ?? $this->getCache_AnnotationsService()), 'cache.property_info' => ($this->privates['cache.property_info'] ?? $this->getCache_PropertyInfoService()), 'doctrine.system_cache_pool' => ($this->privates['doctrine.system_cache_pool'] ?? $this->getDoctrine_SystemCachePoolService()), 'cache.property_access' => ($this->privates['cache.property_access'] ?? $this->getCache_PropertyAccessService()), 'cache.security_expression_language' => ($this->privates['cache.security_expression_language'] ?? $this->getCache_SecurityExpressionLanguageService())]);
    }

    /*
     * Gets the public 'cache_clearer' shared service.
     *
     * @return \Symfony\Component\HttpKernel\CacheClearer\ChainCacheClearer
     */
    protected function getCacheClearerService()
    {
        return $this->services['cache_clearer'] = new \Symfony\Component\HttpKernel\CacheClearer\ChainCacheClearer(new RewindableGenerator(function () {
            yield 0 => ($this->services['cache.system_clearer'] ?? $this->getCache_SystemClearerService());
        }, 1));
    }

    /*
     * Gets the public 'cache_warmer' shared service.
     *
     * @return \Symfony\Component\HttpKernel\CacheWarmer\CacheWarmerAggregate
     */
    protected function getCacheWarmerService()
    {
        return $this->services['cache_warmer'] = new \Symfony\Component\HttpKernel\CacheWarmer\CacheWarmerAggregate(new RewindableGenerator(function () {
            yield 0 => ($this->privates['doctrine.orm.default_metadata_cache_warmer'] ?? $this->getDoctrine_Orm_DefaultMetadataCacheWarmerService());
            yield 1 => ($this->privates['validator.mapping.cache_warmer'] ?? $this->getValidator_Mapping_CacheWarmerService());
            yield 2 => ($this->privates['translation.warmer'] ?? $this->getTranslation_WarmerService());
            yield 3 => ($this->privates['router.cache_warmer'] ?? $this->getRouter_CacheWarmerService());
            yield 4 => ($this->privates['annotations.cache_warmer'] ?? $this->getAnnotations_CacheWarmerService());
            yield 5 => ($this->privates['serializer.mapping.cache_warmer'] ?? $this->getSerializer_Mapping_CacheWarmerService());
            yield 6 => ($this->privates['twig.template_cache_warmer'] ?? $this->getTwig_TemplateCacheWarmerService());
            yield 7 => ($this->privates['doctrine.orm.proxy_cache_warmer'] ?? $this->getDoctrine_Orm_ProxyCacheWarmerService());
        }, 8), false, ($this->targetDir.''.'/srcApp_KernelProdContainerDeprecations.log'));
    }

    /*
     * Gets the public 'console.command_loader' shared service.
     *
     * @return \Symfony\Component\Console\CommandLoader\ContainerCommandLoader
     */
    protected function getConsole_CommandLoaderService()
    {
        return $this->services['console.command_loader'] = new \Symfony\Component\Console\CommandLoader\ContainerCommandLoader(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\CleanAuditLogsCommand' => ['privates', 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\CleanAuditLogsCommand', 'getCleanAuditLogsCommandService', false],
            'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\UpdateSchemaCommand' => ['privates', 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\UpdateSchemaCommand', 'getUpdateSchemaCommandService', false],
            'Doctrine\\DBAL\\Tools\\Console\\Command\\RunSqlCommand' => ['privates', 'Doctrine\\DBAL\\Tools\\Console\\Command\\RunSqlCommand', 'getRunSqlCommandService', false],
            'SymfonyCasts\\Bundle\\ResetPassword\\Command\\ResetPasswordRemoveExpiredCommand' => ['privates', 'SymfonyCasts\\Bundle\\ResetPassword\\Command\\ResetPasswordRemoveExpiredCommand', 'getResetPasswordRemoveExpiredCommandService', false],
            'console.command.about' => ['privates', 'console.command.about', 'getConsole_Command_AboutService', false],
            'console.command.assets_install' => ['privates', 'console.command.assets_install', 'getConsole_Command_AssetsInstallService', false],
            'console.command.cache_clear' => ['privates', 'console.command.cache_clear', 'getConsole_Command_CacheClearService', false],
            'console.command.cache_pool_clear' => ['privates', 'console.command.cache_pool_clear', 'getConsole_Command_CachePoolClearService', false],
            'console.command.cache_pool_delete' => ['privates', 'console.command.cache_pool_delete', 'getConsole_Command_CachePoolDeleteService', false],
            'console.command.cache_pool_list' => ['privates', 'console.command.cache_pool_list', 'getConsole_Command_CachePoolListService', false],
            'console.command.cache_pool_prune' => ['privates', 'console.command.cache_pool_prune', 'getConsole_Command_CachePoolPruneService', false],
            'console.command.cache_warmup' => ['privates', 'console.command.cache_warmup', 'getConsole_Command_CacheWarmupService', false],
            'console.command.config_debug' => ['privates', 'console.command.config_debug', 'getConsole_Command_ConfigDebugService', false],
            'console.command.config_dump_reference' => ['privates', 'console.command.config_dump_reference', 'getConsole_Command_ConfigDumpReferenceService', false],
            'console.command.container_debug' => ['privates', 'console.command.container_debug', 'getConsole_Command_ContainerDebugService', false],
            'console.command.container_lint' => ['privates', 'console.command.container_lint', 'getConsole_Command_ContainerLintService', false],
            'console.command.debug_autowiring' => ['privates', 'console.command.debug_autowiring', 'getConsole_Command_DebugAutowiringService', false],
            'console.command.event_dispatcher_debug' => ['privates', 'console.command.event_dispatcher_debug', 'getConsole_Command_EventDispatcherDebugService', false],
            'console.command.form_debug' => ['privates', 'console.command.form_debug', 'getConsole_Command_FormDebugService', false],
            'console.command.router_debug' => ['privates', 'console.command.router_debug', 'getConsole_Command_RouterDebugService', false],
            'console.command.router_match' => ['privates', 'console.command.router_match', 'getConsole_Command_RouterMatchService', false],
            'console.command.secrets_decrypt_to_local' => ['privates', 'console.command.secrets_decrypt_to_local', 'getConsole_Command_SecretsDecryptToLocalService', false],
            'console.command.secrets_encrypt_from_local' => ['privates', 'console.command.secrets_encrypt_from_local', 'getConsole_Command_SecretsEncryptFromLocalService', false],
            'console.command.secrets_generate_key' => ['privates', 'console.command.secrets_generate_key', 'getConsole_Command_SecretsGenerateKeyService', false],
            'console.command.secrets_list' => ['privates', 'console.command.secrets_list', 'getConsole_Command_SecretsListService', false],
            'console.command.secrets_remove' => ['privates', 'console.command.secrets_remove', 'getConsole_Command_SecretsRemoveService', false],
            'console.command.secrets_set' => ['privates', 'console.command.secrets_set', 'getConsole_Command_SecretsSetService', false],
            'console.command.translation_debug' => ['privates', 'console.command.translation_debug', 'getConsole_Command_TranslationDebugService', false],
            'console.command.translation_update' => ['privates', 'console.command.translation_update', 'getConsole_Command_TranslationUpdateService', false],
            'console.command.xliff_lint' => ['privates', 'console.command.xliff_lint', 'getConsole_Command_XliffLintService', false],
            'console.command.yaml_lint' => ['privates', 'console.command.yaml_lint', 'getConsole_Command_YamlLintService', false],
            'doctrine.cache_clear_metadata_command' => ['privates', 'doctrine.cache_clear_metadata_command', 'getDoctrine_CacheClearMetadataCommandService', false],
            'doctrine.cache_clear_query_cache_command' => ['privates', 'doctrine.cache_clear_query_cache_command', 'getDoctrine_CacheClearQueryCacheCommandService', false],
            'doctrine.cache_clear_result_command' => ['privates', 'doctrine.cache_clear_result_command', 'getDoctrine_CacheClearResultCommandService', false],
            'doctrine.cache_collection_region_command' => ['privates', 'doctrine.cache_collection_region_command', 'getDoctrine_CacheCollectionRegionCommandService', false],
            'doctrine.clear_entity_region_command' => ['privates', 'doctrine.clear_entity_region_command', 'getDoctrine_ClearEntityRegionCommandService', false],
            'doctrine.clear_query_region_command' => ['privates', 'doctrine.clear_query_region_command', 'getDoctrine_ClearQueryRegionCommandService', false],
            'doctrine.database_create_command' => ['privates', 'doctrine.database_create_command', 'getDoctrine_DatabaseCreateCommandService', false],
            'doctrine.database_drop_command' => ['privates', 'doctrine.database_drop_command', 'getDoctrine_DatabaseDropCommandService', false],
            'doctrine.database_import_command' => ['privates', 'doctrine.database_import_command', 'getDoctrine_DatabaseImportCommandService', false],
            'doctrine.ensure_production_settings_command' => ['privates', 'doctrine.ensure_production_settings_command', 'getDoctrine_EnsureProductionSettingsCommandService', false],
            'doctrine.mapping_convert_command' => ['privates', 'doctrine.mapping_convert_command', 'getDoctrine_MappingConvertCommandService', false],
            'doctrine.mapping_import_command' => ['privates', 'doctrine.mapping_import_command', 'getDoctrine_MappingImportCommandService', false],
            'doctrine.mapping_info_command' => ['privates', 'doctrine.mapping_info_command', 'getDoctrine_MappingInfoCommandService', false],
            'doctrine.query_dql_command' => ['privates', 'doctrine.query_dql_command', 'getDoctrine_QueryDqlCommandService', false],
            'doctrine.query_sql_command' => ['privates', 'doctrine.query_sql_command', 'getDoctrine_QuerySqlCommandService', false],
            'doctrine.schema_create_command' => ['privates', 'doctrine.schema_create_command', 'getDoctrine_SchemaCreateCommandService', false],
            'doctrine.schema_drop_command' => ['privates', 'doctrine.schema_drop_command', 'getDoctrine_SchemaDropCommandService', false],
            'doctrine.schema_update_command' => ['privates', 'doctrine.schema_update_command', 'getDoctrine_SchemaUpdateCommandService', false],
            'doctrine.schema_validate_command' => ['privates', 'doctrine.schema_validate_command', 'getDoctrine_SchemaValidateCommandService', false],
            'doctrine_migrations.current_command' => ['privates', 'doctrine_migrations.current_command', 'getDoctrineMigrations_CurrentCommandService', false],
            'doctrine_migrations.diff_command' => ['privates', 'doctrine_migrations.diff_command', 'getDoctrineMigrations_DiffCommandService', false],
            'doctrine_migrations.dump_schema_command' => ['privates', 'doctrine_migrations.dump_schema_command', 'getDoctrineMigrations_DumpSchemaCommandService', false],
            'doctrine_migrations.execute_command' => ['privates', 'doctrine_migrations.execute_command', 'getDoctrineMigrations_ExecuteCommandService', false],
            'doctrine_migrations.generate_command' => ['privates', 'doctrine_migrations.generate_command', 'getDoctrineMigrations_GenerateCommandService', false],
            'doctrine_migrations.latest_command' => ['privates', 'doctrine_migrations.latest_command', 'getDoctrineMigrations_LatestCommandService', false],
            'doctrine_migrations.migrate_command' => ['privates', 'doctrine_migrations.migrate_command', 'getDoctrineMigrations_MigrateCommandService', false],
            'doctrine_migrations.rollup_command' => ['privates', 'doctrine_migrations.rollup_command', 'getDoctrineMigrations_RollupCommandService', false],
            'doctrine_migrations.status_command' => ['privates', 'doctrine_migrations.status_command', 'getDoctrineMigrations_StatusCommandService', false],
            'doctrine_migrations.sync_metadata_command' => ['privates', 'doctrine_migrations.sync_metadata_command', 'getDoctrineMigrations_SyncMetadataCommandService', false],
            'doctrine_migrations.up_to_date_command' => ['privates', 'doctrine_migrations.up_to_date_command', 'getDoctrineMigrations_UpToDateCommandService', false],
            'doctrine_migrations.version_command' => ['privates', 'doctrine_migrations.version_command', 'getDoctrineMigrations_VersionCommandService', false],
            'doctrine_migrations.versions_command' => ['privates', 'doctrine_migrations.versions_command', 'getDoctrineMigrations_VersionsCommandService', false],
            'security.command.user_password_encoder' => ['privates', 'security.command.user_password_encoder', 'getSecurity_Command_UserPasswordEncoderService', false],
            'swiftmailer.command.debug' => ['privates', 'swiftmailer.command.debug', 'getSwiftmailer_Command_DebugService', false],
            'swiftmailer.command.new_email' => ['privates', 'swiftmailer.command.new_email', 'getSwiftmailer_Command_NewEmailService', false],
            'swiftmailer.command.send_email' => ['privates', 'swiftmailer.command.send_email', 'getSwiftmailer_Command_SendEmailService', false],
            'twig.command.debug' => ['privates', 'twig.command.debug', 'getTwig_Command_DebugService', false],
            'twig.command.lint' => ['privates', 'twig.command.lint', 'getTwig_Command_LintService', false],
        ], [
            'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\CleanAuditLogsCommand' => 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\CleanAuditLogsCommand',
            'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\UpdateSchemaCommand' => 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\UpdateSchemaCommand',
            'Doctrine\\DBAL\\Tools\\Console\\Command\\RunSqlCommand' => 'Doctrine\\DBAL\\Tools\\Console\\Command\\RunSqlCommand',
            'SymfonyCasts\\Bundle\\ResetPassword\\Command\\ResetPasswordRemoveExpiredCommand' => 'SymfonyCasts\\Bundle\\ResetPassword\\Command\\ResetPasswordRemoveExpiredCommand',
            'console.command.about' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\AboutCommand',
            'console.command.assets_install' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\AssetsInstallCommand',
            'console.command.cache_clear' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\CacheClearCommand',
            'console.command.cache_pool_clear' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\CachePoolClearCommand',
            'console.command.cache_pool_delete' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\CachePoolDeleteCommand',
            'console.command.cache_pool_list' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\CachePoolListCommand',
            'console.command.cache_pool_prune' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\CachePoolPruneCommand',
            'console.command.cache_warmup' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\CacheWarmupCommand',
            'console.command.config_debug' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\ConfigDebugCommand',
            'console.command.config_dump_reference' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\ConfigDumpReferenceCommand',
            'console.command.container_debug' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\ContainerDebugCommand',
            'console.command.container_lint' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\ContainerLintCommand',
            'console.command.debug_autowiring' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\DebugAutowiringCommand',
            'console.command.event_dispatcher_debug' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\EventDispatcherDebugCommand',
            'console.command.form_debug' => 'Symfony\\Component\\Form\\Command\\DebugCommand',
            'console.command.router_debug' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\RouterDebugCommand',
            'console.command.router_match' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\RouterMatchCommand',
            'console.command.secrets_decrypt_to_local' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\SecretsDecryptToLocalCommand',
            'console.command.secrets_encrypt_from_local' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\SecretsEncryptFromLocalCommand',
            'console.command.secrets_generate_key' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\SecretsGenerateKeysCommand',
            'console.command.secrets_list' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\SecretsListCommand',
            'console.command.secrets_remove' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\SecretsRemoveCommand',
            'console.command.secrets_set' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\SecretsSetCommand',
            'console.command.translation_debug' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\TranslationDebugCommand',
            'console.command.translation_update' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\TranslationUpdateCommand',
            'console.command.xliff_lint' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\XliffLintCommand',
            'console.command.yaml_lint' => 'Symfony\\Bundle\\FrameworkBundle\\Command\\YamlLintCommand',
            'doctrine.cache_clear_metadata_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\ClearMetadataCacheDoctrineCommand',
            'doctrine.cache_clear_query_cache_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\ClearQueryCacheDoctrineCommand',
            'doctrine.cache_clear_result_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\ClearResultCacheDoctrineCommand',
            'doctrine.cache_collection_region_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\CollectionRegionDoctrineCommand',
            'doctrine.clear_entity_region_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\EntityRegionCacheDoctrineCommand',
            'doctrine.clear_query_region_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\QueryRegionCacheDoctrineCommand',
            'doctrine.database_create_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\CreateDatabaseDoctrineCommand',
            'doctrine.database_drop_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\DropDatabaseDoctrineCommand',
            'doctrine.database_import_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\ImportDoctrineCommand',
            'doctrine.ensure_production_settings_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\EnsureProductionSettingsDoctrineCommand',
            'doctrine.mapping_convert_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\ConvertMappingDoctrineCommand',
            'doctrine.mapping_import_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\ImportMappingDoctrineCommand',
            'doctrine.mapping_info_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\InfoDoctrineCommand',
            'doctrine.query_dql_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\RunDqlDoctrineCommand',
            'doctrine.query_sql_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\RunSqlDoctrineCommand',
            'doctrine.schema_create_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\CreateSchemaDoctrineCommand',
            'doctrine.schema_drop_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\DropSchemaDoctrineCommand',
            'doctrine.schema_update_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\UpdateSchemaDoctrineCommand',
            'doctrine.schema_validate_command' => 'Doctrine\\Bundle\\DoctrineBundle\\Command\\Proxy\\ValidateSchemaCommand',
            'doctrine_migrations.current_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\CurrentCommand',
            'doctrine_migrations.diff_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\DiffCommand',
            'doctrine_migrations.dump_schema_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\DumpSchemaCommand',
            'doctrine_migrations.execute_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\ExecuteCommand',
            'doctrine_migrations.generate_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\GenerateCommand',
            'doctrine_migrations.latest_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\LatestCommand',
            'doctrine_migrations.migrate_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\MigrateCommand',
            'doctrine_migrations.rollup_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\RollupCommand',
            'doctrine_migrations.status_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\StatusCommand',
            'doctrine_migrations.sync_metadata_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\SyncMetadataCommand',
            'doctrine_migrations.up_to_date_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\UpToDateCommand',
            'doctrine_migrations.version_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\VersionCommand',
            'doctrine_migrations.versions_command' => 'Doctrine\\Migrations\\Tools\\Console\\Command\\ListCommand',
            'security.command.user_password_encoder' => 'Symfony\\Bundle\\SecurityBundle\\Command\\UserPasswordEncoderCommand',
            'swiftmailer.command.debug' => 'Symfony\\Bundle\\SwiftmailerBundle\\Command\\DebugCommand',
            'swiftmailer.command.new_email' => 'Symfony\\Bundle\\SwiftmailerBundle\\Command\\NewEmailCommand',
            'swiftmailer.command.send_email' => 'Symfony\\Bundle\\SwiftmailerBundle\\Command\\SendEmailCommand',
            'twig.command.debug' => 'Symfony\\Bridge\\Twig\\Command\\DebugCommand',
            'twig.command.lint' => 'Symfony\\Bundle\\TwigBundle\\Command\\LintCommand',
        ]), ['about' => 'console.command.about', 'assets:install' => 'console.command.assets_install', 'cache:clear' => 'console.command.cache_clear', 'cache:pool:clear' => 'console.command.cache_pool_clear', 'cache:pool:prune' => 'console.command.cache_pool_prune', 'cache:pool:delete' => 'console.command.cache_pool_delete', 'cache:pool:list' => 'console.command.cache_pool_list', 'cache:warmup' => 'console.command.cache_warmup', 'debug:config' => 'console.command.config_debug', 'config:dump-reference' => 'console.command.config_dump_reference', 'debug:container' => 'console.command.container_debug', 'lint:container' => 'console.command.container_lint', 'debug:autowiring' => 'console.command.debug_autowiring', 'debug:event-dispatcher' => 'console.command.event_dispatcher_debug', 'debug:router' => 'console.command.router_debug', 'router:match' => 'console.command.router_match', 'debug:translation' => 'console.command.translation_debug', 'translation:update' => 'console.command.translation_update', 'lint:xliff' => 'console.command.xliff_lint', 'lint:yaml' => 'console.command.yaml_lint', 'debug:form' => 'console.command.form_debug', 'secrets:set' => 'console.command.secrets_set', 'secrets:remove' => 'console.command.secrets_remove', 'secrets:generate-keys' => 'console.command.secrets_generate_key', 'secrets:list' => 'console.command.secrets_list', 'secrets:decrypt-to-local' => 'console.command.secrets_decrypt_to_local', 'secrets:encrypt-from-local' => 'console.command.secrets_encrypt_from_local', 'debug:twig' => 'twig.command.debug', 'lint:twig' => 'twig.command.lint', 'doctrine:database:create' => 'doctrine.database_create_command', 'doctrine:database:drop' => 'doctrine.database_drop_command', 'doctrine:query:sql' => 'doctrine.query_sql_command', 'dbal:run-sql' => 'Doctrine\\DBAL\\Tools\\Console\\Command\\RunSqlCommand', 'doctrine:database:import' => 'doctrine.database_import_command', 'doctrine:cache:clear-metadata' => 'doctrine.cache_clear_metadata_command', 'doctrine:cache:clear-query' => 'doctrine.cache_clear_query_cache_command', 'doctrine:cache:clear-result' => 'doctrine.cache_clear_result_command', 'doctrine:cache:clear-collection-region' => 'doctrine.cache_collection_region_command', 'doctrine:mapping:convert' => 'doctrine.mapping_convert_command', 'doctrine:schema:create' => 'doctrine.schema_create_command', 'doctrine:schema:drop' => 'doctrine.schema_drop_command', 'doctrine:ensure-production-settings' => 'doctrine.ensure_production_settings_command', 'doctrine:cache:clear-entity-region' => 'doctrine.clear_entity_region_command', 'doctrine:mapping:info' => 'doctrine.mapping_info_command', 'doctrine:cache:clear-query-region' => 'doctrine.clear_query_region_command', 'doctrine:query:dql' => 'doctrine.query_dql_command', 'doctrine:schema:update' => 'doctrine.schema_update_command', 'doctrine:schema:validate' => 'doctrine.schema_validate_command', 'doctrine:mapping:import' => 'doctrine.mapping_import_command', 'doctrine:migrations:diff' => 'doctrine_migrations.diff_command', 'doctrine:migrations:sync-metadata-storage' => 'doctrine_migrations.sync_metadata_command', 'doctrine:migrations:list' => 'doctrine_migrations.versions_command', 'doctrine:migrations:current' => 'doctrine_migrations.current_command', 'doctrine:migrations:dump-schema' => 'doctrine_migrations.dump_schema_command', 'doctrine:migrations:execute' => 'doctrine_migrations.execute_command', 'doctrine:migrations:generate' => 'doctrine_migrations.generate_command', 'doctrine:migrations:latest' => 'doctrine_migrations.latest_command', 'doctrine:migrations:migrate' => 'doctrine_migrations.migrate_command', 'doctrine:migrations:rollup' => 'doctrine_migrations.rollup_command', 'doctrine:migrations:status' => 'doctrine_migrations.status_command', 'doctrine:migrations:up-to-date' => 'doctrine_migrations.up_to_date_command', 'doctrine:migrations:version' => 'doctrine_migrations.version_command', 'security:encode-password' => 'security.command.user_password_encoder', 'reset-password:remove-expired' => 'SymfonyCasts\\Bundle\\ResetPassword\\Command\\ResetPasswordRemoveExpiredCommand', 'debug:swiftmailer' => 'swiftmailer.command.debug', 'swiftmailer:email:send' => 'swiftmailer.command.new_email', 'swiftmailer:spool:send' => 'swiftmailer.command.send_email', 'audit:clean' => 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\CleanAuditLogsCommand', 'audit:schema:update' => 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\UpdateSchemaCommand']);
    }

    /*
     * Gets the public 'container.env_var_processors_locator' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function getContainer_EnvVarProcessorsLocatorService()
    {
        return $this->services['container.env_var_processors_locator'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'base64' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'bool' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'const' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'csv' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'default' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'file' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'float' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'int' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'json' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'key' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'query_string' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'require' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'resolve' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'string' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'trim' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
            'url' => ['privates', 'container.env_var_processor', 'getContainer_EnvVarProcessorService', false],
        ], [
            'base64' => '?',
            'bool' => '?',
            'const' => '?',
            'csv' => '?',
            'default' => '?',
            'file' => '?',
            'float' => '?',
            'int' => '?',
            'json' => '?',
            'key' => '?',
            'query_string' => '?',
            'require' => '?',
            'resolve' => '?',
            'string' => '?',
            'trim' => '?',
            'url' => '?',
        ]);
    }

    /*
     * Gets the public 'doctrine' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Registry
     */
    protected function getDoctrineService()
    {
        return $this->services['doctrine'] = new \Doctrine\Bundle\DoctrineBundle\Registry($this, $this->parameters['doctrine.connections'], $this->parameters['doctrine.entity_managers'], 'default', 'default');
    }

    /*
     * Gets the public 'doctrine.dbal.default_connection' shared service.
     *
     * @return \Doctrine\DBAL\Connection
     */
    protected function getDoctrine_Dbal_DefaultConnectionService()
    {
        $a = new \Symfony\Bridge\Doctrine\ContainerAwareEventManager(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Event\\CreateSchemaListener' => ['privates', 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Event\\CreateSchemaListener', 'getCreateSchemaListenerService', false],
            'doctrine.orm.default_listeners.attach_entity_listeners' => ['privates', 'doctrine.orm.default_listeners.attach_entity_listeners', 'getDoctrine_Orm_DefaultListeners_AttachEntityListenersService', false],
        ], [
            'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Event\\CreateSchemaListener' => '?',
            'doctrine.orm.default_listeners.attach_entity_listeners' => '?',
        ]), [0 => 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Event\\CreateSchemaListener']);
        $a->addEventListener([0 => 'loadClassMetadata'], 'doctrine.orm.default_listeners.attach_entity_listeners');

        return $this->services['doctrine.dbal.default_connection'] = (new \Doctrine\Bundle\DoctrineBundle\ConnectionFactory([]))->createConnection(['connection_override_options' => [], 'url' => $this->getEnv('resolve:DATABASE_URL'), 'driver' => 'pdo_mysql', 'host' => 'localhost', 'port' => NULL, 'user' => 'root', 'password' => NULL, 'driverOptions' => [], 'defaultTableOptions' => []], new \Doctrine\DBAL\Configuration(), $a, []);
    }

    /*
     * Gets the public 'doctrine.orm.default_entity_manager' shared service.
     *
     * @return \Doctrine\ORM\EntityManager
     */
    protected function getDoctrine_Orm_DefaultEntityManagerService($lazyLoad = true)
    {
        if ($lazyLoad) {
            return $this->services['doctrine.orm.default_entity_manager'] = $this->createProxy('EntityManager_9a5be93', function () {
                return \EntityManager_9a5be93::staticProxyConstructor(function (&$wrappedInstance, \ProxyManager\Proxy\LazyLoadingInterface $proxy) {
                    $wrappedInstance = $this->getDoctrine_Orm_DefaultEntityManagerService(false);

                    $proxy->setProxyInitializer(null);

                    return true;
                });
            });
        }

        $a = new \Doctrine\ORM\Configuration();

        $b = new \Symfony\Component\Cache\DoctrineProvider(($this->privates['doctrine.system_cache_pool'] ?? $this->getDoctrine_SystemCachePoolService()));
        $c = new \Doctrine\Persistence\Mapping\Driver\MappingDriverChain();
        $c->addDriver(new \Doctrine\ORM\Mapping\Driver\AnnotationDriver(($this->privates['annotations.cached_reader'] ?? $this->getAnnotations_CachedReaderService()), [0 => (\dirname(__DIR__, 4).'/src/Entity')]), 'App\\Entity');

        $a->setEntityNamespaces(['App' => 'App\\Entity']);
        $a->setMetadataCacheImpl(new \Symfony\Component\Cache\DoctrineProvider(new \Symfony\Component\Cache\Adapter\PhpArrayAdapter(($this->targetDir.''.'/doctrine/orm/default_metadata.php'), new \Symfony\Component\Cache\Adapter\DoctrineAdapter($b))));
        $a->setQueryCacheImpl($b);
        $a->setResultCacheImpl(new \Symfony\Component\Cache\DoctrineProvider(($this->privates['doctrine.result_cache_pool'] ?? $this->getDoctrine_ResultCachePoolService())));
        $a->setMetadataDriverImpl($c);
        $a->setProxyDir(($this->targetDir.''.'/doctrine/orm/Proxies'));
        $a->setProxyNamespace('Proxies');
        $a->setAutoGenerateProxyClasses(false);
        $a->setClassMetadataFactoryName('Doctrine\\ORM\\Mapping\\ClassMetadataFactory');
        $a->setDefaultRepositoryClassName('Doctrine\\ORM\\EntityRepository');
        $a->setNamingStrategy(new \Doctrine\ORM\Mapping\UnderscoreNamingStrategy(0, true));
        $a->setQuoteStrategy(new \Doctrine\ORM\Mapping\DefaultQuoteStrategy());
        $a->setEntityListenerResolver(new \Doctrine\Bundle\DoctrineBundle\Mapping\ContainerEntityListenerResolver($this));
        $a->setRepositoryFactory(new \Doctrine\Bundle\DoctrineBundle\Repository\ContainerRepositoryFactory(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'App\\Repository\\BreedRepository' => ['privates', 'App\\Repository\\BreedRepository', 'getBreedRepositoryService', false],
            'App\\Repository\\BreedStandardRepository' => ['privates', 'App\\Repository\\BreedStandardRepository', 'getBreedStandardRepositoryService', false],
            'App\\Repository\\CarRepository' => ['privates', 'App\\Repository\\CarRepository', 'getCarRepositoryService', false],
            'App\\Repository\\ChickIntegrationRepository' => ['privates', 'App\\Repository\\ChickIntegrationRepository', 'getChickIntegrationRepositoryService', false],
            'App\\Repository\\ChickTemperatureRepository' => ['privates', 'App\\Repository\\ChickTemperatureRepository', 'getChickTemperatureRepositoryService', false],
            'App\\Repository\\ChicksRecipientRepository' => ['privates', 'App\\Repository\\ChicksRecipientRepository', 'getChicksRecipientRepositoryService', false],
            'App\\Repository\\ConstantRepository' => ['privates', 'App\\Repository\\ConstantRepository', 'getConstantRepositoryService', false],
            'App\\Repository\\ContactInfoRepository' => ['privates', 'App\\Repository\\ContactInfoRepository', 'getContactInfoRepositoryService', false],
            'App\\Repository\\CustomerBuildingRepository' => ['privates', 'App\\Repository\\CustomerBuildingRepository', 'getCustomerBuildingRepositoryService', false],
            'App\\Repository\\CustomerRepository' => ['privates', 'App\\Repository\\CustomerRepository', 'getCustomerRepositoryService', false],
            'App\\Repository\\DeliveryRepository' => ['privates', 'App\\Repository\\DeliveryRepository', 'getDeliveryRepositoryService', false],
            'App\\Repository\\DriverRepository' => ['privates', 'App\\Repository\\DriverRepository', 'getDriverRepositoryService', false],
            'App\\Repository\\HatchersRepository' => ['privates', 'App\\Repository\\HatchersRepository', 'getHatchersRepositoryService', false],
            'App\\Repository\\HerdsRepository' => ['privates', 'App\\Repository\\HerdsRepository', 'getHerdsRepositoryService', false],
            'App\\Repository\\InputDeliveryRepository' => ['privates', 'App\\Repository\\InputDeliveryRepository', 'getInputDeliveryRepositoryService', false],
            'App\\Repository\\InputsFarmDeliveryPlanRepository' => ['privates', 'App\\Repository\\InputsFarmDeliveryPlanRepository', 'getInputsFarmDeliveryPlanRepositoryService', false],
            'App\\Repository\\InputsFarmRepository' => ['privates', 'App\\Repository\\InputsFarmRepository', 'getInputsFarmRepositoryService', false],
            'App\\Repository\\InputsRepository' => ['privates', 'App\\Repository\\InputsRepository', 'getInputsRepositoryService', false],
            'App\\Repository\\LightingRepository' => ['privates', 'App\\Repository\\LightingRepository', 'getLightingRepositoryService', false],
            'App\\Repository\\PlanDeliveryChickRepository' => ['privates', 'App\\Repository\\PlanDeliveryChickRepository', 'getPlanDeliveryChickRepositoryService', false],
            'App\\Repository\\PlanDeliveryEggRepository' => ['privates', 'App\\Repository\\PlanDeliveryEggRepository', 'getPlanDeliveryEggRepositoryService', false],
            'App\\Repository\\PlanIndicatorsRepository' => ['privates', 'App\\Repository\\PlanIndicatorsRepository', 'getPlanIndicatorsRepositoryService', false],
            'App\\Repository\\PlanInputRepository' => ['privates', 'App\\Repository\\PlanInputRepository', 'getPlanInputRepositoryService', false],
            'App\\Repository\\ResetPasswordRequestRepository' => ['privates', 'App\\Repository\\ResetPasswordRequestRepository', 'getResetPasswordRequestRepositoryService', false],
            'App\\Repository\\SelectionsRepository' => ['privates', 'App\\Repository\\SelectionsRepository', 'getSelectionsRepositoryService', false],
            'App\\Repository\\SellingEggRepository' => ['privates', 'App\\Repository\\SellingEggRepository', 'getSellingEggRepositoryService', false],
            'App\\Repository\\SettersRepository' => ['privates', 'App\\Repository\\SettersRepository', 'getSettersRepositoryService', false],
            'App\\Repository\\SupplierRepository' => ['privates', 'App\\Repository\\SupplierRepository', 'getSupplierRepositoryService', false],
            'App\\Repository\\TransfersRepository' => ['privates', 'App\\Repository\\TransfersRepository', 'getTransfersRepositoryService', false],
            'App\\Repository\\TransportListRepository' => ['privates', 'App\\Repository\\TransportListRepository', 'getTransportListRepositoryService', false],
            'App\\Repository\\UserRepository' => ['privates', 'App\\Repository\\UserRepository', 'getUserRepositoryService', false],
            'App\\Repository\\VaccinationRepository' => ['privates', 'App\\Repository\\VaccinationRepository', 'getVaccinationRepositoryService', false],
        ], [
            'App\\Repository\\BreedRepository' => '?',
            'App\\Repository\\BreedStandardRepository' => '?',
            'App\\Repository\\CarRepository' => '?',
            'App\\Repository\\ChickIntegrationRepository' => '?',
            'App\\Repository\\ChickTemperatureRepository' => '?',
            'App\\Repository\\ChicksRecipientRepository' => '?',
            'App\\Repository\\ConstantRepository' => '?',
            'App\\Repository\\ContactInfoRepository' => '?',
            'App\\Repository\\CustomerBuildingRepository' => '?',
            'App\\Repository\\CustomerRepository' => '?',
            'App\\Repository\\DeliveryRepository' => '?',
            'App\\Repository\\DriverRepository' => '?',
            'App\\Repository\\HatchersRepository' => '?',
            'App\\Repository\\HerdsRepository' => '?',
            'App\\Repository\\InputDeliveryRepository' => '?',
            'App\\Repository\\InputsFarmDeliveryPlanRepository' => '?',
            'App\\Repository\\InputsFarmRepository' => '?',
            'App\\Repository\\InputsRepository' => '?',
            'App\\Repository\\LightingRepository' => '?',
            'App\\Repository\\PlanDeliveryChickRepository' => '?',
            'App\\Repository\\PlanDeliveryEggRepository' => '?',
            'App\\Repository\\PlanIndicatorsRepository' => '?',
            'App\\Repository\\PlanInputRepository' => '?',
            'App\\Repository\\ResetPasswordRequestRepository' => '?',
            'App\\Repository\\SelectionsRepository' => '?',
            'App\\Repository\\SellingEggRepository' => '?',
            'App\\Repository\\SettersRepository' => '?',
            'App\\Repository\\SupplierRepository' => '?',
            'App\\Repository\\TransfersRepository' => '?',
            'App\\Repository\\TransportListRepository' => '?',
            'App\\Repository\\UserRepository' => '?',
            'App\\Repository\\VaccinationRepository' => '?',
        ])));
        $a->addCustomDatetimeFunction('date_format', 'DoctrineExtensions\\Query\\Mysql\\DateFormat');
        $a->addCustomDatetimeFunction('weekofyear', 'DoctrineExtensions\\Query\\Mysql\\WeekOfYear');
        $a->addCustomDatetimeFunction('week', 'DoctrineExtensions\\Query\\Mysql\\Week');
        $a->addCustomDatetimeFunction('yearweek', 'DoctrineExtensions\\Query\\Mysql\\YearWeek');

        $instance = \Doctrine\ORM\EntityManager::create(($this->services['doctrine.dbal.default_connection'] ?? $this->getDoctrine_Dbal_DefaultConnectionService()), $a);

        (new \Doctrine\Bundle\DoctrineBundle\ManagerConfigurator([], []))->configure($instance);

        return $instance;
    }

    /*
     * Gets the public 'error_controller' shared service.
     *
     * @return \Symfony\Component\HttpKernel\Controller\ErrorController
     */
    protected function getErrorControllerService()
    {
        $a = ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack()));

        return $this->services['error_controller'] = new \Symfony\Component\HttpKernel\Controller\ErrorController(($this->services['http_kernel'] ?? $this->getHttpKernelService()), 'error_controller', new \Symfony\Component\ErrorHandler\ErrorRenderer\SerializerErrorRenderer(($this->services['serializer'] ?? $this->getSerializerService()), \Symfony\Component\ErrorHandler\ErrorRenderer\SerializerErrorRenderer::getPreferredFormat($a), new \Symfony\Bridge\Twig\ErrorRenderer\TwigErrorRenderer(($this->services['twig'] ?? $this->getTwigService()), new \Symfony\Component\ErrorHandler\ErrorRenderer\HtmlErrorRenderer(\Symfony\Component\ErrorHandler\ErrorRenderer\HtmlErrorRenderer::isDebug($a, false), 'UTF-8', ($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))), \dirname(__DIR__, 4), \Symfony\Component\ErrorHandler\ErrorRenderer\HtmlErrorRenderer::getAndCleanOutputBuffer($a), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService())), \Symfony\Bridge\Twig\ErrorRenderer\TwigErrorRenderer::isDebug($a, false)), \Symfony\Component\ErrorHandler\ErrorRenderer\HtmlErrorRenderer::isDebug($a, false)));
    }

    /*
     * Gets the public 'event_dispatcher' shared service.
     *
     * @return \Symfony\Component\EventDispatcher\EventDispatcher
     */
    protected function getEventDispatcherService()
    {
        $this->services['event_dispatcher'] = $instance = new \Symfony\Component\EventDispatcher\EventDispatcher();

        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['response_listener'] ?? ($this->privates['response_listener'] = new \Symfony\Component\HttpKernel\EventListener\ResponseListener('UTF-8')));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['streamed_response_listener'] ?? ($this->privates['streamed_response_listener'] = new \Symfony\Component\HttpKernel\EventListener\StreamedResponseListener()));
        }, 1 => 'onKernelResponse'], -1024);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['locale_listener'] ?? $this->getLocaleListenerService());
        }, 1 => 'setDefaultLocale'], 100);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['locale_listener'] ?? $this->getLocaleListenerService());
        }, 1 => 'onKernelRequest'], 16);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['locale_listener'] ?? $this->getLocaleListenerService());
        }, 1 => 'onKernelFinishRequest'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['validate_request_listener'] ?? ($this->privates['validate_request_listener'] = new \Symfony\Component\HttpKernel\EventListener\ValidateRequestListener()));
        }, 1 => 'onKernelRequest'], 256);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['.legacy_resolve_controller_name_subscriber'] ?? $this->get_LegacyResolveControllerNameSubscriberService());
        }, 1 => 'resolveControllerName'], 24);
        $instance->addListener('kernel.controller_arguments', [0 => function () {
            return ($this->privates['exception_listener'] ?? $this->getExceptionListenerService());
        }, 1 => 'onControllerArguments'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['exception_listener'] ?? $this->getExceptionListenerService());
        }, 1 => 'logKernelException'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['exception_listener'] ?? $this->getExceptionListenerService());
        }, 1 => 'onKernelException'], -128);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['locale_aware_listener'] ?? $this->getLocaleAwareListenerService());
        }, 1 => 'onKernelRequest'], 15);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['locale_aware_listener'] ?? $this->getLocaleAwareListenerService());
        }, 1 => 'onKernelFinishRequest'], -15);
        $instance->addListener('console.error', [0 => function () {
            return ($this->privates['console.error_listener'] ?? $this->getConsole_ErrorListenerService());
        }, 1 => 'onConsoleError'], -128);
        $instance->addListener('console.terminate', [0 => function () {
            return ($this->privates['console.error_listener'] ?? $this->getConsole_ErrorListenerService());
        }, 1 => 'onConsoleTerminate'], -128);
        $instance->addListener('console.error', [0 => function () {
            return ($this->privates['console.suggest_missing_package_subscriber'] ?? ($this->privates['console.suggest_missing_package_subscriber'] = new \Symfony\Bundle\FrameworkBundle\EventListener\SuggestMissingPackageSubscriber()));
        }, 1 => 'onConsoleError'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['session_listener'] ?? $this->getSessionListenerService());
        }, 1 => 'onKernelRequest'], 128);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['session_listener'] ?? $this->getSessionListenerService());
        }, 1 => 'onKernelResponse'], -1000);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['session_listener'] ?? $this->getSessionListenerService());
        }, 1 => 'onFinishRequest'], 0);
        $instance->addListener('Symfony\\Component\\Mailer\\Event\\MessageEvent', [0 => function () {
            return ($this->privates['mailer.envelope_listener'] ?? ($this->privates['mailer.envelope_listener'] = new \Symfony\Component\Mailer\EventListener\EnvelopeListener('System zarządzania produkcją wylęgarnii <app_sender@zwdmalec.pl>', [])));
        }, 1 => 'onMessage'], -255);
        $instance->addListener('Symfony\\Component\\Mailer\\Event\\MessageEvent', [0 => function () {
            return ($this->privates['mailer.logger_message_listener'] ?? ($this->privates['mailer.logger_message_listener'] = new \Symfony\Component\Mailer\EventListener\MessageLoggerListener()));
        }, 1 => 'onMessage'], -255);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['debug.debug_handlers_listener'] ?? $this->getDebug_DebugHandlersListenerService());
        }, 1 => 'configure'], 2048);
        $instance->addListener('console.command', [0 => function () {
            return ($this->privates['debug.debug_handlers_listener'] ?? $this->getDebug_DebugHandlersListenerService());
        }, 1 => 'configure'], 2048);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['router_listener'] ?? $this->getRouterListenerService());
        }, 1 => 'onKernelRequest'], 32);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['router_listener'] ?? $this->getRouterListenerService());
        }, 1 => 'onKernelFinishRequest'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['router_listener'] ?? $this->getRouterListenerService());
        }, 1 => 'onKernelException'], -64);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['web_link.add_link_header_listener'] ?? ($this->privates['web_link.add_link_header_listener'] = new \Symfony\Component\WebLink\EventListener\AddLinkHeaderListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.controller.listener'] ?? $this->getSensioFrameworkExtra_Controller_ListenerService());
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.converter.listener'] ?? $this->getSensioFrameworkExtra_Converter_ListenerService());
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.view.listener'] ?? $this->getSensioFrameworkExtra_View_ListenerService());
        }, 1 => 'onKernelController'], -128);
        $instance->addListener('kernel.view', [0 => function () {
            return ($this->privates['sensio_framework_extra.view.listener'] ?? $this->getSensioFrameworkExtra_View_ListenerService());
        }, 1 => 'onKernelView'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.cache.listener'] ?? ($this->privates['sensio_framework_extra.cache.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\HttpCacheListener()));
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['sensio_framework_extra.cache.listener'] ?? ($this->privates['sensio_framework_extra.cache.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\HttpCacheListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.controller_arguments', [0 => function () {
            return ($this->privates['sensio_framework_extra.security.listener'] ?? $this->getSensioFrameworkExtra_Security_ListenerService());
        }, 1 => 'onKernelControllerArguments'], 0);
        $instance->addListener('kernel.controller_arguments', [0 => function () {
            return ($this->privates['framework_extra_bundle.event.is_granted'] ?? $this->getFrameworkExtraBundle_Event_IsGrantedService());
        }, 1 => 'onKernelControllerArguments'], 0);
        $instance->addListener('Symfony\\Component\\Mailer\\Event\\MessageEvent', [0 => function () {
            return ($this->privates['twig.mailer.message_listener'] ?? $this->getTwig_Mailer_MessageListenerService());
        }, 1 => 'onMessage'], 0);
        $instance->addListener('console.command', [0 => function () {
            return ($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService());
        }, 1 => 'onCommand'], 255);
        $instance->addListener('console.terminate', [0 => function () {
            return ($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService());
        }, 1 => 'onTerminate'], -255);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['security.firewall'] ?? $this->getSecurity_FirewallService());
        }, 1 => 'configureLogoutUrlGenerator'], 8);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['security.firewall'] ?? $this->getSecurity_FirewallService());
        }, 1 => 'onKernelRequest'], 8);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['security.firewall'] ?? $this->getSecurity_FirewallService());
        }, 1 => 'onKernelFinishRequest'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['security.rememberme.response_listener'] ?? ($this->privates['security.rememberme.response_listener'] = new \Symfony\Component\Security\Http\RememberMe\ResponseListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->getSwiftmailer_EmailSender_ListenerService());
        }, 1 => 'onException'], 0);
        $instance->addListener('kernel.terminate', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->getSwiftmailer_EmailSender_ListenerService());
        }, 1 => 'onTerminate'], 0);
        $instance->addListener('console.error', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->getSwiftmailer_EmailSender_ListenerService());
        }, 1 => 'onException'], 0);
        $instance->addListener('console.terminate', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->getSwiftmailer_EmailSender_ListenerService());
        }, 1 => 'onTerminate'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['DH\\AuditorBundle\\Event\\ViewerEventSubscriber'] ?? $this->getViewerEventSubscriberService());
        }, 1 => 'onKernelController'], 0);

        return $instance;
    }

    /*
     * Gets the public 'filesystem' shared service.
     *
     * @return \Symfony\Component\Filesystem\Filesystem
     */
    protected function getFilesystemService()
    {
        return $this->services['filesystem'] = new \Symfony\Component\Filesystem\Filesystem();
    }

    /*
     * Gets the public 'form.factory' shared service.
     *
     * @return \Symfony\Component\Form\FormFactory
     */
    protected function getForm_FactoryService()
    {
        return $this->services['form.factory'] = new \Symfony\Component\Form\FormFactory(($this->privates['form.registry'] ?? $this->getForm_RegistryService()));
    }

    /*
     * Gets the public 'form.type.file' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\FileType
     */
    protected function getForm_Type_FileService()
    {
        return $this->services['form.type.file'] = new \Symfony\Component\Form\Extension\Core\Type\FileType(($this->services['translator'] ?? $this->getTranslatorService()));
    }

    /*
     * Gets the public 'http_kernel' shared service.
     *
     * @return \Symfony\Component\HttpKernel\HttpKernel
     */
    protected function getHttpKernelService()
    {
        return $this->services['http_kernel'] = new \Symfony\Component\HttpKernel\HttpKernel(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), new \Symfony\Bundle\FrameworkBundle\Controller\ControllerResolver($this, ($this->privates['monolog.logger.request'] ?? $this->getMonolog_Logger_RequestService()), ($this->privates['.legacy_controller_name_converter'] ?? ($this->privates['.legacy_controller_name_converter'] = new \Symfony\Bundle\FrameworkBundle\Controller\ControllerNameParser(($this->services['kernel'] ?? $this->get('kernel', 1)), false)))), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), new \Symfony\Component\HttpKernel\Controller\ArgumentResolver(($this->privates['argument_metadata_factory'] ?? ($this->privates['argument_metadata_factory'] = new \Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadataFactory())), new RewindableGenerator(function () {
            yield 0 => ($this->privates['argument_resolver.request_attribute'] ?? ($this->privates['argument_resolver.request_attribute'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\RequestAttributeValueResolver()));
            yield 1 => ($this->privates['argument_resolver.request'] ?? ($this->privates['argument_resolver.request'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\RequestValueResolver()));
            yield 2 => ($this->privates['argument_resolver.session'] ?? ($this->privates['argument_resolver.session'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\SessionValueResolver()));
            yield 3 => ($this->privates['security.user_value_resolver'] ?? $this->getSecurity_UserValueResolverService());
            yield 4 => ($this->privates['argument_resolver.service'] ?? $this->getArgumentResolver_ServiceService());
            yield 5 => ($this->privates['argument_resolver.default'] ?? ($this->privates['argument_resolver.default'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\DefaultValueResolver()));
            yield 6 => ($this->privates['argument_resolver.variadic'] ?? ($this->privates['argument_resolver.variadic'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\VariadicValueResolver()));
        }, 7)));
    }

    /*
     * Gets the public 'knp_snappy.image' shared service.
     *
     * @return \Knp\Snappy\Image
     */
    protected function getKnpSnappy_ImageService()
    {
        $this->services['knp_snappy.image'] = $instance = new \Knp\Snappy\Image('/var/wkhtmltoimage', [], []);

        $instance->setLogger(($this->privates['monolog.logger.snappy'] ?? $this->getMonolog_Logger_SnappyService()));

        return $instance;
    }

    /*
     * Gets the public 'knp_snappy.pdf' shared service.
     *
     * @return \Knp\Snappy\Pdf
     */
    protected function getKnpSnappy_PdfService()
    {
        $this->services['knp_snappy.pdf'] = $instance = new \Knp\Snappy\Pdf('/usr/bin/wkhtmltopdf', [], []);

        $instance->setLogger(($this->privates['monolog.logger.snappy'] ?? $this->getMonolog_Logger_SnappyService()));

        return $instance;
    }

    /*
     * Gets the public 'request_stack' shared service.
     *
     * @return \Symfony\Component\HttpFoundation\RequestStack
     */
    protected function getRequestStackService()
    {
        return $this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack();
    }

    /*
     * Gets the public 'router' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Routing\Router
     */
    protected function getRouterService()
    {
        $a = new \Symfony\Bridge\Monolog\Logger('router');
        $a->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $a->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        $this->services['router'] = $instance = new \Symfony\Bundle\FrameworkBundle\Routing\Router((new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'routing.loader' => ['services', 'routing.loader', 'getRouting_LoaderService', false],
        ], [
            'routing.loader' => 'Symfony\\Component\\Config\\Loader\\LoaderInterface',
        ]))->withContext('router.default', $this), 'kernel::loadRoutes', ['cache_dir' => $this->targetDir.'', 'debug' => false, 'generator_class' => 'Symfony\\Component\\Routing\\Generator\\CompiledUrlGenerator', 'generator_dumper_class' => 'Symfony\\Component\\Routing\\Generator\\Dumper\\CompiledUrlGeneratorDumper', 'matcher_class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\RedirectableCompiledUrlMatcher', 'matcher_dumper_class' => 'Symfony\\Component\\Routing\\Matcher\\Dumper\\CompiledUrlMatcherDumper', 'strict_requirements' => NULL, 'resource_type' => 'service'], ($this->privates['router.request_context'] ?? $this->getRouter_RequestContextService()), ($this->privates['parameter_bag'] ?? ($this->privates['parameter_bag'] = new \Symfony\Component\DependencyInjection\ParameterBag\ContainerBag($this))), $a, 'pl');

        $instance->setConfigCacheFactory(($this->privates['config_cache_factory'] ?? ($this->privates['config_cache_factory'] = new \Symfony\Component\Config\ResourceCheckerConfigCacheFactory())));

        return $instance;
    }

    /*
     * Gets the public 'routing.loader' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Routing\DelegatingLoader
     */
    protected function getRouting_LoaderService()
    {
        $a = new \Symfony\Component\Config\Loader\LoaderResolver();

        $b = new \Symfony\Component\HttpKernel\Config\FileLocator(($this->services['kernel'] ?? $this->get('kernel', 1)), (\dirname(__DIR__, 4).'/src/Resources'), [0 => (\dirname(__DIR__, 4).'/src')], false);
        $c = new \Symfony\Bundle\FrameworkBundle\Routing\AnnotatedRouteControllerLoader(($this->privates['annotations.cached_reader'] ?? $this->getAnnotations_CachedReaderService()));

        $a->addLoader(new \Symfony\Component\Routing\Loader\XmlFileLoader($b));
        $a->addLoader(new \Symfony\Component\Routing\Loader\YamlFileLoader($b));
        $a->addLoader(new \Symfony\Component\Routing\Loader\PhpFileLoader($b));
        $a->addLoader(new \Symfony\Component\Routing\Loader\GlobFileLoader($b));
        $a->addLoader(new \Symfony\Component\Routing\Loader\DirectoryLoader($b));
        $a->addLoader(new \Symfony\Component\Routing\Loader\ContainerLoader(new \Symfony\Bundle\FrameworkBundle\Routing\LegacyRouteLoaderContainer($this, new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'kernel' => ['services', 'kernel', 'getKernelService', false],
        ], [
            'kernel' => 'App\\Kernel',
        ]))));
        $a->addLoader(new \DH\AuditorBundle\Routing\RoutingAnnotationLoader($c, $this->parameters['dh_auditor.provider.doctrine.configuration']));
        $a->addLoader($c);
        $a->addLoader(new \Symfony\Component\Routing\Loader\AnnotationDirectoryLoader($b, $c));
        $a->addLoader(new \Symfony\Component\Routing\Loader\AnnotationFileLoader($b, $c));

        return $this->services['routing.loader'] = new \Symfony\Bundle\FrameworkBundle\Routing\DelegatingLoader($a, [], ['utf8' => true]);
    }

    /*
     * Gets the public 'security.authentication_utils' shared service.
     *
     * @return \Symfony\Component\Security\Http\Authentication\AuthenticationUtils
     */
    protected function getSecurity_AuthenticationUtilsService()
    {
        return $this->services['security.authentication_utils'] = new \Symfony\Component\Security\Http\Authentication\AuthenticationUtils(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'security.authorization_checker' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\AuthorizationChecker
     */
    protected function getSecurity_AuthorizationCheckerService()
    {
        return $this->services['security.authorization_checker'] = new \Symfony\Component\Security\Core\Authorization\AuthorizationChecker(($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()), ($this->privates['security.authentication.manager'] ?? $this->getSecurity_Authentication_ManagerService()), ($this->privates['security.access.decision_manager'] ?? $this->getSecurity_Access_DecisionManagerService()), false);
    }

    /*
     * Gets the public 'security.csrf.token_manager' shared service.
     *
     * @return \Symfony\Component\Security\Csrf\CsrfTokenManager
     */
    protected function getSecurity_Csrf_TokenManagerService()
    {
        return $this->services['security.csrf.token_manager'] = new \Symfony\Component\Security\Csrf\CsrfTokenManager(new \Symfony\Component\Security\Csrf\TokenGenerator\UriSafeTokenGenerator(), ($this->privates['security.csrf.token_storage'] ?? $this->getSecurity_Csrf_TokenStorageService()), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'security.password_encoder' shared service.
     *
     * @return \Symfony\Component\Security\Core\Encoder\UserPasswordEncoder
     */
    protected function getSecurity_PasswordEncoderService()
    {
        return $this->services['security.password_encoder'] = new \Symfony\Component\Security\Core\Encoder\UserPasswordEncoder(($this->privates['security.encoder_factory.generic'] ?? $this->getSecurity_EncoderFactory_GenericService()));
    }

    /*
     * Gets the public 'security.token_storage' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authentication\Token\Storage\UsageTrackingTokenStorage
     */
    protected function getSecurity_TokenStorageService()
    {
        return $this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\UsageTrackingTokenStorage(($this->privates['security.untracked_token_storage'] ?? ($this->privates['security.untracked_token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())), new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'session' => ['services', 'session', 'getSessionService', false],
        ], [
            'session' => '?',
        ]));
    }

    /*
     * Gets the public 'serializer' shared service.
     *
     * @return \Symfony\Component\Serializer\Serializer
     */
    protected function getSerializerService()
    {
        $a = ($this->privates['serializer.mapping.cache_class_metadata_factory'] ?? $this->getSerializer_Mapping_CacheClassMetadataFactoryService());

        $b = new \Symfony\Component\Serializer\NameConverter\MetadataAwareNameConverter($a);

        return $this->services['serializer'] = new \Symfony\Component\Serializer\Serializer([0 => new \Symfony\Component\Serializer\Normalizer\ProblemNormalizer(false), 1 => new \Symfony\Component\Serializer\Normalizer\JsonSerializableNormalizer(), 2 => new \Symfony\Component\Serializer\Normalizer\DateTimeNormalizer(), 3 => new \Symfony\Component\Serializer\Normalizer\ConstraintViolationListNormalizer([], $b), 4 => new \Symfony\Component\Serializer\Normalizer\DateTimeZoneNormalizer(), 5 => new \Symfony\Component\Serializer\Normalizer\DateIntervalNormalizer(), 6 => new \Symfony\Component\Serializer\Normalizer\DataUriNormalizer(($this->privates['mime_types'] ?? $this->getMimeTypesService())), 7 => new \Symfony\Component\Serializer\Normalizer\ArrayDenormalizer(), 8 => new \Symfony\Component\Serializer\Normalizer\ObjectNormalizer($a, $b, ($this->privates['property_accessor'] ?? $this->getPropertyAccessorService()), ($this->privates['property_info.cache'] ?? $this->getPropertyInfo_CacheService()), new \Symfony\Component\Serializer\Mapping\ClassDiscriminatorFromClassMetadata($a), NULL, [])], [0 => new \Symfony\Component\Serializer\Encoder\XmlEncoder(), 1 => new \Symfony\Component\Serializer\Encoder\JsonEncoder(), 2 => new \Symfony\Component\Serializer\Encoder\YamlEncoder(), 3 => new \Symfony\Component\Serializer\Encoder\CsvEncoder()]);
    }

    /*
     * Gets the public 'services_resetter' shared service.
     *
     * @return \Symfony\Component\HttpKernel\DependencyInjection\ServicesResetter
     */
    protected function getServicesResetterService()
    {
        return $this->services['services_resetter'] = new \Symfony\Component\HttpKernel\DependencyInjection\ServicesResetter(new RewindableGenerator(function () {
            if (isset($this->services['cache.app'])) {
                yield 'cache.app' => ($this->services['cache.app'] ?? null);
            }
            if (isset($this->services['cache.system'])) {
                yield 'cache.system' => ($this->services['cache.system'] ?? null);
            }
            if (isset($this->privates['cache.validator'])) {
                yield 'cache.validator' => ($this->privates['cache.validator'] ?? null);
            }
            if (isset($this->privates['cache.serializer'])) {
                yield 'cache.serializer' => ($this->privates['cache.serializer'] ?? null);
            }
            if (isset($this->privates['cache.annotations'])) {
                yield 'cache.annotations' => ($this->privates['cache.annotations'] ?? null);
            }
            if (isset($this->privates['cache.property_info'])) {
                yield 'cache.property_info' => ($this->privates['cache.property_info'] ?? null);
            }
            if (isset($this->privates['doctrine.result_cache_pool'])) {
                yield 'doctrine.result_cache_pool' => ($this->privates['doctrine.result_cache_pool'] ?? null);
            }
            if (isset($this->privates['doctrine.system_cache_pool'])) {
                yield 'doctrine.system_cache_pool' => ($this->privates['doctrine.system_cache_pool'] ?? null);
            }
            if (isset($this->privates['form.choice_list_factory.cached'])) {
                yield 'form.choice_list_factory.cached' => ($this->privates['form.choice_list_factory.cached'] ?? null);
            }
            if (isset($this->privates['mailer.logger_message_listener'])) {
                yield 'mailer.logger_message_listener' => ($this->privates['mailer.logger_message_listener'] ?? null);
            }
            if (isset($this->privates['debug.stopwatch'])) {
                yield 'debug.stopwatch' => ($this->privates['debug.stopwatch'] ?? null);
            }
            if (isset($this->privates['monolog.handler.main'])) {
                yield 'monolog.handler.main' => ($this->privates['monolog.handler.main'] ?? null);
            }
            if (isset($this->privates['monolog.handler.console'])) {
                yield 'monolog.handler.console' => ($this->privates['monolog.handler.console'] ?? null);
            }
            if (isset($this->services['doctrine'])) {
                yield 'doctrine' => ($this->services['doctrine'] ?? null);
            }
            if (isset($this->privates['form.type.entity'])) {
                yield 'form.type.entity' => ($this->privates['form.type.entity'] ?? null);
            }
            if (isset($this->services['security.token_storage'])) {
                yield 'security.token_storage' => ($this->services['security.token_storage'] ?? null);
            }
            if (isset($this->privates['cache.security_expression_language'])) {
                yield 'cache.security_expression_language' => ($this->privates['cache.security_expression_language'] ?? null);
            }
            if (isset($this->privates['swiftmailer.email_sender.listener'])) {
                yield 'swiftmailer.email_sender.listener' => ($this->privates['swiftmailer.email_sender.listener'] ?? null);
            }
        }, function () {
            return 0 + (int) (isset($this->services['cache.app'])) + (int) (isset($this->services['cache.system'])) + (int) (isset($this->privates['cache.validator'])) + (int) (isset($this->privates['cache.serializer'])) + (int) (isset($this->privates['cache.annotations'])) + (int) (isset($this->privates['cache.property_info'])) + (int) (isset($this->privates['doctrine.result_cache_pool'])) + (int) (isset($this->privates['doctrine.system_cache_pool'])) + (int) (isset($this->privates['form.choice_list_factory.cached'])) + (int) (isset($this->privates['mailer.logger_message_listener'])) + (int) (isset($this->privates['debug.stopwatch'])) + (int) (isset($this->privates['monolog.handler.main'])) + (int) (isset($this->privates['monolog.handler.console'])) + (int) (isset($this->services['doctrine'])) + (int) (isset($this->privates['form.type.entity'])) + (int) (isset($this->services['security.token_storage'])) + (int) (isset($this->privates['cache.security_expression_language'])) + (int) (isset($this->privates['swiftmailer.email_sender.listener']));
        }), ['cache.app' => [0 => 'reset'], 'cache.system' => [0 => 'reset'], 'cache.validator' => [0 => 'reset'], 'cache.serializer' => [0 => 'reset'], 'cache.annotations' => [0 => 'reset'], 'cache.property_info' => [0 => 'reset'], 'doctrine.result_cache_pool' => [0 => 'reset'], 'doctrine.system_cache_pool' => [0 => 'reset'], 'form.choice_list_factory.cached' => [0 => 'reset'], 'mailer.logger_message_listener' => [0 => 'reset'], 'debug.stopwatch' => [0 => 'reset'], 'monolog.handler.main' => [0 => 'reset'], 'monolog.handler.console' => [0 => 'reset'], 'doctrine' => [0 => 'reset'], 'form.type.entity' => [0 => 'reset'], 'security.token_storage' => [0 => 'disableUsageTracking', 1 => 'setToken'], 'cache.security_expression_language' => [0 => 'reset'], 'swiftmailer.email_sender.listener' => [0 => 'reset']]);
    }

    /*
     * Gets the public 'session' shared service.
     *
     * @return \Symfony\Component\HttpFoundation\Session\Session
     */
    protected function getSessionService()
    {
        return $this->services['session'] = new \Symfony\Component\HttpFoundation\Session\Session(($this->privates['session.storage.native'] ?? $this->getSession_Storage_NativeService()));
    }

    /*
     * Gets the public 'swiftmailer.mailer.default' shared service.
     *
     * @return \Swift_Mailer
     */
    protected function getSwiftmailer_Mailer_DefaultService()
    {
        return $this->services['swiftmailer.mailer.default'] = new \Swift_Mailer(($this->services['swiftmailer.transport'] ?? $this->getSwiftmailer_TransportService()));
    }

    /*
     * Gets the public 'swiftmailer.mailer.default.transport.real' shared service.
     *
     * @return \Swift_Transport
     */
    protected function getSwiftmailer_Mailer_Default_Transport_RealService()
    {
        return $this->services['swiftmailer.mailer.default.transport.real'] = \Symfony\Bundle\SwiftmailerBundle\DependencyInjection\SwiftmailerTransportFactory::createTransport(['transport' => 'smtp', 'url' => $this->getEnv('MAILER_URL'), 'username' => NULL, 'password' => NULL, 'host' => 'localhost', 'port' => NULL, 'timeout' => 30, 'source_ip' => NULL, 'local_domain' => NULL, 'encryption' => NULL, 'auth_mode' => NULL, 'command' => '/usr/sbin/sendmail -t -i ', 'stream_options' => []], ($this->privates['router.request_context'] ?? $this->getRouter_RequestContextService()), ($this->privates['swiftmailer.mailer.default.transport.eventdispatcher'] ?? ($this->privates['swiftmailer.mailer.default.transport.eventdispatcher'] = new \Swift_Events_SimpleEventDispatcher())));
    }

    /*
     * Gets the public 'swiftmailer.transport' shared service.
     *
     * @return \Swift_Transport_SpoolTransport
     */
    protected function getSwiftmailer_TransportService()
    {
        return $this->services['swiftmailer.transport'] = new \Swift_Transport_SpoolTransport(($this->privates['swiftmailer.mailer.default.transport.eventdispatcher'] ?? ($this->privates['swiftmailer.mailer.default.transport.eventdispatcher'] = new \Swift_Events_SimpleEventDispatcher())), new \Swift_MemorySpool());
    }

    /*
     * Gets the public 'translator' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Translation\Translator
     */
    protected function getTranslatorService()
    {
        $this->services['translator'] = $instance = new \Symfony\Bundle\FrameworkBundle\Translation\Translator(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'translation.loader.csv' => ['privates', 'translation.loader.csv', 'getTranslation_Loader_CsvService', false],
            'translation.loader.dat' => ['privates', 'translation.loader.dat', 'getTranslation_Loader_DatService', false],
            'translation.loader.ini' => ['privates', 'translation.loader.ini', 'getTranslation_Loader_IniService', false],
            'translation.loader.json' => ['privates', 'translation.loader.json', 'getTranslation_Loader_JsonService', false],
            'translation.loader.mo' => ['privates', 'translation.loader.mo', 'getTranslation_Loader_MoService', false],
            'translation.loader.php' => ['privates', 'translation.loader.php', 'getTranslation_Loader_PhpService', false],
            'translation.loader.po' => ['privates', 'translation.loader.po', 'getTranslation_Loader_PoService', false],
            'translation.loader.qt' => ['privates', 'translation.loader.qt', 'getTranslation_Loader_QtService', false],
            'translation.loader.res' => ['privates', 'translation.loader.res', 'getTranslation_Loader_ResService', false],
            'translation.loader.xliff' => ['privates', 'translation.loader.xliff', 'getTranslation_Loader_XliffService', false],
            'translation.loader.yml' => ['privates', 'translation.loader.yml', 'getTranslation_Loader_YmlService', false],
        ], [
            'translation.loader.csv' => '?',
            'translation.loader.dat' => '?',
            'translation.loader.ini' => '?',
            'translation.loader.json' => '?',
            'translation.loader.mo' => '?',
            'translation.loader.php' => '?',
            'translation.loader.po' => '?',
            'translation.loader.qt' => '?',
            'translation.loader.res' => '?',
            'translation.loader.xliff' => '?',
            'translation.loader.yml' => '?',
        ]), new \Symfony\Component\Translation\Formatter\MessageFormatter(new \Symfony\Component\Translation\IdentityTranslator()), 'pl', ['translation.loader.php' => [0 => 'php'], 'translation.loader.yml' => [0 => 'yaml', 1 => 'yml'], 'translation.loader.xliff' => [0 => 'xlf', 1 => 'xliff'], 'translation.loader.po' => [0 => 'po'], 'translation.loader.mo' => [0 => 'mo'], 'translation.loader.qt' => [0 => 'ts'], 'translation.loader.csv' => [0 => 'csv'], 'translation.loader.res' => [0 => 'res'], 'translation.loader.dat' => [0 => 'dat'], 'translation.loader.ini' => [0 => 'ini'], 'translation.loader.json' => [0 => 'json']], ['cache_dir' => ($this->targetDir.''.'/translations'), 'debug' => false, 'resource_files' => ['af' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.af.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.af.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.af.xlf')], 'ar' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.ar.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.ar.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.ar.xlf')], 'az' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.az.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.az.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.az.xlf')], 'be' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.be.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.be.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.be.xlf')], 'bg' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.bg.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.bg.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.bg.xlf')], 'bs' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.bs.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.bs.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.bs.xlf')], 'ca' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.ca.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.ca.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.ca.xlf')], 'cs' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.cs.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.cs.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.cs.xlf')], 'cy' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.cy.xlf')], 'da' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.da.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.da.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.da.xlf')], 'de' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.de.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.de.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.de.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.de.xlf'), 4 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations/auditor.de.yaml')], 'el' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.el.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.el.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.el.xlf')], 'en' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.en.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.en.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.en.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.en.xlf'), 4 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations/auditor.en.yaml')], 'es' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.es.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.es.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.es.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.es.xlf'), 4 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations/auditor.es.yaml')], 'et' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.et.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.et.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations/auditor.et.yaml')], 'eu' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.eu.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.eu.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.eu.xlf')], 'fa' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.fa.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.fa.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.fa.xlf')], 'fi' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.fi.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.fi.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.fi.xlf')], 'fr' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.fr.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.fr.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.fr.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.fr.xlf'), 4 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations/auditor.fr.yaml')], 'gl' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.gl.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.gl.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.gl.xlf')], 'he' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.he.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.he.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.he.xlf')], 'hr' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.hr.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.hr.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.hr.xlf')], 'hu' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.hu.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.hu.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.hu.xlf')], 'hy' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.hy.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.hy.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.hy.xlf')], 'id' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.id.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.id.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.id.xlf')], 'it' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.it.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.it.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.it.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.it.xlf'), 4 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations/auditor.it.yaml')], 'ja' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.ja.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.ja.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.ja.xlf')], 'lb' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.lb.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.lb.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.lb.xlf')], 'lt' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.lt.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.lt.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.lt.xlf')], 'lv' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.lv.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.lv.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.lv.xlf')], 'mn' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.mn.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.mn.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.mn.xlf')], 'nb' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.nb.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.nb.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.nb.xlf')], 'nl' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.nl.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.nl.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.nl.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations/auditor.nl.yaml')], 'nn' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.nn.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.nn.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.nn.xlf')], 'no' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.no.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.no.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.no.xlf')], 'pl' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.pl.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.pl.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.pl.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.pl.xlf'), 4 => (\dirname(__DIR__, 4).'/translations/auditor.pl.yaml'), 5 => (\dirname(__DIR__, 4).'/translations/messages.pl.yaml'), 6 => (\dirname(__DIR__, 4).'/translations/validators.pl.yaml')], 'pt' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.pt.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.pt.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.pt.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.pt.xlf')], 'pt_BR' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.pt_BR.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.pt_BR.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.pt_BR.xlf')], 'ro' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.ro.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.ro.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.ro.xlf')], 'ru' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.ru.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.ru.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.ru.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.ru.xlf')], 'sk' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.sk.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.sk.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.sk.xlf')], 'sl' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.sl.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.sl.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.sl.xlf')], 'sq' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.sq.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.sq.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.sq.xlf')], 'sr_Cyrl' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.sr_Cyrl.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.sr_Cyrl.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.sr_Cyrl.xlf')], 'sr_Latn' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.sr_Latn.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.sr_Latn.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.sr_Latn.xlf')], 'sv' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.sv.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.sv.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.sv.xlf')], 'th' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.th.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.th.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.th.xlf')], 'tl' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.tl.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.tl.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.tl.xlf')], 'tr' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.tr.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.tr.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.tr.xlf')], 'uk' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.uk.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.uk.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.uk.xlf'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.uk.xlf')], 'uz' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.uz.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.uz.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.uz.xlf')], 'vi' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.vi.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.vi.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.vi.xlf')], 'zh_CN' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.zh_CN.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.zh_CN.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.zh_CN.xlf')], 'zh_TW' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations/validators.zh_TW.xlf'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations/validators.zh_TW.xlf'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations/security.zh_TW.xlf')], 'sr' => [0 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations/ResetPasswordBundle.sr.xlf')]], 'scanned_directories' => [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations'), 3 => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src/Resources/translations'), 4 => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/translations'), 5 => (\dirname(__DIR__, 4).'/translations'), 6 => (\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle/translations'), 7 => (\dirname(__DIR__, 4).'/src/Resources/FrameworkBundle/translations'), 8 => (\dirname(__DIR__, 4).'/vendor/sensio/framework-extra-bundle/src/translations'), 9 => (\dirname(__DIR__, 4).'/src/Resources/SensioFrameworkExtraBundle/translations'), 10 => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bundle/translations'), 11 => (\dirname(__DIR__, 4).'/src/Resources/TwigBundle/translations'), 12 => (\dirname(__DIR__, 4).'/vendor/symfony/monolog-bundle/translations'), 13 => (\dirname(__DIR__, 4).'/src/Resources/MonologBundle/translations'), 14 => (\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-bundle/translations'), 15 => (\dirname(__DIR__, 4).'/src/Resources/DoctrineBundle/translations'), 16 => (\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-migrations-bundle/translations'), 17 => (\dirname(__DIR__, 4).'/src/Resources/DoctrineMigrationsBundle/translations'), 18 => (\dirname(__DIR__, 4).'/vendor/symfony/security-bundle/translations'), 19 => (\dirname(__DIR__, 4).'/src/Resources/SecurityBundle/translations'), 20 => (\dirname(__DIR__, 4).'/vendor/twig/extra-bundle/translations'), 21 => (\dirname(__DIR__, 4).'/src/Resources/TwigExtraBundle/translations'), 22 => (\dirname(__DIR__, 4).'/src/Resources/SymfonyCastsResetPasswordBundle/translations'), 23 => (\dirname(__DIR__, 4).'/vendor/symfony/swiftmailer-bundle/translations'), 24 => (\dirname(__DIR__, 4).'/src/Resources/SwiftmailerBundle/translations'), 25 => (\dirname(__DIR__, 4).'/vendor/stof/doctrine-extensions-bundle/src/translations'), 26 => (\dirname(__DIR__, 4).'/src/Resources/StofDoctrineExtensionsBundle/translations'), 27 => (\dirname(__DIR__, 4).'/vendor/knplabs/knp-snappy-bundle/src/translations'), 28 => (\dirname(__DIR__, 4).'/src/Resources/KnpSnappyBundle/translations'), 29 => (\dirname(__DIR__, 4).'/src/Resources/DHAuditorBundle/translations'), 30 => (\dirname(__DIR__, 4).'/src/Resources/translations')], 'cache_vary' => ['scanned_directories' => [0 => 'vendor/symfony/validator/Resources/translations', 1 => 'vendor/symfony/form/Resources/translations', 2 => 'vendor/symfony/security-core/Resources/translations', 3 => 'vendor/symfonycasts/reset-password-bundle/src/Resources/translations', 4 => 'vendor/damienharper/auditor-bundle/src/translations', 5 => 'translations', 6 => 'vendor/symfony/framework-bundle/translations', 7 => 'src/Resources/FrameworkBundle/translations', 8 => 'vendor/sensio/framework-extra-bundle/src/translations', 9 => 'src/Resources/SensioFrameworkExtraBundle/translations', 10 => 'vendor/symfony/twig-bundle/translations', 11 => 'src/Resources/TwigBundle/translations', 12 => 'vendor/symfony/monolog-bundle/translations', 13 => 'src/Resources/MonologBundle/translations', 14 => 'vendor/doctrine/doctrine-bundle/translations', 15 => 'src/Resources/DoctrineBundle/translations', 16 => 'vendor/doctrine/doctrine-migrations-bundle/translations', 17 => 'src/Resources/DoctrineMigrationsBundle/translations', 18 => 'vendor/symfony/security-bundle/translations', 19 => 'src/Resources/SecurityBundle/translations', 20 => 'vendor/twig/extra-bundle/translations', 21 => 'src/Resources/TwigExtraBundle/translations', 22 => 'src/Resources/SymfonyCastsResetPasswordBundle/translations', 23 => 'vendor/symfony/swiftmailer-bundle/translations', 24 => 'src/Resources/SwiftmailerBundle/translations', 25 => 'vendor/stof/doctrine-extensions-bundle/src/translations', 26 => 'src/Resources/StofDoctrineExtensionsBundle/translations', 27 => 'vendor/knplabs/knp-snappy-bundle/src/translations', 28 => 'src/Resources/KnpSnappyBundle/translations', 29 => 'src/Resources/DHAuditorBundle/translations', 30 => 'src/Resources/translations']]]);

        $instance->setConfigCacheFactory(($this->privates['config_cache_factory'] ?? ($this->privates['config_cache_factory'] = new \Symfony\Component\Config\ResourceCheckerConfigCacheFactory())));
        $instance->setFallbackLocales([0 => 'pl']);

        return $instance;
    }

    /*
     * Gets the public 'twig' shared service.
     *
     * @return \Twig\Environment
     */
    protected function getTwigService()
    {
        $a = new \Twig\Loader\FilesystemLoader([], \dirname(__DIR__, 4));
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle/Resources/views'), 'Framework');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle/Resources/views'), '!Framework');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/twig-bundle/Resources/views'), 'Twig');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/twig-bundle/Resources/views'), '!Twig');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-bundle/Resources/views'), 'Doctrine');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-bundle/Resources/views'), '!Doctrine');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-migrations-bundle/Resources/views'), 'DoctrineMigrations');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-migrations-bundle/Resources/views'), '!DoctrineMigrations');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/security-bundle/Resources/views'), 'Security');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/security-bundle/Resources/views'), '!Security');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/swiftmailer-bundle/Resources/views'), 'Swiftmailer');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/swiftmailer-bundle/Resources/views'), '!Swiftmailer');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/Resources/views'), 'DHAuditor');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src/Resources/views'), '!DHAuditor');
        $a->addPath((\dirname(__DIR__, 4).'/templates'));
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Email'), 'email');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Email'), '!email');
        $a->addPath((\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Form'));

        $this->services['twig'] = $instance = new \Twig\Environment($a, ['debug' => false, 'strict_variables' => false, 'autoescape' => 'name', 'cache' => ($this->targetDir.''.'/twig'), 'charset' => 'UTF-8']);

        $b = ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack()));
        $c = new \Symfony\Bridge\Twig\AppVariable();
        $c->setEnvironment('prod');
        $c->setDebug(false);
        if ($this->has('security.token_storage')) {
            $c->setTokenStorage(($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()));
        }
        if ($this->has('request_stack')) {
            $c->setRequestStack($b);
        }

        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\CsrfExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\TranslationExtension(($this->services['translator'] ?? $this->getTranslatorService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\AssetExtension(new \Symfony\Component\Asset\Packages(new \Symfony\Component\Asset\PathPackage('', new \Symfony\Component\Asset\VersionStrategy\EmptyVersionStrategy(), new \Symfony\Component\Asset\Context\RequestStackContext($b, '', false)), [])));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\CodeExtension(($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))), \dirname(__DIR__, 4), 'UTF-8'));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\RoutingExtension(($this->services['router'] ?? $this->getRouterService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\YamlExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\StopwatchExtension(($this->privates['debug.stopwatch'] ?? ($this->privates['debug.stopwatch'] = new \Symfony\Component\Stopwatch\Stopwatch(true))), false));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\ExpressionExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\HttpKernelExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\HttpFoundationExtension(new \Symfony\Component\HttpFoundation\UrlHelper($b, ($this->privates['router.request_context'] ?? $this->getRouter_RequestContextService()))));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\WebLinkExtension($b));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\FormExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\LogoutUrlExtension(($this->privates['security.logout_url_generator'] ?? $this->getSecurity_LogoutUrlGeneratorService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\SecurityExtension(($this->services['security.authorization_checker'] ?? $this->getSecurity_AuthorizationCheckerService())));
        $instance->addExtension(new \Doctrine\Bundle\DoctrineBundle\Twig\DoctrineExtension());
        $instance->addExtension(new \Twig\Extra\Intl\IntlExtension());
        $instance->addExtension(new \Twig\Extra\Inky\InkyExtension());
        $instance->addExtension(new \DH\AuditorBundle\Twig\Extension\TwigExtension(($this->services['doctrine'] ?? $this->getDoctrineService())));
        $instance->addGlobal('app', $c);
        $instance->addRuntimeLoader(new \Twig\RuntimeLoader\ContainerRuntimeLoader(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'Symfony\\Bridge\\Twig\\Extension\\CsrfRuntime' => ['privates', 'twig.runtime.security_csrf', 'getTwig_Runtime_SecurityCsrfService', false],
            'Symfony\\Bridge\\Twig\\Extension\\HttpKernelRuntime' => ['privates', 'twig.runtime.httpkernel', 'getTwig_Runtime_HttpkernelService', false],
            'Symfony\\Component\\Form\\FormRenderer' => ['privates', 'twig.form.renderer', 'getTwig_Form_RendererService', false],
        ], [
            'Symfony\\Bridge\\Twig\\Extension\\CsrfRuntime' => '?',
            'Symfony\\Bridge\\Twig\\Extension\\HttpKernelRuntime' => '?',
            'Symfony\\Component\\Form\\FormRenderer' => '?',
        ])));
        (new \Symfony\Bundle\TwigBundle\DependencyInjection\Configurator\EnvironmentConfigurator('F j, Y H:i', '%d days', NULL, 0, '.', ','))->configure($instance);

        return $instance;
    }

    /*
     * Gets the public 'twig.controller.exception' shared service.
     *
     * @return \Symfony\Bundle\TwigBundle\Controller\ExceptionController
     *
     * @deprecated The "twig.controller.exception" service is deprecated since Symfony 4.4.
     */
    protected function getTwig_Controller_ExceptionService()
    {
        @trigger_error('The "twig.controller.exception" service is deprecated since Symfony 4.4.', E_USER_DEPRECATED);

        return $this->services['twig.controller.exception'] = new \Symfony\Bundle\TwigBundle\Controller\ExceptionController(($this->services['twig'] ?? $this->getTwigService()), false);
    }

    /*
     * Gets the public 'twig.controller.preview_error' shared service.
     *
     * @return \Symfony\Bundle\TwigBundle\Controller\PreviewErrorController
     *
     * @deprecated The "twig.controller.preview_error" service is deprecated since Symfony 4.4.
     */
    protected function getTwig_Controller_PreviewErrorService()
    {
        @trigger_error('The "twig.controller.preview_error" service is deprecated since Symfony 4.4.', E_USER_DEPRECATED);

        return $this->services['twig.controller.preview_error'] = new \Symfony\Bundle\TwigBundle\Controller\PreviewErrorController(($this->services['http_kernel'] ?? $this->getHttpKernelService()), NULL);
    }

    /*
     * Gets the public 'validator' shared service.
     *
     * @return \Symfony\Component\Validator\Validator\ValidatorInterface
     */
    protected function getValidatorService()
    {
        return $this->services['validator'] = ($this->privates['validator.builder'] ?? $this->getValidator_BuilderService())->getValidator();
    }

    /*
     * Gets the private '.errored..service_locator.0RTtFZW.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputsService()
    {
        $this->throw('Cannot autowire service ".service_locator.0RTtFZW": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.4gHrsrg.App\Entity\Driver' shared service.
     *
     * @return \App\Entity\Driver
     */
    protected function getDriverService()
    {
        $this->throw('Cannot autowire service ".service_locator.4gHrsrg": it references class "App\\Entity\\Driver" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.51x_oDo.App\Entity\TransportList' shared service.
     *
     * @return \App\Entity\TransportList
     */
    protected function getTransportListService()
    {
        $this->throw('Cannot autowire service ".service_locator.51x_oDo": it references class "App\\Entity\\TransportList" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.6uRO9y9.App\Entity\PlanInput' shared service.
     *
     * @return \App\Entity\PlanInput
     */
    protected function getPlanInputService()
    {
        $this->throw('Cannot autowire service ".service_locator.6uRO9y9": it references class "App\\Entity\\PlanInput" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.7GGDOJU.App\Entity\Herds' shared service.
     *
     * @return \App\Entity\Herds
     */
    protected function getHerdsService()
    {
        $this->throw('Cannot autowire service ".service_locator.7GGDOJU": it references class "App\\Entity\\Herds" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.7NSCnyQ.App\Entity\Customer' shared service.
     *
     * @return \App\Entity\Customer
     */
    protected function getCustomerService()
    {
        $this->throw('Cannot autowire service ".service_locator.7NSCnyQ": it references class "App\\Entity\\Customer" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.A8uXX_2.App\Entity\Supplier' shared service.
     *
     * @return \App\Entity\Supplier
     */
    protected function getSupplierService()
    {
        $this->throw('Cannot autowire service ".service_locator.A8uXX_2": it references class "App\\Entity\\Supplier" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.BKc.8Yh.App\Entity\InputsFarm' shared service.
     *
     * @return \App\Entity\InputsFarm
     */
    protected function getInputsFarmService()
    {
        $this->throw('Cannot autowire service ".service_locator.BKc.8Yh": it references class "App\\Entity\\InputsFarm" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.Dn9kS4t.App\Entity\ChickTemperature' shared service.
     *
     * @return \App\Entity\ChickTemperature
     */
    protected function getChickTemperatureService()
    {
        $this->throw('Cannot autowire service ".service_locator.Dn9kS4t": it references class "App\\Entity\\ChickTemperature" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.G4rkM_4.App\Entity\ChicksRecipient' shared service.
     *
     * @return \App\Entity\ChicksRecipient
     */
    protected function getChicksRecipientService()
    {
        $this->throw('Cannot autowire service ".service_locator.G4rkM_4": it references class "App\\Entity\\ChicksRecipient" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.ISCZ1YP.Symfony\Component\Security\Core\Exception\AccessDeniedException' shared service.
     *
     * @return \Symfony\Component\Security\Core\Exception\AccessDeniedException
     */
    protected function getAccessDeniedExceptionService()
    {
        $this->throw('Cannot autowire service ".service_locator.ISCZ1YP": it references class "Symfony\\Component\\Security\\Core\\Exception\\AccessDeniedException" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.ItH1Gr..DateTime' shared service.
     *
     * @return \DateTime
     */
    protected function get_Errored__ServiceLocator_ItH1Gr__DateTimeService()
    {
        $this->throw('Cannot autowire service ".service_locator.ItH1Gr.": it references class "DateTime" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.KinxmXU.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs2Service()
    {
        $this->throw('Cannot autowire service ".service_locator.KinxmXU": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.LhOy3Zo.App\Entity\Delivery' shared service.
     *
     * @return \App\Entity\Delivery
     */
    protected function getDeliveryService()
    {
        $this->throw('Cannot autowire service ".service_locator.LhOy3Zo": it references class "App\\Entity\\Delivery" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.MtlBFkc.App\Entity\ChicksRecipient' shared service.
     *
     * @return \App\Entity\ChicksRecipient
     */
    protected function getChicksRecipient2Service()
    {
        $this->throw('Cannot autowire service ".service_locator.MtlBFkc": it references class "App\\Entity\\ChicksRecipient" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.NBaPSWt.App\Entity\InputDelivery' shared service.
     *
     * @return \App\Entity\InputDelivery
     */
    protected function getInputDeliveryService()
    {
        $this->throw('Cannot autowire service ".service_locator.NBaPSWt": it references class "App\\Entity\\InputDelivery" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.QQJCbua.App\Entity\Herds' shared service.
     *
     * @return \App\Entity\Herds
     */
    protected function getHerds2Service()
    {
        $this->throw('Cannot autowire service ".service_locator.QQJCbua": it references class "App\\Entity\\Herds" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.RVTGs6k.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs3Service()
    {
        $this->throw('Cannot autowire service ".service_locator.RVTGs6k": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.RVTGs6k.App\Entity\InputsFarm' shared service.
     *
     * @return \App\Entity\InputsFarm
     */
    protected function getInputsFarm2Service()
    {
        $this->throw('Cannot autowire service ".service_locator.RVTGs6k": it references class "App\\Entity\\InputsFarm" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.T6odLp1.App\Entity\PlanDeliveryEgg' shared service.
     *
     * @return \App\Entity\PlanDeliveryEgg
     */
    protected function getPlanDeliveryEggService()
    {
        $this->throw('Cannot autowire service ".service_locator.T6odLp1": it references class "App\\Entity\\PlanDeliveryEgg" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.UziN_hh.App\Entity\Selections' shared service.
     *
     * @return \App\Entity\Selections
     */
    protected function getSelectionsService()
    {
        $this->throw('Cannot autowire service ".service_locator.UziN_hh": it references class "App\\Entity\\Selections" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.VF1w2VI.App\Entity\Herds' shared service.
     *
     * @return \App\Entity\Herds
     */
    protected function getHerds3Service()
    {
        $this->throw('Cannot autowire service ".service_locator.VF1w2VI": it references class "App\\Entity\\Herds" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.VrKIhbE.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs4Service()
    {
        $this->throw('Cannot autowire service ".service_locator.VrKIhbE": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.W.YOCo6.App\Entity\ChicksRecipient' shared service.
     *
     * @return \App\Entity\ChicksRecipient
     */
    protected function getChicksRecipient3Service()
    {
        $this->throw('Cannot autowire service ".service_locator.W.YOCo6": it references class "App\\Entity\\ChicksRecipient" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.YVUVBTC.App\Entity\Lighting' shared service.
     *
     * @return \App\Entity\Lighting
     */
    protected function getLightingService()
    {
        $this->throw('Cannot autowire service ".service_locator.YVUVBTC": it references class "App\\Entity\\Lighting" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator._1MUdwY.App\Entity\Supplier' shared service.
     *
     * @return \App\Entity\Supplier
     */
    protected function getSupplier2Service()
    {
        $this->throw('Cannot autowire service ".service_locator._1MUdwY": it references class "App\\Entity\\Supplier" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator._2Plx1P.App\Entity\Herds' shared service.
     *
     * @return \App\Entity\Herds
     */
    protected function getHerds4Service()
    {
        $this->throw('Cannot autowire service ".service_locator._2Plx1P": it references class "App\\Entity\\Herds" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator._OEZtLO.App\Entity\InputsFarm' shared service.
     *
     * @return \App\Entity\InputsFarm
     */
    protected function getInputsFarm3Service()
    {
        $this->throw('Cannot autowire service ".service_locator._OEZtLO": it references class "App\\Entity\\InputsFarm" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator._WYX_x_.App\Entity\PlanIndicators' shared service.
     *
     * @return \App\Entity\PlanIndicators
     */
    protected function getPlanIndicatorsService()
    {
        $this->throw('Cannot autowire service ".service_locator._WYX_x_": it references class "App\\Entity\\PlanIndicators" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.aPT4Rqb.App\Entity\ChickIntegration' shared service.
     *
     * @return \App\Entity\ChickIntegration
     */
    protected function getChickIntegrationService()
    {
        $this->throw('Cannot autowire service ".service_locator.aPT4Rqb": it references class "App\\Entity\\ChickIntegration" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.akaboVt.App\Entity\Delivery' shared service.
     *
     * @return \App\Entity\Delivery
     */
    protected function getDelivery2Service()
    {
        $this->throw('Cannot autowire service ".service_locator.akaboVt": it references class "App\\Entity\\Delivery" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.bov.xyt.App\Entity\Supplier' shared service.
     *
     * @return \App\Entity\Supplier
     */
    protected function getSupplier3Service()
    {
        $this->throw('Cannot autowire service ".service_locator.bov.xyt": it references class "App\\Entity\\Supplier" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.cQuFK9R.App\Entity\InputsFarmDeliveryPlan' shared service.
     *
     * @return \App\Entity\InputsFarmDeliveryPlan
     */
    protected function getInputsFarmDeliveryPlanService()
    {
        $this->throw('Cannot autowire service ".service_locator.cQuFK9R": it references class "App\\Entity\\InputsFarmDeliveryPlan" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.cYwVkCd.App\Entity\Hatchers' shared service.
     *
     * @return \App\Entity\Hatchers
     */
    protected function getHatchersService()
    {
        $this->throw('Cannot autowire service ".service_locator.cYwVkCd": it references class "App\\Entity\\Hatchers" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.dDx38tR.App\Entity\Herds' shared service.
     *
     * @return \App\Entity\Herds
     */
    protected function getHerds5Service()
    {
        $this->throw('Cannot autowire service ".service_locator.dDx38tR": it references class "App\\Entity\\Herds" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.fX4ImNz.App\Entity\Herds' shared service.
     *
     * @return \App\Entity\Herds
     */
    protected function getHerds6Service()
    {
        $this->throw('Cannot autowire service ".service_locator.fX4ImNz": it references class "App\\Entity\\Herds" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.fX4ImNz.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs5Service()
    {
        $this->throw('Cannot autowire service ".service_locator.fX4ImNz": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.fX4ImNz.App\Entity\InputsFarm' shared service.
     *
     * @return \App\Entity\InputsFarm
     */
    protected function getInputsFarm4Service()
    {
        $this->throw('Cannot autowire service ".service_locator.fX4ImNz": it references class "App\\Entity\\InputsFarm" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.g.guwk1.App\Entity\InputsFarm' shared service.
     *
     * @return \App\Entity\InputsFarm
     */
    protected function getInputsFarm5Service()
    {
        $this->throw('Cannot autowire service ".service_locator.g.guwk1": it references class "App\\Entity\\InputsFarm" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.hcga3N6.App\Entity\BreedStandard' shared service.
     *
     * @return \App\Entity\BreedStandard
     */
    protected function getBreedStandardService()
    {
        $this->throw('Cannot autowire service ".service_locator.hcga3N6": it references class "App\\Entity\\BreedStandard" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.hl5g9CG.App\Entity\Setters' shared service.
     *
     * @return \App\Entity\Setters
     */
    protected function getSettersService()
    {
        $this->throw('Cannot autowire service ".service_locator.hl5g9CG": it references class "App\\Entity\\Setters" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.kFWiiLA.App\Entity\SellingEgg' shared service.
     *
     * @return \App\Entity\SellingEgg
     */
    protected function getSellingEggService()
    {
        $this->throw('Cannot autowire service ".service_locator.kFWiiLA": it references class "App\\Entity\\SellingEgg" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.kgeYX4r.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs6Service()
    {
        $this->throw('Cannot autowire service ".service_locator.kgeYX4r": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.kgeYX4r.App\Entity\Supplier' shared service.
     *
     * @return \App\Entity\Supplier
     */
    protected function getSupplier4Service()
    {
        $this->throw('Cannot autowire service ".service_locator.kgeYX4r": it references class "App\\Entity\\Supplier" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.l1XZ2mI.App\Entity\Transfers' shared service.
     *
     * @return \App\Entity\Transfers
     */
    protected function getTransfersService()
    {
        $this->throw('Cannot autowire service ".service_locator.l1XZ2mI": it references class "App\\Entity\\Transfers" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.mQpOpia.App\Entity\Vaccination' shared service.
     *
     * @return \App\Entity\Vaccination
     */
    protected function getVaccinationService()
    {
        $this->throw('Cannot autowire service ".service_locator.mQpOpia": it references class "App\\Entity\\Vaccination" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.s_RWU_Q.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs7Service()
    {
        $this->throw('Cannot autowire service ".service_locator.s_RWU_Q": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.tIQ5Q0N.App\Entity\User' shared service.
     *
     * @return \App\Entity\User
     */
    protected function getUserService()
    {
        $this->throw('Cannot autowire service ".service_locator.tIQ5Q0N": it references class "App\\Entity\\User" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.ufDOk6W.App\Entity\Breed' shared service.
     *
     * @return \App\Entity\Breed
     */
    protected function getBreedService()
    {
        $this->throw('Cannot autowire service ".service_locator.ufDOk6W": it references class "App\\Entity\\Breed" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.uzilRCW.App\Entity\Car' shared service.
     *
     * @return \App\Entity\Car
     */
    protected function getCarService()
    {
        $this->throw('Cannot autowire service ".service_locator.uzilRCW": it references class "App\\Entity\\Car" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.v0RJ6N8.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs8Service()
    {
        $this->throw('Cannot autowire service ".service_locator.v0RJ6N8": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.xh.Ejip.App\Entity\Herds' shared service.
     *
     * @return \App\Entity\Herds
     */
    protected function getHerds7Service()
    {
        $this->throw('Cannot autowire service ".service_locator.xh.Ejip": it references class "App\\Entity\\Herds" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.xh.Ejip.App\Entity\Inputs' shared service.
     *
     * @return \App\Entity\Inputs
     */
    protected function getInputs9Service()
    {
        $this->throw('Cannot autowire service ".service_locator.xh.Ejip": it references class "App\\Entity\\Inputs" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.yZPm2Ey.App\Entity\ContactInfo' shared service.
     *
     * @return \App\Entity\ContactInfo
     */
    protected function getContactInfoService()
    {
        $this->throw('Cannot autowire service ".service_locator.yZPm2Ey": it references class "App\\Entity\\ContactInfo" but no such service exists.');
    }

    /*
     * Gets the private '.errored..service_locator.z1yUq3Y.App\Entity\PlanDeliveryChick' shared service.
     *
     * @return \App\Entity\PlanDeliveryChick
     */
    protected function getPlanDeliveryChickService()
    {
        $this->throw('Cannot autowire service ".service_locator.z1yUq3Y": it references class "App\\Entity\\PlanDeliveryChick" but no such service exists.');
    }

    /*
     * Gets the private '.legacy_resolve_controller_name_subscriber' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\EventListener\ResolveControllerNameSubscriber
     */
    protected function get_LegacyResolveControllerNameSubscriberService()
    {
        return $this->privates['.legacy_resolve_controller_name_subscriber'] = new \Symfony\Bundle\FrameworkBundle\EventListener\ResolveControllerNameSubscriber(($this->privates['.legacy_controller_name_converter'] ?? ($this->privates['.legacy_controller_name_converter'] = new \Symfony\Bundle\FrameworkBundle\Controller\ControllerNameParser(($this->services['kernel'] ?? $this->get('kernel', 1)), false))), false);
    }

    /*
     * Gets the private '.service_locator.0RTtFZW' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_0RTtFZWService()
    {
        return $this->privates['.service_locator.0RTtFZW'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inputs' => ['privates', '.errored..service_locator.0RTtFZW.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.0RTtFZW": it references class "App\\Entity\\Inputs" but no such service exists.'],
        ], [
            'inputs' => 'App\\Entity\\Inputs',
        ]);
    }

    /*
     * Gets the private '.service_locator.1UuH9tO' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_1UuH9tOService()
    {
        return $this->privates['.service_locator.1UuH9tO'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'userRepository' => ['privates', 'App\\Repository\\UserRepository', 'getUserRepositoryService', false],
        ], [
            'userRepository' => 'App\\Repository\\UserRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.2ViFXR5' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_2ViFXR5Service()
    {
        return $this->privates['.service_locator.2ViFXR5'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInputsRepository' => ['privates', 'App\\Repository\\InputsRepository', 'getInputsRepositoryService', false],
        ], [
            'eggsInputsRepository' => 'App\\Repository\\InputsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.3fPcA2g' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_3fPcA2gService()
    {
        return $this->privates['.service_locator.3fPcA2g'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planDeliveryEggRepository' => ['privates', 'App\\Repository\\PlanDeliveryEggRepository', 'getPlanDeliveryEggRepositoryService', false],
        ], [
            'planDeliveryEggRepository' => 'App\\Repository\\PlanDeliveryEggRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.4gHrsrg' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_4gHrsrgService()
    {
        return $this->privates['.service_locator.4gHrsrg'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'driver' => ['privates', '.errored..service_locator.4gHrsrg.App\\Entity\\Driver', NULL, 'Cannot autowire service ".service_locator.4gHrsrg": it references class "App\\Entity\\Driver" but no such service exists.'],
        ], [
            'driver' => 'App\\Entity\\Driver',
        ]);
    }

    /*
     * Gets the private '.service_locator.51x_oDo' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_51xODoService()
    {
        return $this->privates['.service_locator.51x_oDo'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'transportList' => ['privates', '.errored..service_locator.51x_oDo.App\\Entity\\TransportList', NULL, 'Cannot autowire service ".service_locator.51x_oDo": it references class "App\\Entity\\TransportList" but no such service exists.'],
        ], [
            'transportList' => 'App\\Entity\\TransportList',
        ]);
    }

    /*
     * Gets the private '.service_locator.6Vugu6d' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_6Vugu6dService()
    {
        return $this->privates['.service_locator.6Vugu6d'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inputDeliveryRepository' => ['privates', 'App\\Repository\\InputDeliveryRepository', 'getInputDeliveryRepositoryService', false],
        ], [
            'inputDeliveryRepository' => 'App\\Repository\\InputDeliveryRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.6uRO9y9' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_6uRO9y9Service()
    {
        return $this->privates['.service_locator.6uRO9y9'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planInput' => ['privates', '.errored..service_locator.6uRO9y9.App\\Entity\\PlanInput', NULL, 'Cannot autowire service ".service_locator.6uRO9y9": it references class "App\\Entity\\PlanInput" but no such service exists.'],
        ], [
            'planInput' => 'App\\Entity\\PlanInput',
        ]);
    }

    /*
     * Gets the private '.service_locator.7GGDOJU' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_7GGDOJUService()
    {
        return $this->privates['.service_locator.7GGDOJU'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'deliveryRepository' => ['privates', 'App\\Repository\\DeliveryRepository', 'getDeliveryRepositoryService', false],
            'herd' => ['privates', '.errored..service_locator.7GGDOJU.App\\Entity\\Herds', NULL, 'Cannot autowire service ".service_locator.7GGDOJU": it references class "App\\Entity\\Herds" but no such service exists.'],
            'inputDeliveryRepository' => ['privates', 'App\\Repository\\InputDeliveryRepository', 'getInputDeliveryRepositoryService', false],
        ], [
            'deliveryRepository' => 'App\\Repository\\DeliveryRepository',
            'herd' => 'App\\Entity\\Herds',
            'inputDeliveryRepository' => 'App\\Repository\\InputDeliveryRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.7NSCnyQ' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_7NSCnyQService()
    {
        return $this->privates['.service_locator.7NSCnyQ'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'customer' => ['privates', '.errored..service_locator.7NSCnyQ.App\\Entity\\Customer', NULL, 'Cannot autowire service ".service_locator.7NSCnyQ": it references class "App\\Entity\\Customer" but no such service exists.'],
        ], [
            'customer' => 'App\\Entity\\Customer',
        ]);
    }

    /*
     * Gets the private '.service_locator.7npc7Mc' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_7npc7McService()
    {
        return $this->privates['.service_locator.7npc7Mc'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planInputRepository' => ['privates', 'App\\Repository\\PlanInputRepository', 'getPlanInputRepositoryService', false],
        ], [
            'planInputRepository' => 'App\\Repository\\PlanInputRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.8ZuNAXa' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_8ZuNAXaService()
    {
        return $this->privates['.service_locator.8ZuNAXa'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'mailer' => ['services', 'swiftmailer.mailer.default', 'getSwiftmailer_Mailer_DefaultService', false],
        ], [
            'mailer' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.8pMVo_M' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_8pMVoMService()
    {
        return $this->privates['.service_locator.8pMVo_M'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'hatchersRepository' => ['privates', 'App\\Repository\\HatchersRepository', 'getHatchersRepositoryService', false],
        ], [
            'hatchersRepository' => 'App\\Repository\\HatchersRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.9I6nq7p' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_9I6nq7pService()
    {
        return $this->privates['.service_locator.9I6nq7p'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'sellingEggRepository' => ['privates', 'App\\Repository\\SellingEggRepository', 'getSellingEggRepositoryService', false],
        ], [
            'sellingEggRepository' => 'App\\Repository\\SellingEggRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.9YaQrws' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_9YaQrwsService()
    {
        return $this->privates['.service_locator.9YaQrws'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planDeliveryChickRepository' => ['privates', 'App\\Repository\\PlanDeliveryChickRepository', 'getPlanDeliveryChickRepositoryService', false],
            'planIndicatorsRepository' => ['privates', 'App\\Repository\\PlanIndicatorsRepository', 'getPlanIndicatorsRepositoryService', false],
        ], [
            'planDeliveryChickRepository' => 'App\\Repository\\PlanDeliveryChickRepository',
            'planIndicatorsRepository' => 'App\\Repository\\PlanIndicatorsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.A0OcCfX' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_A0OcCfXService()
    {
        return $this->privates['.service_locator.A0OcCfX'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggSupplierRepository' => ['privates', 'App\\Repository\\SupplierRepository', 'getSupplierRepositoryService', false],
            'herdsRepository' => ['privates', 'App\\Repository\\HerdsRepository', 'getHerdsRepositoryService', false],
        ], [
            'eggSupplierRepository' => 'App\\Repository\\SupplierRepository',
            'herdsRepository' => 'App\\Repository\\HerdsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.A8uXX_2' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_A8uXX2Service()
    {
        return $this->privates['.service_locator.A8uXX_2'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggSupplier' => ['privates', '.errored..service_locator.A8uXX_2.App\\Entity\\Supplier', NULL, 'Cannot autowire service ".service_locator.A8uXX_2": it references class "App\\Entity\\Supplier" but no such service exists.'],
        ], [
            'eggSupplier' => 'App\\Entity\\Supplier',
        ]);
    }

    /*
     * Gets the private '.service_locator.Ayv8Hbr' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Ayv8HbrService()
    {
        return $this->privates['.service_locator.Ayv8Hbr'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'contactInfoRepository' => ['privates', 'App\\Repository\\ContactInfoRepository', 'getContactInfoRepositoryService', false],
        ], [
            'contactInfoRepository' => 'App\\Repository\\ContactInfoRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.BKc.8Yh' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_BKc_8YhService()
    {
        return $this->privates['.service_locator.BKc.8Yh'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'farm' => ['privates', '.errored..service_locator.BKc.8Yh.App\\Entity\\InputsFarm', NULL, 'Cannot autowire service ".service_locator.BKc.8Yh": it references class "App\\Entity\\InputsFarm" but no such service exists.'],
            'inputsFarmDeliveryPlanRepository' => ['privates', 'App\\Repository\\InputsFarmDeliveryPlanRepository', 'getInputsFarmDeliveryPlanRepositoryService', false],
        ], [
            'farm' => 'App\\Entity\\InputsFarm',
            'inputsFarmDeliveryPlanRepository' => 'App\\Repository\\InputsFarmDeliveryPlanRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.BnM8aS0' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_BnM8aS0Service()
    {
        return $this->privates['.service_locator.BnM8aS0'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'supplierRepository' => ['privates', 'App\\Repository\\SupplierRepository', 'getSupplierRepositoryService', false],
        ], [
            'supplierRepository' => 'App\\Repository\\SupplierRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.CQ5DlG.' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_CQ5DlG_Service()
    {
        return $this->privates['.service_locator.CQ5DlG.'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'settersRepository' => ['privates', 'App\\Repository\\SettersRepository', 'getSettersRepositoryService', false],
        ], [
            'settersRepository' => 'App\\Repository\\SettersRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.CWSFabL' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_CWSFabLService()
    {
        return $this->privates['.service_locator.CWSFabL'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chicksRecipientRepository' => ['privates', 'App\\Repository\\ChicksRecipientRepository', 'getChicksRecipientRepositoryService', false],
            'pdf' => ['services', 'knp_snappy.pdf', 'getKnpSnappy_PdfService', false],
        ], [
            'chicksRecipientRepository' => 'App\\Repository\\ChicksRecipientRepository',
            'pdf' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.DckF3wx' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_DckF3wxService()
    {
        return $this->privates['.service_locator.DckF3wx'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsSelectionsRepository' => ['privates', 'App\\Repository\\SelectionsRepository', 'getSelectionsRepositoryService', false],
        ], [
            'eggsSelectionsRepository' => 'App\\Repository\\SelectionsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.DjlexR7' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_DjlexR7Service()
    {
        return $this->privates['.service_locator.DjlexR7'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chicksRecipientRepository' => ['privates', 'App\\Repository\\ChicksRecipientRepository', 'getChicksRecipientRepositoryService', false],
            'customerRepository' => ['privates', 'App\\Repository\\CustomerRepository', 'getCustomerRepositoryService', false],
        ], [
            'chicksRecipientRepository' => 'App\\Repository\\ChicksRecipientRepository',
            'customerRepository' => 'App\\Repository\\CustomerRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.Dn9kS4t' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Dn9kS4tService()
    {
        return $this->privates['.service_locator.Dn9kS4t'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chickTemperature' => ['privates', '.errored..service_locator.Dn9kS4t.App\\Entity\\ChickTemperature', NULL, 'Cannot autowire service ".service_locator.Dn9kS4t": it references class "App\\Entity\\ChickTemperature" but no such service exists.'],
        ], [
            'chickTemperature' => 'App\\Entity\\ChickTemperature',
        ]);
    }

    /*
     * Gets the private '.service_locator.FrSsn8W' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_FrSsn8WService()
    {
        return $this->privates['.service_locator.FrSsn8W'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsDeliveryRepository' => ['privates', 'App\\Repository\\DeliveryRepository', 'getDeliveryRepositoryService', false],
            'inputDeliveryRepository' => ['privates', 'App\\Repository\\InputDeliveryRepository', 'getInputDeliveryRepositoryService', false],
            'sellingEggRepository' => ['privates', 'App\\Repository\\SellingEggRepository', 'getSellingEggRepositoryService', false],
        ], [
            'eggsDeliveryRepository' => 'App\\Repository\\DeliveryRepository',
            'inputDeliveryRepository' => 'App\\Repository\\InputDeliveryRepository',
            'sellingEggRepository' => 'App\\Repository\\SellingEggRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.G4rkM_4' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_G4rkM4Service()
    {
        return $this->privates['.service_locator.G4rkM_4'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chicksRecipient' => ['privates', '.errored..service_locator.G4rkM_4.App\\Entity\\ChicksRecipient', NULL, 'Cannot autowire service ".service_locator.G4rkM_4": it references class "App\\Entity\\ChicksRecipient" but no such service exists.'],
            'repository' => ['privates', 'App\\Repository\\ChicksRecipientRepository', 'getChicksRecipientRepositoryService', false],
        ], [
            'chicksRecipient' => 'App\\Entity\\ChicksRecipient',
            'repository' => 'App\\Repository\\ChicksRecipientRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.ISCZ1YP' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_ISCZ1YPService()
    {
        return $this->privates['.service_locator.ISCZ1YP'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'accessDeniedException' => ['privates', '.errored..service_locator.ISCZ1YP.Symfony\\Component\\Security\\Core\\Exception\\AccessDeniedException', NULL, 'Cannot autowire service ".service_locator.ISCZ1YP": it references class "Symfony\\Component\\Security\\Core\\Exception\\AccessDeniedException" but no such service exists.'],
        ], [
            'accessDeniedException' => 'Symfony\\Component\\Security\\Core\\Exception\\AccessDeniedException',
        ]);
    }

    /*
     * Gets the private '.service_locator.ItH1Gr.' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_ItH1Gr_Service()
    {
        return $this->privates['.service_locator.ItH1Gr.'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'date' => ['privates', '.errored..service_locator.ItH1Gr..DateTime', NULL, 'Cannot autowire service ".service_locator.ItH1Gr.": it references class "DateTime" but no such service exists.'],
            'deliveryEggRepository' => ['privates', 'App\\Repository\\PlanDeliveryEggRepository', 'getPlanDeliveryEggRepositoryService', false],
            'supplierRepository' => ['privates', 'App\\Repository\\SupplierRepository', 'getSupplierRepositoryService', false],
        ], [
            'date' => 'DateTime',
            'deliveryEggRepository' => 'App\\Repository\\PlanDeliveryEggRepository',
            'supplierRepository' => 'App\\Repository\\SupplierRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.KfFw_BS' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_KfFwBSService()
    {
        return $this->privates['.service_locator.KfFw_BS'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'herdsRepository' => ['privates', 'App\\Repository\\HerdsRepository', 'getHerdsRepositoryService', false],
        ], [
            'herdsRepository' => 'App\\Repository\\HerdsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.KinxmXU' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_KinxmXUService()
    {
        return $this->privates['.service_locator.KinxmXU'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInput' => ['privates', '.errored..service_locator.KinxmXU.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.KinxmXU": it references class "App\\Entity\\Inputs" but no such service exists.'],
            'farmRepository' => ['privates', 'App\\Repository\\InputsFarmRepository', 'getInputsFarmRepositoryService', false],
            'herdsRepository' => ['privates', 'App\\Repository\\HerdsRepository', 'getHerdsRepositoryService', false],
        ], [
            'eggsInput' => 'App\\Entity\\Inputs',
            'farmRepository' => 'App\\Repository\\InputsFarmRepository',
            'herdsRepository' => 'App\\Repository\\HerdsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.Kpi1dqa' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Kpi1dqaService()
    {
        return $this->privates['.service_locator.Kpi1dqa'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'reader' => ['privates', 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Reader\\Reader', 'getReaderService', false],
        ], [
            'reader' => 'DH\\Auditor\\Provider\\Doctrine\\Persistence\\Reader\\Reader',
        ]);
    }

    /*
     * Gets the private '.service_locator.LhOy3Zo' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_LhOy3ZoService()
    {
        return $this->privates['.service_locator.LhOy3Zo'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'delivery' => ['privates', '.errored..service_locator.LhOy3Zo.App\\Entity\\Delivery', NULL, 'Cannot autowire service ".service_locator.LhOy3Zo": it references class "App\\Entity\\Delivery" but no such service exists.'],
        ], [
            'delivery' => 'App\\Entity\\Delivery',
        ]);
    }

    /*
     * Gets the private '.service_locator.MtlBFkc' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_MtlBFkcService()
    {
        return $this->privates['.service_locator.MtlBFkc'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chicksRecipient' => ['privates', '.errored..service_locator.MtlBFkc.App\\Entity\\ChicksRecipient', NULL, 'Cannot autowire service ".service_locator.MtlBFkc": it references class "App\\Entity\\ChicksRecipient" but no such service exists.'],
        ], [
            'chicksRecipient' => 'App\\Entity\\ChicksRecipient',
        ]);
    }

    /*
     * Gets the private '.service_locator.NBaPSWt' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_NBaPSWtService()
    {
        return $this->privates['.service_locator.NBaPSWt'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inputDelivery' => ['privates', '.errored..service_locator.NBaPSWt.App\\Entity\\InputDelivery', NULL, 'Cannot autowire service ".service_locator.NBaPSWt": it references class "App\\Entity\\InputDelivery" but no such service exists.'],
        ], [
            'inputDelivery' => 'App\\Entity\\InputDelivery',
        ]);
    }

    /*
     * Gets the private '.service_locator.OaAVb7K' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_OaAVb7KService()
    {
        return $this->privates['.service_locator.OaAVb7K'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'carRepository' => ['privates', 'App\\Repository\\CarRepository', 'getCarRepositoryService', false],
        ], [
            'carRepository' => 'App\\Repository\\CarRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.QQJCbua' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_QQJCbuaService()
    {
        return $this->privates['.service_locator.QQJCbua'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'herd' => ['privates', '.errored..service_locator.QQJCbua.App\\Entity\\Herds', NULL, 'Cannot autowire service ".service_locator.QQJCbua": it references class "App\\Entity\\Herds" but no such service exists.'],
            'mailer' => ['privates', 'mailer.mailer', 'getMailer_MailerService', false],
        ], [
            'herd' => 'App\\Entity\\Herds',
            'mailer' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.RVTGs6k' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_RVTGs6kService()
    {
        return $this->privates['.service_locator.RVTGs6k'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'farm' => ['privates', '.errored..service_locator.RVTGs6k.App\\Entity\\InputsFarm', NULL, 'Cannot autowire service ".service_locator.RVTGs6k": it references class "App\\Entity\\InputsFarm" but no such service exists.'],
            'inputs' => ['privates', '.errored..service_locator.RVTGs6k.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.RVTGs6k": it references class "App\\Entity\\Inputs" but no such service exists.'],
        ], [
            'farm' => 'App\\Entity\\InputsFarm',
            'inputs' => 'App\\Entity\\Inputs',
        ]);
    }

    /*
     * Gets the private '.service_locator.T6odLp1' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_T6odLp1Service()
    {
        return $this->privates['.service_locator.T6odLp1'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planDeliveryEgg' => ['privates', '.errored..service_locator.T6odLp1.App\\Entity\\PlanDeliveryEgg', NULL, 'Cannot autowire service ".service_locator.T6odLp1": it references class "App\\Entity\\PlanDeliveryEgg" but no such service exists.'],
        ], [
            'planDeliveryEgg' => 'App\\Entity\\PlanDeliveryEgg',
        ]);
    }

    /*
     * Gets the private '.service_locator.UubWFXd' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_UubWFXdService()
    {
        return $this->privates['.service_locator.UubWFXd'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'breedStandardRepository' => ['privates', 'App\\Repository\\BreedStandardRepository', 'getBreedStandardRepositoryService', false],
        ], [
            'breedStandardRepository' => 'App\\Repository\\BreedStandardRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.UziN_hh' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_UziNHhService()
    {
        return $this->privates['.service_locator.UziN_hh'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsSelection' => ['privates', '.errored..service_locator.UziN_hh.App\\Entity\\Selections', NULL, 'Cannot autowire service ".service_locator.UziN_hh": it references class "App\\Entity\\Selections" but no such service exists.'],
        ], [
            'eggsSelection' => 'App\\Entity\\Selections',
        ]);
    }

    /*
     * Gets the private '.service_locator.VF1w2VI' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_VF1w2VIService()
    {
        return $this->privates['.service_locator.VF1w2VI'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'herd' => ['privates', '.errored..service_locator.VF1w2VI.App\\Entity\\Herds', NULL, 'Cannot autowire service ".service_locator.VF1w2VI": it references class "App\\Entity\\Herds" but no such service exists.'],
            'pdf' => ['services', 'knp_snappy.pdf', 'getKnpSnappy_PdfService', false],
            'translator' => ['services', 'translator', 'getTranslatorService', false],
        ], [
            'herd' => 'App\\Entity\\Herds',
            'pdf' => '?',
            'translator' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.VrKIhbE' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_VrKIhbEService()
    {
        return $this->privates['.service_locator.VrKIhbE'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInput' => ['privates', '.errored..service_locator.VrKIhbE.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.VrKIhbE": it references class "App\\Entity\\Inputs" but no such service exists.'],
        ], [
            'eggsInput' => 'App\\Entity\\Inputs',
        ]);
    }

    /*
     * Gets the private '.service_locator.W.YOCo6' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_W_YOCo6Service()
    {
        return $this->privates['.service_locator.W.YOCo6'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'farm' => ['privates', '.errored..service_locator.W.YOCo6.App\\Entity\\ChicksRecipient', NULL, 'Cannot autowire service ".service_locator.W.YOCo6": it references class "App\\Entity\\ChicksRecipient" but no such service exists.'],
            'planDeliveryChickRepository' => ['privates', 'App\\Repository\\PlanDeliveryChickRepository', 'getPlanDeliveryChickRepositoryService', false],
            'planIndicatorsRepository' => ['privates', 'App\\Repository\\PlanIndicatorsRepository', 'getPlanIndicatorsRepositoryService', false],
        ], [
            'farm' => 'App\\Entity\\ChicksRecipient',
            'planDeliveryChickRepository' => 'App\\Repository\\PlanDeliveryChickRepository',
            'planIndicatorsRepository' => 'App\\Repository\\PlanIndicatorsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.WiUKNEm' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_WiUKNEmService()
    {
        return $this->privates['.service_locator.WiUKNEm'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'deliveryRepository' => ['privates', 'App\\Repository\\DeliveryRepository', 'getDeliveryRepositoryService', false],
            'inputsDeliveryRepository' => ['privates', 'App\\Repository\\InputDeliveryRepository', 'getInputDeliveryRepositoryService', false],
            'sellingEggRepository' => ['privates', 'App\\Repository\\SellingEggRepository', 'getSellingEggRepositoryService', false],
            'supplierRepository' => ['privates', 'App\\Repository\\SupplierRepository', 'getSupplierRepositoryService', false],
        ], [
            'deliveryRepository' => 'App\\Repository\\DeliveryRepository',
            'inputsDeliveryRepository' => 'App\\Repository\\InputDeliveryRepository',
            'sellingEggRepository' => 'App\\Repository\\SellingEggRepository',
            'supplierRepository' => 'App\\Repository\\SupplierRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.YVUVBTC' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_YVUVBTCService()
    {
        return $this->privates['.service_locator.YVUVBTC'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'lighting' => ['privates', '.errored..service_locator.YVUVBTC.App\\Entity\\Lighting', NULL, 'Cannot autowire service ".service_locator.YVUVBTC": it references class "App\\Entity\\Lighting" but no such service exists.'],
        ], [
            'lighting' => 'App\\Entity\\Lighting',
        ]);
    }

    /*
     * Gets the private '.service_locator.YjdEfJn' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_YjdEfJnService()
    {
        return $this->privates['.service_locator.YjdEfJn'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInputsTransfersRepository' => ['privates', 'App\\Repository\\TransfersRepository', 'getTransfersRepositoryService', false],
        ], [
            'eggsInputsTransfersRepository' => 'App\\Repository\\TransfersRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator._1MUdwY' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_1MUdwYService()
    {
        return $this->privates['.service_locator._1MUdwY'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'deliveryEggRepository' => ['privates', 'App\\Repository\\PlanDeliveryEggRepository', 'getPlanDeliveryEggRepositoryService', false],
            'supplier' => ['privates', '.errored..service_locator._1MUdwY.App\\Entity\\Supplier', NULL, 'Cannot autowire service ".service_locator._1MUdwY": it references class "App\\Entity\\Supplier" but no such service exists.'],
        ], [
            'deliveryEggRepository' => 'App\\Repository\\PlanDeliveryEggRepository',
            'supplier' => 'App\\Entity\\Supplier',
        ]);
    }

    /*
     * Gets the private '.service_locator._2Plx1P' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_2Plx1PService()
    {
        return $this->privates['.service_locator._2Plx1P'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'herd' => ['privates', '.errored..service_locator._2Plx1P.App\\Entity\\Herds', NULL, 'Cannot autowire service ".service_locator._2Plx1P": it references class "App\\Entity\\Herds" but no such service exists.'],
        ], [
            'herd' => 'App\\Entity\\Herds',
        ]);
    }

    /*
     * Gets the private '.service_locator._OEZtLO' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_OEZtLOService()
    {
        return $this->privates['.service_locator._OEZtLO'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'deliveryRepository' => ['privates', 'App\\Repository\\DeliveryRepository', 'getDeliveryRepositoryService', false],
            'farm' => ['privates', '.errored..service_locator._OEZtLO.App\\Entity\\InputsFarm', NULL, 'Cannot autowire service ".service_locator._OEZtLO": it references class "App\\Entity\\InputsFarm" but no such service exists.'],
            'inputsFarmDeliveryPlanRepository' => ['privates', 'App\\Repository\\InputsFarmDeliveryPlanRepository', 'getInputsFarmDeliveryPlanRepositoryService', false],
        ], [
            'deliveryRepository' => 'App\\Repository\\DeliveryRepository',
            'farm' => 'App\\Entity\\InputsFarm',
            'inputsFarmDeliveryPlanRepository' => 'App\\Repository\\InputsFarmDeliveryPlanRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator._WYX_x_' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_WYXXService()
    {
        return $this->privates['.service_locator._WYX_x_'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planIndicator' => ['privates', '.errored..service_locator._WYX_x_.App\\Entity\\PlanIndicators', NULL, 'Cannot autowire service ".service_locator._WYX_x_": it references class "App\\Entity\\PlanIndicators" but no such service exists.'],
        ], [
            'planIndicator' => 'App\\Entity\\PlanIndicators',
        ]);
    }

    /*
     * Gets the private '.service_locator._aCulUr' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_ACulUrService()
    {
        return $this->privates['.service_locator._aCulUr'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'hatchersRepository' => ['privates', 'App\\Repository\\HatchersRepository', 'getHatchersRepositoryService', false],
            'settersRepository' => ['privates', 'App\\Repository\\SettersRepository', 'getSettersRepositoryService', false],
        ], [
            'hatchersRepository' => 'App\\Repository\\HatchersRepository',
            'settersRepository' => 'App\\Repository\\SettersRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.aCqsVwX' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_ACqsVwXService()
    {
        return $this->privates['.service_locator.aCqsVwX'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'vaccinationRepository' => ['privates', 'App\\Repository\\VaccinationRepository', 'getVaccinationRepositoryService', false],
        ], [
            'vaccinationRepository' => 'App\\Repository\\VaccinationRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.aPT4Rqb' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_APT4RqbService()
    {
        return $this->privates['.service_locator.aPT4Rqb'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chickIntegration' => ['privates', '.errored..service_locator.aPT4Rqb.App\\Entity\\ChickIntegration', NULL, 'Cannot autowire service ".service_locator.aPT4Rqb": it references class "App\\Entity\\ChickIntegration" but no such service exists.'],
        ], [
            'chickIntegration' => 'App\\Entity\\ChickIntegration',
        ]);
    }

    /*
     * Gets the private '.service_locator.ab94eYl' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Ab94eYlService()
    {
        return $this->privates['.service_locator.ab94eYl'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planIndicatorsRepository' => ['privates', 'App\\Repository\\PlanIndicatorsRepository', 'getPlanIndicatorsRepositoryService', false],
        ], [
            'planIndicatorsRepository' => 'App\\Repository\\PlanIndicatorsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.akaboVt' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_AkaboVtService()
    {
        return $this->privates['.service_locator.akaboVt'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsDelivery' => ['privates', '.errored..service_locator.akaboVt.App\\Entity\\Delivery', NULL, 'Cannot autowire service ".service_locator.akaboVt": it references class "App\\Entity\\Delivery" but no such service exists.'],
        ], [
            'eggsDelivery' => 'App\\Entity\\Delivery',
        ]);
    }

    /*
     * Gets the private '.service_locator.bov.xyt' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Bov_XytService()
    {
        return $this->privates['.service_locator.bov.xyt'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'supplier' => ['privates', '.errored..service_locator.bov.xyt.App\\Entity\\Supplier', NULL, 'Cannot autowire service ".service_locator.bov.xyt": it references class "App\\Entity\\Supplier" but no such service exists.'],
        ], [
            'supplier' => 'App\\Entity\\Supplier',
        ]);
    }

    /*
     * Gets the private '.service_locator.cQuFK9R' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_CQuFK9RService()
    {
        return $this->privates['.service_locator.cQuFK9R'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inputsFarmDeliveryPlan' => ['privates', '.errored..service_locator.cQuFK9R.App\\Entity\\InputsFarmDeliveryPlan', NULL, 'Cannot autowire service ".service_locator.cQuFK9R": it references class "App\\Entity\\InputsFarmDeliveryPlan" but no such service exists.'],
        ], [
            'inputsFarmDeliveryPlan' => 'App\\Entity\\InputsFarmDeliveryPlan',
        ]);
    }

    /*
     * Gets the private '.service_locator.cVn5ICU' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_CVn5ICUService()
    {
        return $this->privates['.service_locator.cVn5ICU'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'transportListRepository' => ['privates', 'App\\Repository\\TransportListRepository', 'getTransportListRepositoryService', false],
        ], [
            'transportListRepository' => 'App\\Repository\\TransportListRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.cYwVkCd' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_CYwVkCdService()
    {
        return $this->privates['.service_locator.cYwVkCd'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'hatcher' => ['privates', '.errored..service_locator.cYwVkCd.App\\Entity\\Hatchers', NULL, 'Cannot autowire service ".service_locator.cYwVkCd": it references class "App\\Entity\\Hatchers" but no such service exists.'],
        ], [
            'hatcher' => 'App\\Entity\\Hatchers',
        ]);
    }

    /*
     * Gets the private '.service_locator.ccM2MGC' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_CcM2MGCService()
    {
        return $this->privates['.service_locator.ccM2MGC'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'passwordEncoder' => ['services', 'security.password_encoder', 'getSecurity_PasswordEncoderService', false],
        ], [
            'passwordEncoder' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.dDx38tR' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_DDx38tRService()
    {
        return $this->privates['.service_locator.dDx38tR'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'herds' => ['privates', '.errored..service_locator.dDx38tR.App\\Entity\\Herds', NULL, 'Cannot autowire service ".service_locator.dDx38tR": it references class "App\\Entity\\Herds" but no such service exists.'],
        ], [
            'herds' => 'App\\Entity\\Herds',
        ]);
    }

    /*
     * Gets the private '.service_locator.fX4ImNz' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_FX4ImNzService()
    {
        return $this->privates['.service_locator.fX4ImNz'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'farm' => ['privates', '.errored..service_locator.fX4ImNz.App\\Entity\\InputsFarm', NULL, 'Cannot autowire service ".service_locator.fX4ImNz": it references class "App\\Entity\\InputsFarm" but no such service exists.'],
            'herd' => ['privates', '.errored..service_locator.fX4ImNz.App\\Entity\\Herds', NULL, 'Cannot autowire service ".service_locator.fX4ImNz": it references class "App\\Entity\\Herds" but no such service exists.'],
            'inputs' => ['privates', '.errored..service_locator.fX4ImNz.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.fX4ImNz": it references class "App\\Entity\\Inputs" but no such service exists.'],
        ], [
            'farm' => 'App\\Entity\\InputsFarm',
            'herd' => 'App\\Entity\\Herds',
            'inputs' => 'App\\Entity\\Inputs',
        ]);
    }

    /*
     * Gets the private '.service_locator.g.guwk1' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_G_Guwk1Service()
    {
        return $this->privates['.service_locator.g.guwk1'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inputsFarm' => ['privates', '.errored..service_locator.g.guwk1.App\\Entity\\InputsFarm', NULL, 'Cannot autowire service ".service_locator.g.guwk1": it references class "App\\Entity\\InputsFarm" but no such service exists.'],
        ], [
            'inputsFarm' => 'App\\Entity\\InputsFarm',
        ]);
    }

    /*
     * Gets the private '.service_locator.g.xob4v' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_G_Xob4vService()
    {
        return $this->privates['.service_locator.g.xob4v'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'authenticationUtils' => ['services', 'security.authentication_utils', 'getSecurity_AuthenticationUtilsService', false],
        ], [
            'authenticationUtils' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.hcga3N6' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Hcga3N6Service()
    {
        return $this->privates['.service_locator.hcga3N6'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'breedStandard' => ['privates', '.errored..service_locator.hcga3N6.App\\Entity\\BreedStandard', NULL, 'Cannot autowire service ".service_locator.hcga3N6": it references class "App\\Entity\\BreedStandard" but no such service exists.'],
        ], [
            'breedStandard' => 'App\\Entity\\BreedStandard',
        ]);
    }

    /*
     * Gets the private '.service_locator.heBOatc' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_HeBOatcService()
    {
        return $this->privates['.service_locator.heBOatc'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'customerRepository' => ['privates', 'App\\Repository\\CustomerRepository', 'getCustomerRepositoryService', false],
        ], [
            'customerRepository' => 'App\\Repository\\CustomerRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.hl5g9CG' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Hl5g9CGService()
    {
        return $this->privates['.service_locator.hl5g9CG'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'setter' => ['privates', '.errored..service_locator.hl5g9CG.App\\Entity\\Setters', NULL, 'Cannot autowire service ".service_locator.hl5g9CG": it references class "App\\Entity\\Setters" but no such service exists.'],
        ], [
            'setter' => 'App\\Entity\\Setters',
        ]);
    }

    /*
     * Gets the private '.service_locator.iP8eVIx' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_IP8eVIxService()
    {
        return $this->privates['.service_locator.iP8eVIx'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'mailer' => ['privates', 'mailer.mailer', 'getMailer_MailerService', false],
        ], [
            'mailer' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.j7YlT0U' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_J7YlT0UService()
    {
        return $this->privates['.service_locator.j7YlT0U'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggSupplierRepository' => ['privates', 'App\\Repository\\SupplierRepository', 'getSupplierRepositoryService', false],
        ], [
            'eggSupplierRepository' => 'App\\Repository\\SupplierRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.jxVy_9b' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_JxVy9bService()
    {
        return $this->privates['.service_locator.jxVy_9b'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'breedRepository' => ['privates', 'App\\Repository\\BreedRepository', 'getBreedRepositoryService', false],
        ], [
            'breedRepository' => 'App\\Repository\\BreedRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.kFWiiLA' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_KFWiiLAService()
    {
        return $this->privates['.service_locator.kFWiiLA'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'sellingEgg' => ['privates', '.errored..service_locator.kFWiiLA.App\\Entity\\SellingEgg', NULL, 'Cannot autowire service ".service_locator.kFWiiLA": it references class "App\\Entity\\SellingEgg" but no such service exists.'],
        ], [
            'sellingEgg' => 'App\\Entity\\SellingEgg',
        ]);
    }

    /*
     * Gets the private '.service_locator.kgeYX4r' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_KgeYX4rService()
    {
        return $this->privates['.service_locator.kgeYX4r'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inputs' => ['privates', '.errored..service_locator.kgeYX4r.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.kgeYX4r": it references class "App\\Entity\\Inputs" but no such service exists.'],
            'supplier' => ['privates', '.errored..service_locator.kgeYX4r.App\\Entity\\Supplier', NULL, 'Cannot autowire service ".service_locator.kgeYX4r": it references class "App\\Entity\\Supplier" but no such service exists.'],
        ], [
            'inputs' => 'App\\Entity\\Inputs',
            'supplier' => 'App\\Entity\\Supplier',
        ]);
    }

    /*
     * Gets the private '.service_locator.l1XZ2mI' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_L1XZ2mIService()
    {
        return $this->privates['.service_locator.l1XZ2mI'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInputsTransfer' => ['privates', '.errored..service_locator.l1XZ2mI.App\\Entity\\Transfers', NULL, 'Cannot autowire service ".service_locator.l1XZ2mI": it references class "App\\Entity\\Transfers" but no such service exists.'],
        ], [
            'eggsInputsTransfer' => 'App\\Entity\\Transfers',
        ]);
    }

    /*
     * Gets the private '.service_locator.lX1ZHLN' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_LX1ZHLNService()
    {
        return $this->privates['.service_locator.lX1ZHLN'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'driverRepository' => ['privates', 'App\\Repository\\DriverRepository', 'getDriverRepositoryService', false],
        ], [
            'driverRepository' => 'App\\Repository\\DriverRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.mQpOpia' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_MQpOpiaService()
    {
        return $this->privates['.service_locator.mQpOpia'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'vaccination' => ['privates', '.errored..service_locator.mQpOpia.App\\Entity\\Vaccination', NULL, 'Cannot autowire service ".service_locator.mQpOpia": it references class "App\\Entity\\Vaccination" but no such service exists.'],
        ], [
            'vaccination' => 'App\\Entity\\Vaccination',
        ]);
    }

    /*
     * Gets the private '.service_locator.obuVz3B' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_ObuVz3BService()
    {
        return $this->privates['.service_locator.obuVz3B'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inputsRepository' => ['privates', 'App\\Repository\\InputsRepository', 'getInputsRepositoryService', false],
        ], [
            'inputsRepository' => 'App\\Repository\\InputsRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.sOiJzIJ' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_SOiJzIJService()
    {
        return $this->privates['.service_locator.sOiJzIJ'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chicksRecipientRepository' => ['privates', 'App\\Repository\\ChicksRecipientRepository', 'getChicksRecipientRepositoryService', false],
        ], [
            'chicksRecipientRepository' => 'App\\Repository\\ChicksRecipientRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.s_RWU_Q' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_SRWUQService()
    {
        return $this->privates['.service_locator.s_RWU_Q'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'input' => ['privates', '.errored..service_locator.s_RWU_Q.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.s_RWU_Q": it references class "App\\Entity\\Inputs" but no such service exists.'],
        ], [
            'input' => 'App\\Entity\\Inputs',
        ]);
    }

    /*
     * Gets the private '.service_locator.skRqFqk' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_SkRqFqkService()
    {
        return $this->privates['.service_locator.skRqFqk'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInputsLightingRepository' => ['privates', 'App\\Repository\\LightingRepository', 'getLightingRepositoryService', false],
        ], [
            'eggsInputsLightingRepository' => 'App\\Repository\\LightingRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.tIQ5Q0N' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_TIQ5Q0NService()
    {
        return $this->privates['.service_locator.tIQ5Q0N'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'user' => ['privates', '.errored..service_locator.tIQ5Q0N.App\\Entity\\User', NULL, 'Cannot autowire service ".service_locator.tIQ5Q0N": it references class "App\\Entity\\User" but no such service exists.'],
        ], [
            'user' => 'App\\Entity\\User',
        ]);
    }

    /*
     * Gets the private '.service_locator.ufDOk6W' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_UfDOk6WService()
    {
        return $this->privates['.service_locator.ufDOk6W'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'breed' => ['privates', '.errored..service_locator.ufDOk6W.App\\Entity\\Breed', NULL, 'Cannot autowire service ".service_locator.ufDOk6W": it references class "App\\Entity\\Breed" but no such service exists.'],
        ], [
            'breed' => 'App\\Entity\\Breed',
        ]);
    }

    /*
     * Gets the private '.service_locator.uuLauoa' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_UuLauoaService()
    {
        return $this->privates['.service_locator.uuLauoa'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chickTemperatureRepository' => ['privates', 'App\\Repository\\ChickTemperatureRepository', 'getChickTemperatureRepositoryService', false],
        ], [
            'chickTemperatureRepository' => 'App\\Repository\\ChickTemperatureRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.uzilRCW' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_UzilRCWService()
    {
        return $this->privates['.service_locator.uzilRCW'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'car' => ['privates', '.errored..service_locator.uzilRCW.App\\Entity\\Car', NULL, 'Cannot autowire service ".service_locator.uzilRCW": it references class "App\\Entity\\Car" but no such service exists.'],
        ], [
            'car' => 'App\\Entity\\Car',
        ]);
    }

    /*
     * Gets the private '.service_locator.v0RJ6N8' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_V0RJ6N8Service()
    {
        return $this->privates['.service_locator.v0RJ6N8'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInput' => ['privates', '.errored..service_locator.v0RJ6N8.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.v0RJ6N8": it references class "App\\Entity\\Inputs" but no such service exists.'],
            'farmRepository' => ['privates', 'App\\Repository\\InputsFarmRepository', 'getInputsFarmRepositoryService', false],
        ], [
            'eggsInput' => 'App\\Entity\\Inputs',
            'farmRepository' => 'App\\Repository\\InputsFarmRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.vc.JCrN' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Vc_JCrNService()
    {
        return $this->privates['.service_locator.vc.JCrN'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'chickIntegrationRepository' => ['privates', 'App\\Repository\\ChickIntegrationRepository', 'getChickIntegrationRepositoryService', false],
        ], [
            'chickIntegrationRepository' => 'App\\Repository\\ChickIntegrationRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.vdmMuyE' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_VdmMuyEService()
    {
        return $this->privates['.service_locator.vdmMuyE'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'doctrine' => ['services', 'doctrine', 'getDoctrineService', false],
            'form.factory' => ['services', 'form.factory', 'getForm_FactoryService', false],
            'http_kernel' => ['services', 'http_kernel', 'getHttpKernelService', false],
            'parameter_bag' => ['privates', 'parameter_bag', 'getParameterBagService', false],
            'request_stack' => ['services', 'request_stack', 'getRequestStackService', false],
            'router' => ['services', 'router', 'getRouterService', false],
            'security.authorization_checker' => ['services', 'security.authorization_checker', 'getSecurity_AuthorizationCheckerService', false],
            'security.csrf.token_manager' => ['services', 'security.csrf.token_manager', 'getSecurity_Csrf_TokenManagerService', false],
            'security.token_storage' => ['services', 'security.token_storage', 'getSecurity_TokenStorageService', false],
            'serializer' => ['services', 'serializer', 'getSerializerService', false],
            'session' => ['services', 'session', 'getSessionService', false],
            'twig' => ['services', 'twig', 'getTwigService', false],
        ], [
            'doctrine' => '?',
            'form.factory' => '?',
            'http_kernel' => '?',
            'parameter_bag' => '?',
            'request_stack' => '?',
            'router' => '?',
            'security.authorization_checker' => '?',
            'security.csrf.token_manager' => '?',
            'security.token_storage' => '?',
            'serializer' => '?',
            'session' => '?',
            'twig' => '?',
        ]);
    }

    /*
     * Gets the private '.service_locator.xh.Ejip' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Xh_EjipService()
    {
        return $this->privates['.service_locator.xh.Ejip'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'herd' => ['privates', '.errored..service_locator.xh.Ejip.App\\Entity\\Herds', NULL, 'Cannot autowire service ".service_locator.xh.Ejip": it references class "App\\Entity\\Herds" but no such service exists.'],
            'input' => ['privates', '.errored..service_locator.xh.Ejip.App\\Entity\\Inputs', NULL, 'Cannot autowire service ".service_locator.xh.Ejip": it references class "App\\Entity\\Inputs" but no such service exists.'],
        ], [
            'herd' => 'App\\Entity\\Herds',
            'input' => 'App\\Entity\\Inputs',
        ]);
    }

    /*
     * Gets the private '.service_locator.yZPm2Ey' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_YZPm2EyService()
    {
        return $this->privates['.service_locator.yZPm2Ey'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'contactInfo' => ['privates', '.errored..service_locator.yZPm2Ey.App\\Entity\\ContactInfo', NULL, 'Cannot autowire service ".service_locator.yZPm2Ey": it references class "App\\Entity\\ContactInfo" but no such service exists.'],
        ], [
            'contactInfo' => 'App\\Entity\\ContactInfo',
        ]);
    }

    /*
     * Gets the private '.service_locator.yyxnYO4' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_YyxnYO4Service()
    {
        return $this->privates['.service_locator.yyxnYO4'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'eggsInputsRepository' => ['privates', 'App\\Repository\\InputsRepository', 'getInputsRepositoryService', false],
            'herdsRepository' => ['privates', 'App\\Repository\\HerdsRepository', 'getHerdsRepositoryService', false],
            'inputDeliveryRepository' => ['privates', 'App\\Repository\\InputDeliveryRepository', 'getInputDeliveryRepositoryService', false],
        ], [
            'eggsInputsRepository' => 'App\\Repository\\InputsRepository',
            'herdsRepository' => 'App\\Repository\\HerdsRepository',
            'inputDeliveryRepository' => 'App\\Repository\\InputDeliveryRepository',
        ]);
    }

    /*
     * Gets the private '.service_locator.z1yUq3Y' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ServiceLocator
     */
    protected function get_ServiceLocator_Z1yUq3YService()
    {
        return $this->privates['.service_locator.z1yUq3Y'] = new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'planDeliveryChick' => ['privates', '.errored..service_locator.z1yUq3Y.App\\Entity\\PlanDeliveryChick', NULL, 'Cannot autowire service ".service_locator.z1yUq3Y": it references class "App\\Entity\\PlanDeliveryChick" but no such service exists.'],
        ], [
            'planDeliveryChick' => 'App\\Entity\\PlanDeliveryChick',
        ]);
    }

    /*
     * Gets the private 'App\Form\BetweenDateType' shared autowired service.
     *
     * @return \App\Form\BetweenDateType
     */
    protected function getBetweenDateTypeService()
    {
        return $this->privates['App\\Form\\BetweenDateType'] = new \App\Form\BetweenDateType();
    }

    /*
     * Gets the private 'App\Form\BreedStandardType' shared autowired service.
     *
     * @return \App\Form\BreedStandardType
     */
    protected function getBreedStandardTypeService()
    {
        return $this->privates['App\\Form\\BreedStandardType'] = new \App\Form\BreedStandardType();
    }

    /*
     * Gets the private 'App\Form\BreedType' shared autowired service.
     *
     * @return \App\Form\BreedType
     */
    protected function getBreedTypeService()
    {
        return $this->privates['App\\Form\\BreedType'] = new \App\Form\BreedType();
    }

    /*
     * Gets the private 'App\Form\CarType' shared autowired service.
     *
     * @return \App\Form\CarType
     */
    protected function getCarTypeService()
    {
        return $this->privates['App\\Form\\CarType'] = new \App\Form\CarType();
    }

    /*
     * Gets the private 'App\Form\ChangePasswordFormType' shared autowired service.
     *
     * @return \App\Form\ChangePasswordFormType
     */
    protected function getChangePasswordFormTypeService()
    {
        return $this->privates['App\\Form\\ChangePasswordFormType'] = new \App\Form\ChangePasswordFormType();
    }

    /*
     * Gets the private 'App\Form\ChickIntegrationType' shared autowired service.
     *
     * @return \App\Form\ChickIntegrationType
     */
    protected function getChickIntegrationTypeService()
    {
        return $this->privates['App\\Form\\ChickIntegrationType'] = new \App\Form\ChickIntegrationType();
    }

    /*
     * Gets the private 'App\Form\ChickTemperatureType' shared autowired service.
     *
     * @return \App\Form\ChickTemperatureType
     */
    protected function getChickTemperatureTypeService()
    {
        return $this->privates['App\\Form\\ChickTemperatureType'] = new \App\Form\ChickTemperatureType();
    }

    /*
     * Gets the private 'App\Form\ChicksRecipientType' shared autowired service.
     *
     * @return \App\Form\ChicksRecipientType
     */
    protected function getChicksRecipientTypeService()
    {
        return $this->privates['App\\Form\\ChicksRecipientType'] = new \App\Form\ChicksRecipientType();
    }

    /*
     * Gets the private 'App\Form\ContactInfoType' shared autowired service.
     *
     * @return \App\Form\ContactInfoType
     */
    protected function getContactInfoTypeService()
    {
        return $this->privates['App\\Form\\ContactInfoType'] = new \App\Form\ContactInfoType();
    }

    /*
     * Gets the private 'App\Form\CustomerType' shared autowired service.
     *
     * @return \App\Form\CustomerType
     */
    protected function getCustomerTypeService()
    {
        return $this->privates['App\\Form\\CustomerType'] = new \App\Form\CustomerType();
    }

    /*
     * Gets the private 'App\Form\DeliveryPartIndexType' shared autowired service.
     *
     * @return \App\Form\DeliveryPartIndexType
     */
    protected function getDeliveryPartIndexTypeService()
    {
        return $this->privates['App\\Form\\DeliveryPartIndexType'] = new \App\Form\DeliveryPartIndexType();
    }

    /*
     * Gets the private 'App\Form\DeliveryProductionType' shared autowired service.
     *
     * @return \App\Form\DeliveryProductionType
     */
    protected function getDeliveryProductionTypeService()
    {
        return $this->privates['App\\Form\\DeliveryProductionType'] = new \App\Form\DeliveryProductionType();
    }

    /*
     * Gets the private 'App\Form\DeliveryType' shared autowired service.
     *
     * @return \App\Form\DeliveryType
     */
    protected function getDeliveryTypeService()
    {
        return $this->privates['App\\Form\\DeliveryType'] = new \App\Form\DeliveryType();
    }

    /*
     * Gets the private 'App\Form\DriverType' shared autowired service.
     *
     * @return \App\Form\DriverType
     */
    protected function getDriverTypeService()
    {
        return $this->privates['App\\Form\\DriverType'] = new \App\Form\DriverType();
    }

    /*
     * Gets the private 'App\Form\HatchersType' shared autowired service.
     *
     * @return \App\Form\HatchersType
     */
    protected function getHatchersTypeService()
    {
        return $this->privates['App\\Form\\HatchersType'] = new \App\Form\HatchersType();
    }

    /*
     * Gets the private 'App\Form\HerdActiveType' shared autowired service.
     *
     * @return \App\Form\HerdActiveType
     */
    protected function getHerdActiveTypeService()
    {
        return $this->privates['App\\Form\\HerdActiveType'] = new \App\Form\HerdActiveType();
    }

    /*
     * Gets the private 'App\Form\HerdsType' shared autowired service.
     *
     * @return \App\Form\HerdsType
     */
    protected function getHerdsTypeService()
    {
        return $this->privates['App\\Form\\HerdsType'] = new \App\Form\HerdsType();
    }

    /*
     * Gets the private 'App\Form\InputDeliveryProductionType' shared autowired service.
     *
     * @return \App\Form\InputDeliveryProductionType
     */
    protected function getInputDeliveryProductionTypeService()
    {
        return $this->privates['App\\Form\\InputDeliveryProductionType'] = new \App\Form\InputDeliveryProductionType();
    }

    /*
     * Gets the private 'App\Form\InputDeliveryType' shared autowired service.
     *
     * @return \App\Form\InputDeliveryType
     */
    protected function getInputDeliveryTypeService()
    {
        return $this->privates['App\\Form\\InputDeliveryType'] = new \App\Form\InputDeliveryType();
    }

    /*
     * Gets the private 'App\Form\InputsDetailsType' shared autowired service.
     *
     * @return \App\Form\InputsDetailsType
     */
    protected function getInputsDetailsTypeService()
    {
        return $this->privates['App\\Form\\InputsDetailsType'] = new \App\Form\InputsDetailsType();
    }

    /*
     * Gets the private 'App\Form\InputsFarmType' shared autowired service.
     *
     * @return \App\Form\InputsFarmType
     */
    protected function getInputsFarmTypeService()
    {
        return $this->privates['App\\Form\\InputsFarmType'] = new \App\Form\InputsFarmType();
    }

    /*
     * Gets the private 'App\Form\InputsType' shared autowired service.
     *
     * @return \App\Form\InputsType
     */
    protected function getInputsTypeService()
    {
        return $this->privates['App\\Form\\InputsType'] = new \App\Form\InputsType();
    }

    /*
     * Gets the private 'App\Form\LightingCorrectType' shared autowired service.
     *
     * @return \App\Form\LightingCorrectType
     */
    protected function getLightingCorrectTypeService()
    {
        return $this->privates['App\\Form\\LightingCorrectType'] = new \App\Form\LightingCorrectType();
    }

    /*
     * Gets the private 'App\Form\LightingType' shared autowired service.
     *
     * @return \App\Form\LightingType
     */
    protected function getLightingTypeService()
    {
        return $this->privates['App\\Form\\LightingType'] = new \App\Form\LightingType();
    }

    /*
     * Gets the private 'App\Form\PlanDeliveryChickType' shared autowired service.
     *
     * @return \App\Form\PlanDeliveryChickType
     */
    protected function getPlanDeliveryChickTypeService()
    {
        return $this->privates['App\\Form\\PlanDeliveryChickType'] = new \App\Form\PlanDeliveryChickType();
    }

    /*
     * Gets the private 'App\Form\PlanDeliveryEggForHerdType' shared autowired service.
     *
     * @return \App\Form\PlanDeliveryEggForHerdType
     */
    protected function getPlanDeliveryEggForHerdTypeService()
    {
        return $this->privates['App\\Form\\PlanDeliveryEggForHerdType'] = new \App\Form\PlanDeliveryEggForHerdType();
    }

    /*
     * Gets the private 'App\Form\PlanDeliveryEggType' shared autowired service.
     *
     * @return \App\Form\PlanDeliveryEggType
     */
    protected function getPlanDeliveryEggTypeService()
    {
        return $this->privates['App\\Form\\PlanDeliveryEggType'] = new \App\Form\PlanDeliveryEggType();
    }

    /*
     * Gets the private 'App\Form\PlanIndicatorsType' shared autowired service.
     *
     * @return \App\Form\PlanIndicatorsType
     */
    protected function getPlanIndicatorsTypeService()
    {
        return $this->privates['App\\Form\\PlanIndicatorsType'] = new \App\Form\PlanIndicatorsType();
    }

    /*
     * Gets the private 'App\Form\PlanInputType' shared autowired service.
     *
     * @return \App\Form\PlanInputType
     */
    protected function getPlanInputTypeService()
    {
        return $this->privates['App\\Form\\PlanInputType'] = new \App\Form\PlanInputType();
    }

    /*
     * Gets the private 'App\Form\Production\TransfersProductionType' shared autowired service.
     *
     * @return \App\Form\Production\TransfersProductionType
     */
    protected function getTransfersProductionTypeService()
    {
        return $this->privates['App\\Form\\Production\\TransfersProductionType'] = new \App\Form\Production\TransfersProductionType();
    }

    /*
     * Gets the private 'App\Form\ResetPasswordRequestFormType' shared autowired service.
     *
     * @return \App\Form\ResetPasswordRequestFormType
     */
    protected function getResetPasswordRequestFormTypeService()
    {
        return $this->privates['App\\Form\\ResetPasswordRequestFormType'] = new \App\Form\ResetPasswordRequestFormType();
    }

    /*
     * Gets the private 'App\Form\SelectionsType' shared autowired service.
     *
     * @return \App\Form\SelectionsType
     */
    protected function getSelectionsTypeService()
    {
        return $this->privates['App\\Form\\SelectionsType'] = new \App\Form\SelectionsType();
    }

    /*
     * Gets the private 'App\Form\SellingEggType' shared autowired service.
     *
     * @return \App\Form\SellingEggType
     */
    protected function getSellingEggTypeService()
    {
        return $this->privates['App\\Form\\SellingEggType'] = new \App\Form\SellingEggType();
    }

    /*
     * Gets the private 'App\Form\SettersType' shared autowired service.
     *
     * @return \App\Form\SettersType
     */
    protected function getSettersTypeService()
    {
        return $this->privates['App\\Form\\SettersType'] = new \App\Form\SettersType();
    }

    /*
     * Gets the private 'App\Form\SupplierType' shared autowired service.
     *
     * @return \App\Form\SupplierType
     */
    protected function getSupplierTypeService()
    {
        return $this->privates['App\\Form\\SupplierType'] = new \App\Form\SupplierType();
    }

    /*
     * Gets the private 'App\Form\TransfersType' shared autowired service.
     *
     * @return \App\Form\TransfersType
     */
    protected function getTransfersTypeService()
    {
        return $this->privates['App\\Form\\TransfersType'] = new \App\Form\TransfersType();
    }

    /*
     * Gets the private 'App\Form\TransportListType' shared autowired service.
     *
     * @return \App\Form\TransportListType
     */
    protected function getTransportListTypeService()
    {
        return $this->privates['App\\Form\\TransportListType'] = new \App\Form\TransportListType();
    }

    /*
     * Gets the private 'App\Form\User1Type' shared autowired service.
     *
     * @return \App\Form\User1Type
     */
    protected function getUser1TypeService()
    {
        return $this->privates['App\\Form\\User1Type'] = new \App\Form\User1Type();
    }

    /*
     * Gets the private 'App\Form\UserType' shared autowired service.
     *
     * @return \App\Form\UserType
     */
    protected function getUserTypeService()
    {
        return $this->privates['App\\Form\\UserType'] = new \App\Form\UserType();
    }

    /*
     * Gets the private 'App\Form\VaccinationType' shared autowired service.
     *
     * @return \App\Form\VaccinationType
     */
    protected function getVaccinationTypeService()
    {
        return $this->privates['App\\Form\\VaccinationType'] = new \App\Form\VaccinationType();
    }

    /*
     * Gets the private 'App\Repository\BreedRepository' shared autowired service.
     *
     * @return \App\Repository\BreedRepository
     */
    protected function getBreedRepositoryService()
    {
        return $this->privates['App\\Repository\\BreedRepository'] = new \App\Repository\BreedRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\BreedStandardRepository' shared autowired service.
     *
     * @return \App\Repository\BreedStandardRepository
     */
    protected function getBreedStandardRepositoryService()
    {
        return $this->privates['App\\Repository\\BreedStandardRepository'] = new \App\Repository\BreedStandardRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\CarRepository' shared autowired service.
     *
     * @return \App\Repository\CarRepository
     */
    protected function getCarRepositoryService()
    {
        return $this->privates['App\\Repository\\CarRepository'] = new \App\Repository\CarRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\ChickIntegrationRepository' shared autowired service.
     *
     * @return \App\Repository\ChickIntegrationRepository
     */
    protected function getChickIntegrationRepositoryService()
    {
        return $this->privates['App\\Repository\\ChickIntegrationRepository'] = new \App\Repository\ChickIntegrationRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\ChickTemperatureRepository' shared autowired service.
     *
     * @return \App\Repository\ChickTemperatureRepository
     */
    protected function getChickTemperatureRepositoryService()
    {
        return $this->privates['App\\Repository\\ChickTemperatureRepository'] = new \App\Repository\ChickTemperatureRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\ChicksRecipientRepository' shared autowired service.
     *
     * @return \App\Repository\ChicksRecipientRepository
     */
    protected function getChicksRecipientRepositoryService()
    {
        return $this->privates['App\\Repository\\ChicksRecipientRepository'] = new \App\Repository\ChicksRecipientRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\ConstantRepository' shared autowired service.
     *
     * @return \App\Repository\ConstantRepository
     */
    protected function getConstantRepositoryService()
    {
        return $this->privates['App\\Repository\\ConstantRepository'] = new \App\Repository\ConstantRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\ContactInfoRepository' shared autowired service.
     *
     * @return \App\Repository\ContactInfoRepository
     */
    protected function getContactInfoRepositoryService()
    {
        return $this->privates['App\\Repository\\ContactInfoRepository'] = new \App\Repository\ContactInfoRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\CustomerBuildingRepository' shared autowired service.
     *
     * @return \App\Repository\CustomerBuildingRepository
     */
    protected function getCustomerBuildingRepositoryService()
    {
        return $this->privates['App\\Repository\\CustomerBuildingRepository'] = new \App\Repository\CustomerBuildingRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\CustomerRepository' shared autowired service.
     *
     * @return \App\Repository\CustomerRepository
     */
    protected function getCustomerRepositoryService()
    {
        return $this->privates['App\\Repository\\CustomerRepository'] = new \App\Repository\CustomerRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\DeliveryRepository' shared autowired service.
     *
     * @return \App\Repository\DeliveryRepository
     */
    protected function getDeliveryRepositoryService()
    {
        return $this->privates['App\\Repository\\DeliveryRepository'] = new \App\Repository\DeliveryRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\DriverRepository' shared autowired service.
     *
     * @return \App\Repository\DriverRepository
     */
    protected function getDriverRepositoryService()
    {
        return $this->privates['App\\Repository\\DriverRepository'] = new \App\Repository\DriverRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\HatchersRepository' shared autowired service.
     *
     * @return \App\Repository\HatchersRepository
     */
    protected function getHatchersRepositoryService()
    {
        return $this->privates['App\\Repository\\HatchersRepository'] = new \App\Repository\HatchersRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\HerdsRepository' shared autowired service.
     *
     * @return \App\Repository\HerdsRepository
     */
    protected function getHerdsRepositoryService()
    {
        return $this->privates['App\\Repository\\HerdsRepository'] = new \App\Repository\HerdsRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\InputDeliveryRepository' shared autowired service.
     *
     * @return \App\Repository\InputDeliveryRepository
     */
    protected function getInputDeliveryRepositoryService()
    {
        return $this->privates['App\\Repository\\InputDeliveryRepository'] = new \App\Repository\InputDeliveryRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\InputsFarmDeliveryPlanRepository' shared autowired service.
     *
     * @return \App\Repository\InputsFarmDeliveryPlanRepository
     */
    protected function getInputsFarmDeliveryPlanRepositoryService()
    {
        return $this->privates['App\\Repository\\InputsFarmDeliveryPlanRepository'] = new \App\Repository\InputsFarmDeliveryPlanRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\InputsFarmRepository' shared autowired service.
     *
     * @return \App\Repository\InputsFarmRepository
     */
    protected function getInputsFarmRepositoryService()
    {
        return $this->privates['App\\Repository\\InputsFarmRepository'] = new \App\Repository\InputsFarmRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\InputsRepository' shared autowired service.
     *
     * @return \App\Repository\InputsRepository
     */
    protected function getInputsRepositoryService()
    {
        return $this->privates['App\\Repository\\InputsRepository'] = new \App\Repository\InputsRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\LightingRepository' shared autowired service.
     *
     * @return \App\Repository\LightingRepository
     */
    protected function getLightingRepositoryService()
    {
        return $this->privates['App\\Repository\\LightingRepository'] = new \App\Repository\LightingRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\PlanDeliveryChickRepository' shared autowired service.
     *
     * @return \App\Repository\PlanDeliveryChickRepository
     */
    protected function getPlanDeliveryChickRepositoryService()
    {
        return $this->privates['App\\Repository\\PlanDeliveryChickRepository'] = new \App\Repository\PlanDeliveryChickRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\PlanDeliveryEggRepository' shared autowired service.
     *
     * @return \App\Repository\PlanDeliveryEggRepository
     */
    protected function getPlanDeliveryEggRepositoryService()
    {
        return $this->privates['App\\Repository\\PlanDeliveryEggRepository'] = new \App\Repository\PlanDeliveryEggRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\PlanIndicatorsRepository' shared autowired service.
     *
     * @return \App\Repository\PlanIndicatorsRepository
     */
    protected function getPlanIndicatorsRepositoryService()
    {
        return $this->privates['App\\Repository\\PlanIndicatorsRepository'] = new \App\Repository\PlanIndicatorsRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\PlanInputRepository' shared autowired service.
     *
     * @return \App\Repository\PlanInputRepository
     */
    protected function getPlanInputRepositoryService()
    {
        return $this->privates['App\\Repository\\PlanInputRepository'] = new \App\Repository\PlanInputRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\ResetPasswordRequestRepository' shared autowired service.
     *
     * @return \App\Repository\ResetPasswordRequestRepository
     */
    protected function getResetPasswordRequestRepositoryService()
    {
        return $this->privates['App\\Repository\\ResetPasswordRequestRepository'] = new \App\Repository\ResetPasswordRequestRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\SelectionsRepository' shared autowired service.
     *
     * @return \App\Repository\SelectionsRepository
     */
    protected function getSelectionsRepositoryService()
    {
        return $this->privates['App\\Repository\\SelectionsRepository'] = new \App\Repository\SelectionsRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\SellingEggRepository' shared autowired service.
     *
     * @return \App\Repository\SellingEggRepository
     */
    protected function getSellingEggRepositoryService()
    {
        return $this->privates['App\\Repository\\SellingEggRepository'] = new \App\Repository\SellingEggRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\SettersRepository' shared autowired service.
     *
     * @return \App\Repository\SettersRepository
     */
    protected function getSettersRepositoryService()
    {
        return $this->privates['App\\Repository\\SettersRepository'] = new \App\Repository\SettersRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\SupplierRepository' shared autowired service.
     *
     * @return \App\Repository\SupplierRepository
     */
    protected function getSupplierRepositoryService()
    {
        return $this->privates['App\\Repository\\SupplierRepository'] = new \App\Repository\SupplierRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\TransfersRepository' shared autowired service.
     *
     * @return \App\Repository\TransfersRepository
     */
    protected function getTransfersRepositoryService()
    {
        return $this->privates['App\\Repository\\TransfersRepository'] = new \App\Repository\TransfersRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\TransportListRepository' shared autowired service.
     *
     * @return \App\Repository\TransportListRepository
     */
    protected function getTransportListRepositoryService()
    {
        return $this->privates['App\\Repository\\TransportListRepository'] = new \App\Repository\TransportListRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\UserRepository' shared autowired service.
     *
     * @return \App\Repository\UserRepository
     */
    protected function getUserRepositoryService()
    {
        return $this->privates['App\\Repository\\UserRepository'] = new \App\Repository\UserRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Repository\VaccinationRepository' shared autowired service.
     *
     * @return \App\Repository\VaccinationRepository
     */
    protected function getVaccinationRepositoryService()
    {
        return $this->privates['App\\Repository\\VaccinationRepository'] = new \App\Repository\VaccinationRepository(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'App\Security\LoginFormAuthenticator' shared autowired service.
     *
     * @return \App\Security\LoginFormAuthenticator
     */
    protected function getLoginFormAuthenticatorService()
    {
        return $this->privates['App\\Security\\LoginFormAuthenticator'] = new \App\Security\LoginFormAuthenticator(($this->services['doctrine.orm.default_entity_manager'] ?? $this->getDoctrine_Orm_DefaultEntityManagerService()), ($this->services['router'] ?? $this->getRouterService()), ($this->services['security.csrf.token_manager'] ?? $this->getSecurity_Csrf_TokenManagerService()), ($this->services['security.password_encoder'] ?? $this->getSecurity_PasswordEncoderService()), ($this->privates['security.helper'] ?? $this->getSecurity_HelperService()));
    }

    /*
     * Gets the private 'DH\AuditorBundle\Event\ViewerEventSubscriber' shared service.
     *
     * @return \DH\AuditorBundle\Event\ViewerEventSubscriber
     */
    protected function getViewerEventSubscriberService()
    {
        return $this->privates['DH\\AuditorBundle\\Event\\ViewerEventSubscriber'] = new \DH\AuditorBundle\Event\ViewerEventSubscriber(($this->privates['DH\\Auditor\\Auditor'] ?? $this->getAuditorService()));
    }

    /*
     * Gets the private 'DH\Auditor\Auditor' shared service.
     *
     * @return \DH\Auditor\Auditor
     */
    protected function getAuditorService()
    {
        $a = new \DH\Auditor\Configuration($this->parameters['dh_auditor.configuration']);

        $b = ($this->privates['security.helper'] ?? $this->getSecurity_HelperService());
        $this->privates['DH\\Auditor\\Auditor'] = $instance = new \DH\Auditor\Auditor($a, ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));

        $c = ($this->privates['DH\\Auditor\\Provider\\Doctrine\\DoctrineProvider'] ?? $this->getDoctrineProviderService());

        $instance->registerProvider($c);

        $a->setUserProvider(new \DH\AuditorBundle\User\UserProvider($b, ($this->privates['DH\\Auditor\\Provider\\Doctrine\\Configuration'] ?? $this->getConfigurationService())));
        $a->setRoleChecker(new \DH\AuditorBundle\Security\RoleChecker($b, $c));
        $a->setSecurityProvider(new \DH\AuditorBundle\Security\SecurityProvider(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->privates['security.firewall.map'] ?? $this->getSecurity_Firewall_MapService())));

        return $instance;
    }

    /*
     * Gets the private 'DH\Auditor\Provider\Doctrine\Configuration' shared service.
     *
     * @return \DH\Auditor\Provider\Doctrine\Configuration
     */
    protected function getConfigurationService()
    {
        return $this->privates['DH\\Auditor\\Provider\\Doctrine\\Configuration'] = new \DH\Auditor\Provider\Doctrine\Configuration($this->parameters['dh_auditor.provider.doctrine.configuration']);
    }

    /*
     * Gets the private 'DH\Auditor\Provider\Doctrine\DoctrineProvider' shared service.
     *
     * @return \DH\Auditor\Provider\Doctrine\DoctrineProvider
     */
    protected function getDoctrineProviderService()
    {
        $this->privates['DH\\Auditor\\Provider\\Doctrine\\DoctrineProvider'] = $instance = new \DH\Auditor\Provider\Doctrine\DoctrineProvider(($this->privates['DH\\Auditor\\Provider\\Doctrine\\Configuration'] ?? $this->getConfigurationService()));

        $a = ($this->services['doctrine.orm.default_entity_manager'] ?? $this->getDoctrine_Orm_DefaultEntityManagerService());

        $instance->setAuditor(($this->privates['DH\\Auditor\\Auditor'] ?? $this->getAuditorService()));
        $instance->registerStorageService(new \DH\Auditor\Provider\Doctrine\Service\StorageService('dh_auditor.provider.doctrine.storage_services.doctrine.orm.default_entity_manager', $a));
        $instance->registerAuditingService(new \DH\Auditor\Provider\Doctrine\Service\AuditingService('dh_auditor.provider.doctrine.auditing_services.doctrine.orm.default_entity_manager', $a));

        return $instance;
    }

    /*
     * Gets the private 'DH\Auditor\Provider\Doctrine\Persistence\Command\CleanAuditLogsCommand' shared service.
     *
     * @return \DH\Auditor\Provider\Doctrine\Persistence\Command\CleanAuditLogsCommand
     */
    protected function getCleanAuditLogsCommandService()
    {
        $this->privates['DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\CleanAuditLogsCommand'] = $instance = new \DH\Auditor\Provider\Doctrine\Persistence\Command\CleanAuditLogsCommand();

        $instance->setAuditor(($this->privates['DH\\Auditor\\Auditor'] ?? $this->getAuditorService()));
        $instance->setName('audit:clean');

        return $instance;
    }

    /*
     * Gets the private 'DH\Auditor\Provider\Doctrine\Persistence\Command\UpdateSchemaCommand' shared service.
     *
     * @return \DH\Auditor\Provider\Doctrine\Persistence\Command\UpdateSchemaCommand
     */
    protected function getUpdateSchemaCommandService()
    {
        $this->privates['DH\\Auditor\\Provider\\Doctrine\\Persistence\\Command\\UpdateSchemaCommand'] = $instance = new \DH\Auditor\Provider\Doctrine\Persistence\Command\UpdateSchemaCommand();

        $instance->setAuditor(($this->privates['DH\\Auditor\\Auditor'] ?? $this->getAuditorService()));
        $instance->setName('audit:schema:update');

        return $instance;
    }

    /*
     * Gets the private 'DH\Auditor\Provider\Doctrine\Persistence\Event\CreateSchemaListener' shared service.
     *
     * @return \DH\Auditor\Provider\Doctrine\Persistence\Event\CreateSchemaListener
     */
    protected function getCreateSchemaListenerService()
    {
        return $this->privates['DH\\Auditor\\Provider\\Doctrine\\Persistence\\Event\\CreateSchemaListener'] = new \DH\Auditor\Provider\Doctrine\Persistence\Event\CreateSchemaListener(($this->privates['DH\\Auditor\\Provider\\Doctrine\\DoctrineProvider'] ?? $this->getDoctrineProviderService()));
    }

    /*
     * Gets the private 'DH\Auditor\Provider\Doctrine\Persistence\Reader\Reader' shared service.
     *
     * @return \DH\Auditor\Provider\Doctrine\Persistence\Reader\Reader
     */
    protected function getReaderService()
    {
        return $this->privates['DH\\Auditor\\Provider\\Doctrine\\Persistence\\Reader\\Reader'] = new \DH\Auditor\Provider\Doctrine\Persistence\Reader\Reader(($this->privates['DH\\Auditor\\Provider\\Doctrine\\DoctrineProvider'] ?? $this->getDoctrineProviderService()));
    }

    /*
     * Gets the private 'Doctrine\Bundle\DoctrineBundle\Dbal\ManagerRegistryAwareConnectionProvider' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Dbal\ManagerRegistryAwareConnectionProvider
     */
    protected function getManagerRegistryAwareConnectionProviderService()
    {
        return $this->privates['Doctrine\\Bundle\\DoctrineBundle\\Dbal\\ManagerRegistryAwareConnectionProvider'] = new \Doctrine\Bundle\DoctrineBundle\Dbal\ManagerRegistryAwareConnectionProvider(new \Doctrine\Bundle\DoctrineBundle\Registry($this, $this->parameters['doctrine.connections'], $this->parameters['doctrine.entity_managers'], 'default', 'default'));
    }

    /*
     * Gets the private 'Doctrine\DBAL\Tools\Console\Command\RunSqlCommand' shared service.
     *
     * @return \Doctrine\DBAL\Tools\Console\Command\RunSqlCommand
     */
    protected function getRunSqlCommandService()
    {
        $this->privates['Doctrine\\DBAL\\Tools\\Console\\Command\\RunSqlCommand'] = $instance = new \Doctrine\DBAL\Tools\Console\Command\RunSqlCommand(($this->privates['Doctrine\\Bundle\\DoctrineBundle\\Dbal\\ManagerRegistryAwareConnectionProvider'] ?? $this->getManagerRegistryAwareConnectionProviderService()));

        $instance->setName('dbal:run-sql');

        return $instance;
    }

    /*
     * Gets the private 'SymfonyCasts\Bundle\ResetPassword\Command\ResetPasswordRemoveExpiredCommand' shared service.
     *
     * @return \SymfonyCasts\Bundle\ResetPassword\Command\ResetPasswordRemoveExpiredCommand
     */
    protected function getResetPasswordRemoveExpiredCommandService()
    {
        $this->privates['SymfonyCasts\\Bundle\\ResetPassword\\Command\\ResetPasswordRemoveExpiredCommand'] = $instance = new \SymfonyCasts\Bundle\ResetPassword\Command\ResetPasswordRemoveExpiredCommand(($this->privates['symfonycasts.reset_password.cleaner'] ?? $this->getSymfonycasts_ResetPassword_CleanerService()));

        $instance->setName('reset-password:remove-expired');

        return $instance;
    }

    /*
     * Gets the private 'annotations.cache' shared service.
     *
     * @return \Symfony\Component\Cache\DoctrineProvider
     */
    protected function getAnnotations_CacheService()
    {
        return new \Symfony\Component\Cache\DoctrineProvider(\Symfony\Component\Cache\Adapter\PhpArrayAdapter::create(($this->targetDir.''.'/annotations.php'), ($this->privates['cache.annotations'] ?? $this->getCache_AnnotationsService())));
    }

    /*
     * Gets the private 'annotations.cache_warmer' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\CacheWarmer\AnnotationsCacheWarmer
     */
    protected function getAnnotations_CacheWarmerService()
    {
        return $this->privates['annotations.cache_warmer'] = new \Symfony\Bundle\FrameworkBundle\CacheWarmer\AnnotationsCacheWarmer(($this->privates['annotations.reader'] ?? $this->getAnnotations_ReaderService()), ($this->targetDir.''.'/annotations.php'), '#^Symfony\\\\(?:Component\\\\HttpKernel\\\\|Bundle\\\\FrameworkBundle\\\\Controller\\\\(?!.*Controller$))#', false);
    }

    /*
     * Gets the private 'annotations.cached_reader' shared service.
     *
     * @return \Doctrine\Common\Annotations\CachedReader
     */
    protected function getAnnotations_CachedReaderService()
    {
        return $this->privates['annotations.cached_reader'] = new \Doctrine\Common\Annotations\CachedReader(($this->privates['annotations.reader'] ?? $this->getAnnotations_ReaderService()), $this->getAnnotations_CacheService(), false);
    }

    /*
     * Gets the private 'annotations.reader' shared service.
     *
     * @return \Doctrine\Common\Annotations\AnnotationReader
     */
    protected function getAnnotations_ReaderService()
    {
        $this->privates['annotations.reader'] = $instance = new \Doctrine\Common\Annotations\AnnotationReader();

        $a = new \Doctrine\Common\Annotations\AnnotationRegistry();
        $a->registerUniqueLoader('class_exists');

        $instance->addGlobalIgnoredName('required', $a);

        return $instance;
    }

    /*
     * Gets the private 'argument_resolver.service' shared service.
     *
     * @return \Symfony\Component\HttpKernel\Controller\ArgumentResolver\ServiceValueResolver
     */
    protected function getArgumentResolver_ServiceService()
    {
        return $this->privates['argument_resolver.service'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\ServiceValueResolver(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'App\\Controller\\BreedController::delete' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\BreedController::edit' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\BreedController::index' => ['privates', '.service_locator.jxVy_9b', 'get_ServiceLocator_JxVy9bService', false],
            'App\\Controller\\BreedController::show' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\BreedStandardController::delete' => ['privates', '.service_locator.hcga3N6', 'get_ServiceLocator_Hcga3N6Service', false],
            'App\\Controller\\BreedStandardController::edit' => ['privates', '.service_locator.hcga3N6', 'get_ServiceLocator_Hcga3N6Service', false],
            'App\\Controller\\BreedStandardController::index' => ['privates', '.service_locator.UubWFXd', 'get_ServiceLocator_UubWFXdService', false],
            'App\\Controller\\BreedStandardController::show' => ['privates', '.service_locator.hcga3N6', 'get_ServiceLocator_Hcga3N6Service', false],
            'App\\Controller\\CarController::delete' => ['privates', '.service_locator.uzilRCW', 'get_ServiceLocator_UzilRCWService', false],
            'App\\Controller\\CarController::edit' => ['privates', '.service_locator.uzilRCW', 'get_ServiceLocator_UzilRCWService', false],
            'App\\Controller\\CarController::index' => ['privates', '.service_locator.OaAVb7K', 'get_ServiceLocator_OaAVb7KService', false],
            'App\\Controller\\CarController::show' => ['privates', '.service_locator.uzilRCW', 'get_ServiceLocator_UzilRCWService', false],
            'App\\Controller\\ChickIntegrationController::delete' => ['privates', '.service_locator.aPT4Rqb', 'get_ServiceLocator_APT4RqbService', false],
            'App\\Controller\\ChickIntegrationController::edit' => ['privates', '.service_locator.aPT4Rqb', 'get_ServiceLocator_APT4RqbService', false],
            'App\\Controller\\ChickIntegrationController::index' => ['privates', '.service_locator.vc.JCrN', 'get_ServiceLocator_Vc_JCrNService', false],
            'App\\Controller\\ChickIntegrationController::show' => ['privates', '.service_locator.aPT4Rqb', 'get_ServiceLocator_APT4RqbService', false],
            'App\\Controller\\ChickTemperatureController::delete' => ['privates', '.service_locator.Dn9kS4t', 'get_ServiceLocator_Dn9kS4tService', false],
            'App\\Controller\\ChickTemperatureController::edit' => ['privates', '.service_locator.Dn9kS4t', 'get_ServiceLocator_Dn9kS4tService', false],
            'App\\Controller\\ChickTemperatureController::index' => ['privates', '.service_locator.uuLauoa', 'get_ServiceLocator_UuLauoaService', false],
            'App\\Controller\\ChickTemperatureController::show' => ['privates', '.service_locator.Dn9kS4t', 'get_ServiceLocator_Dn9kS4tService', false],
            'App\\Controller\\ChicksRecipientController::customerIndex' => ['privates', '.service_locator.DjlexR7', 'get_ServiceLocator_DjlexR7Service', false],
            'App\\Controller\\ChicksRecipientController::delete' => ['privates', '.service_locator.MtlBFkc', 'get_ServiceLocator_MtlBFkcService', false],
            'App\\Controller\\ChicksRecipientController::edit' => ['privates', '.service_locator.MtlBFkc', 'get_ServiceLocator_MtlBFkcService', false],
            'App\\Controller\\ChicksRecipientController::index' => ['privates', '.service_locator.sOiJzIJ', 'get_ServiceLocator_SOiJzIJService', false],
            'App\\Controller\\ChicksRecipientController::show' => ['privates', '.service_locator.G4rkM_4', 'get_ServiceLocator_G4rkM4Service', false],
            'App\\Controller\\ContactInfoController::delete' => ['privates', '.service_locator.yZPm2Ey', 'get_ServiceLocator_YZPm2EyService', false],
            'App\\Controller\\ContactInfoController::edit' => ['privates', '.service_locator.yZPm2Ey', 'get_ServiceLocator_YZPm2EyService', false],
            'App\\Controller\\ContactInfoController::index' => ['privates', '.service_locator.Ayv8Hbr', 'get_ServiceLocator_Ayv8HbrService', false],
            'App\\Controller\\ContactInfoController::show' => ['privates', '.service_locator.yZPm2Ey', 'get_ServiceLocator_YZPm2EyService', false],
            'App\\Controller\\CustomerController::delete' => ['privates', '.service_locator.7NSCnyQ', 'get_ServiceLocator_7NSCnyQService', false],
            'App\\Controller\\CustomerController::edit' => ['privates', '.service_locator.7NSCnyQ', 'get_ServiceLocator_7NSCnyQService', false],
            'App\\Controller\\CustomerController::index' => ['privates', '.service_locator.heBOatc', 'get_ServiceLocator_HeBOatcService', false],
            'App\\Controller\\CustomerController::show' => ['privates', '.service_locator.7NSCnyQ', 'get_ServiceLocator_7NSCnyQService', false],
            'App\\Controller\\DefaultController::incubators' => ['privates', '.service_locator._aCulUr', 'get_ServiceLocator_ACulUrService', false],
            'App\\Controller\\DefaultController::index' => ['privates', '.service_locator.WiUKNEm', 'get_ServiceLocator_WiUKNEmService', false],
            'App\\Controller\\DefaultController::indexPdf' => ['privates', '.service_locator.CWSFabL', 'get_ServiceLocator_CWSFabLService', false],
            'App\\Controller\\DeliveryController::addPartIndex' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DeliveryController::allDelivery' => ['privates', '.service_locator.FrSsn8W', 'get_ServiceLocator_FrSsn8WService', false],
            'App\\Controller\\DeliveryController::delete' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DeliveryController::edit' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DeliveryController::index' => ['privates', '.service_locator.FrSsn8W', 'get_ServiceLocator_FrSsn8WService', false],
            'App\\Controller\\DeliveryController::new' => ['privates', '.service_locator.iP8eVIx', 'get_ServiceLocator_IP8eVIxService', false],
            'App\\Controller\\DeliveryController::show' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DriverController::delete' => ['privates', '.service_locator.4gHrsrg', 'get_ServiceLocator_4gHrsrgService', false],
            'App\\Controller\\DriverController::edit' => ['privates', '.service_locator.4gHrsrg', 'get_ServiceLocator_4gHrsrgService', false],
            'App\\Controller\\DriverController::index' => ['privates', '.service_locator.lX1ZHLN', 'get_ServiceLocator_LX1ZHLNService', false],
            'App\\Controller\\DriverController::show' => ['privates', '.service_locator.4gHrsrg', 'get_ServiceLocator_4gHrsrgService', false],
            'App\\Controller\\HatchersController::delete' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HatchersController::edit' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HatchersController::getChickTemperatureInHatcher' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HatchersController::index' => ['privates', '.service_locator.8pMVo_M', 'get_ServiceLocator_8pMVoMService', false],
            'App\\Controller\\HatchersController::show' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HerdsController::active' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\HerdsController::breeder' => ['privates', '.service_locator.A0OcCfX', 'get_ServiceLocator_A0OcCfXService', false],
            'App\\Controller\\HerdsController::delete' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\HerdsController::edit' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\HerdsController::index' => ['privates', '.service_locator.KfFw_BS', 'get_ServiceLocator_KfFwBSService', false],
            'App\\Controller\\HerdsController::show' => ['privates', '.service_locator.7GGDOJU', 'get_ServiceLocator_7GGDOJUService', false],
            'App\\Controller\\InputDeliveryController::checkStockEggs' => ['privates', '.service_locator.LhOy3Zo', 'get_ServiceLocator_LhOy3ZoService', false],
            'App\\Controller\\InputDeliveryController::delete' => ['privates', '.service_locator.NBaPSWt', 'get_ServiceLocator_NBaPSWtService', false],
            'App\\Controller\\InputDeliveryController::edit' => ['privates', '.service_locator.NBaPSWt', 'get_ServiceLocator_NBaPSWtService', false],
            'App\\Controller\\InputDeliveryController::herdDeliveryOnStock' => ['privates', '.service_locator.dDx38tR', 'get_ServiceLocator_DDx38tRService', false],
            'App\\Controller\\InputDeliveryController::index' => ['privates', '.service_locator.6Vugu6d', 'get_ServiceLocator_6Vugu6dService', false],
            'App\\Controller\\InputDeliveryController::show' => ['privates', '.service_locator.NBaPSWt', 'get_ServiceLocator_NBaPSWtService', false],
            'App\\Controller\\InputsController::delete' => ['privates', '.service_locator.VrKIhbE', 'get_ServiceLocator_VrKIhbEService', false],
            'App\\Controller\\InputsController::edit' => ['privates', '.service_locator.VrKIhbE', 'get_ServiceLocator_VrKIhbEService', false],
            'App\\Controller\\InputsController::index' => ['privates', '.service_locator.2ViFXR5', 'get_ServiceLocator_2ViFXR5Service', false],
            'App\\Controller\\InputsController::show' => ['privates', '.service_locator.KinxmXU', 'get_ServiceLocator_KinxmXUService', false],
            'App\\Controller\\InputsFarmController::delete' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmController::deletePlan' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmController::edit' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmController::show' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmDeliveryPlanController::delete' => ['privates', '.service_locator.cQuFK9R', 'get_ServiceLocator_CQuFK9RService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController::edit' => ['privates', '.service_locator.cQuFK9R', 'get_ServiceLocator_CQuFK9RService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController::index' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController::inputsShow' => ['privates', '.service_locator.v0RJ6N8', 'get_ServiceLocator_V0RJ6N8Service', false],
            'App\\Controller\\InputsFarmDeliveryPlanController::list' => ['privates', '.service_locator.BKc.8Yh', 'get_ServiceLocator_BKc_8YhService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController::new' => ['privates', '.service_locator._OEZtLO', 'get_ServiceLocator_OEZtLOService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController::show' => ['privates', '.service_locator.cQuFK9R', 'get_ServiceLocator_CQuFK9RService', false],
            'App\\Controller\\LightingController::delete' => ['privates', '.service_locator.YVUVBTC', 'get_ServiceLocator_YVUVBTCService', false],
            'App\\Controller\\LightingController::index' => ['privates', '.service_locator.skRqFqk', 'get_ServiceLocator_SkRqFqkService', false],
            'App\\Controller\\LightingController::new' => ['privates', '.service_locator.yyxnYO4', 'get_ServiceLocator_YyxnYO4Service', false],
            'App\\Controller\\LightingController::showNoLighting' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\PlanBreederController::index' => ['privates', '.service_locator._1MUdwY', 'get_ServiceLocator_1MUdwYService', false],
            'App\\Controller\\PlanBreederController::week' => ['privates', '.service_locator._1MUdwY', 'get_ServiceLocator_1MUdwYService', false],
            'App\\Controller\\PlanController::eggsInStock' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\PlanController::herdDeliveryIndex' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\PlanController::herdDeliveryPdf' => ['privates', '.service_locator.VF1w2VI', 'get_ServiceLocator_VF1w2VIService', false],
            'App\\Controller\\PlanController::planEggs' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\PlanDeliveryChickController::delete' => ['privates', '.service_locator.z1yUq3Y', 'get_ServiceLocator_Z1yUq3YService', false],
            'App\\Controller\\PlanDeliveryChickController::edit' => ['privates', '.service_locator.z1yUq3Y', 'get_ServiceLocator_Z1yUq3YService', false],
            'App\\Controller\\PlanDeliveryChickController::index' => ['privates', '.service_locator.9YaQrws', 'get_ServiceLocator_9YaQrwsService', false],
            'App\\Controller\\PlanDeliveryChickController::show' => ['privates', '.service_locator.z1yUq3Y', 'get_ServiceLocator_Z1yUq3YService', false],
            'App\\Controller\\PlanDeliveryChickController::weekCustomer' => ['privates', '.service_locator.W.YOCo6', 'get_ServiceLocator_W_YOCo6Service', false],
            'App\\Controller\\PlanDeliveryEggController::delete' => ['privates', '.service_locator.T6odLp1', 'get_ServiceLocator_T6odLp1Service', false],
            'App\\Controller\\PlanDeliveryEggController::edit' => ['privates', '.service_locator.T6odLp1', 'get_ServiceLocator_T6odLp1Service', false],
            'App\\Controller\\PlanDeliveryEggController::herd' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\PlanDeliveryEggController::index' => ['privates', '.service_locator.3fPcA2g', 'get_ServiceLocator_3fPcA2gService', false],
            'App\\Controller\\PlanDeliveryEggController::show' => ['privates', '.service_locator.T6odLp1', 'get_ServiceLocator_T6odLp1Service', false],
            'App\\Controller\\PlanHatchingDateController::index' => ['privates', '.service_locator.KfFw_BS', 'get_ServiceLocator_KfFwBSService', false],
            'App\\Controller\\PlanHatchingDateController::indexDay' => ['privates', '.service_locator.ItH1Gr.', 'get_ServiceLocator_ItH1Gr_Service', false],
            'App\\Controller\\PlanHatchingDateController::week' => ['privates', '.service_locator.ItH1Gr.', 'get_ServiceLocator_ItH1Gr_Service', false],
            'App\\Controller\\PlanIndicatorsController::delete' => ['privates', '.service_locator._WYX_x_', 'get_ServiceLocator_WYXXService', false],
            'App\\Controller\\PlanIndicatorsController::edit' => ['privates', '.service_locator._WYX_x_', 'get_ServiceLocator_WYXXService', false],
            'App\\Controller\\PlanIndicatorsController::index' => ['privates', '.service_locator.ab94eYl', 'get_ServiceLocator_Ab94eYlService', false],
            'App\\Controller\\PlanIndicatorsController::show' => ['privates', '.service_locator._WYX_x_', 'get_ServiceLocator_WYXXService', false],
            'App\\Controller\\PlanInputController::delete' => ['privates', '.service_locator.6uRO9y9', 'get_ServiceLocator_6uRO9y9Service', false],
            'App\\Controller\\PlanInputController::edit' => ['privates', '.service_locator.6uRO9y9', 'get_ServiceLocator_6uRO9y9Service', false],
            'App\\Controller\\PlanInputController::index' => ['privates', '.service_locator.7npc7Mc', 'get_ServiceLocator_7npc7McService', false],
            'App\\Controller\\PlanInputController::show' => ['privates', '.service_locator.6uRO9y9', 'get_ServiceLocator_6uRO9y9Service', false],
            'App\\Controller\\Production\\ProductionChickTemperatureController::chickTemperatureHatcher' => ['privates', '.service_locator.s_RWU_Q', 'get_ServiceLocator_SRWUQService', false],
            'App\\Controller\\Production\\ProductionDeliveryController::deliveryHerd' => ['privates', '.service_locator.bov.xyt', 'get_ServiceLocator_Bov_XytService', false],
            'App\\Controller\\Production\\ProductionDeliveryController::deliveryNew' => ['privates', '.service_locator.QQJCbua', 'get_ServiceLocator_QQJCbuaService', false],
            'App\\Controller\\Production\\ProductionDeliveryController::deliverySupplier' => ['privates', '.service_locator.BnM8aS0', 'get_ServiceLocator_BnM8aS0Service', false],
            'App\\Controller\\Production\\ProductionInputsController::checkStockEggs' => ['privates', '.service_locator.LhOy3Zo', 'get_ServiceLocator_LhOy3ZoService', false],
            'App\\Controller\\Production\\ProductionInputsController::herdDeliveryOnStock' => ['privates', '.service_locator.dDx38tR', 'get_ServiceLocator_DDx38tRService', false],
            'App\\Controller\\Production\\ProductionInputsController::inputNew' => ['privates', '.service_locator.xh.Ejip', 'get_ServiceLocator_Xh_EjipService', false],
            'App\\Controller\\Production\\ProductionInputsController::inputsBreeder' => ['privates', '.service_locator.0RTtFZW', 'get_ServiceLocator_0RTtFZWService', false],
            'App\\Controller\\Production\\ProductionInputsController::inputsHerd' => ['privates', '.service_locator.kgeYX4r', 'get_ServiceLocator_KgeYX4rService', false],
            'App\\Controller\\Production\\ProductionLightingController::lightingHerd' => ['privates', '.service_locator.0RTtFZW', 'get_ServiceLocator_0RTtFZWService', false],
            'App\\Controller\\Production\\ProductionSelectionController::selectionsFarm' => ['privates', '.service_locator.s_RWU_Q', 'get_ServiceLocator_SRWUQService', false],
            'App\\Controller\\Production\\ProductionSelectionController::selectionsHerd' => ['privates', '.service_locator.RVTGs6k', 'get_ServiceLocator_RVTGs6kService', false],
            'App\\Controller\\Production\\ProductionTransferController::transferFarm' => ['privates', '.service_locator.s_RWU_Q', 'get_ServiceLocator_SRWUQService', false],
            'App\\Controller\\Production\\ProductionTransferController::transferHerd' => ['privates', '.service_locator.RVTGs6k', 'get_ServiceLocator_RVTGs6kService', false],
            'App\\Controller\\RegistrationController::register' => ['privates', '.service_locator.ccM2MGC', 'get_ServiceLocator_CcM2MGCService', false],
            'App\\Controller\\ResetPasswordController::request' => ['privates', '.service_locator.8ZuNAXa', 'get_ServiceLocator_8ZuNAXaService', false],
            'App\\Controller\\ResetPasswordController::reset' => ['privates', '.service_locator.ccM2MGC', 'get_ServiceLocator_CcM2MGCService', false],
            'App\\Controller\\SecurityController::login' => ['privates', '.service_locator.g.xob4v', 'get_ServiceLocator_G_Xob4vService', false],
            'App\\Controller\\SelectionsController::delete' => ['privates', '.service_locator.UziN_hh', 'get_ServiceLocator_UziNHhService', false],
            'App\\Controller\\SelectionsController::edit' => ['privates', '.service_locator.UziN_hh', 'get_ServiceLocator_UziNHhService', false],
            'App\\Controller\\SelectionsController::index' => ['privates', '.service_locator.DckF3wx', 'get_ServiceLocator_DckF3wxService', false],
            'App\\Controller\\SelectionsController::new' => ['privates', '.service_locator.fX4ImNz', 'get_ServiceLocator_FX4ImNzService', false],
            'App\\Controller\\SelectionsController::show' => ['privates', '.service_locator.UziN_hh', 'get_ServiceLocator_UziNHhService', false],
            'App\\Controller\\SelectionsController::showNoSelection' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\SellingEggController::delete' => ['privates', '.service_locator.kFWiiLA', 'get_ServiceLocator_KFWiiLAService', false],
            'App\\Controller\\SellingEggController::edit' => ['privates', '.service_locator.kFWiiLA', 'get_ServiceLocator_KFWiiLAService', false],
            'App\\Controller\\SellingEggController::index' => ['privates', '.service_locator.9I6nq7p', 'get_ServiceLocator_9I6nq7pService', false],
            'App\\Controller\\SellingEggController::show' => ['privates', '.service_locator.kFWiiLA', 'get_ServiceLocator_KFWiiLAService', false],
            'App\\Controller\\SettersController::delete' => ['privates', '.service_locator.hl5g9CG', 'get_ServiceLocator_Hl5g9CGService', false],
            'App\\Controller\\SettersController::edit' => ['privates', '.service_locator.hl5g9CG', 'get_ServiceLocator_Hl5g9CGService', false],
            'App\\Controller\\SettersController::index' => ['privates', '.service_locator.CQ5DlG.', 'get_ServiceLocator_CQ5DlG_Service', false],
            'App\\Controller\\SettersController::show' => ['privates', '.service_locator.hl5g9CG', 'get_ServiceLocator_Hl5g9CGService', false],
            'App\\Controller\\SupplierController::delete' => ['privates', '.service_locator.A8uXX_2', 'get_ServiceLocator_A8uXX2Service', false],
            'App\\Controller\\SupplierController::edit' => ['privates', '.service_locator.A8uXX_2', 'get_ServiceLocator_A8uXX2Service', false],
            'App\\Controller\\SupplierController::index' => ['privates', '.service_locator.j7YlT0U', 'get_ServiceLocator_J7YlT0UService', false],
            'App\\Controller\\SupplierController::show' => ['privates', '.service_locator.A8uXX_2', 'get_ServiceLocator_A8uXX2Service', false],
            'App\\Controller\\TransfersController::delete' => ['privates', '.service_locator.l1XZ2mI', 'get_ServiceLocator_L1XZ2mIService', false],
            'App\\Controller\\TransfersController::edit' => ['privates', '.service_locator.l1XZ2mI', 'get_ServiceLocator_L1XZ2mIService', false],
            'App\\Controller\\TransfersController::index' => ['privates', '.service_locator.YjdEfJn', 'get_ServiceLocator_YjdEfJnService', false],
            'App\\Controller\\TransfersController::new' => ['privates', '.service_locator.fX4ImNz', 'get_ServiceLocator_FX4ImNzService', false],
            'App\\Controller\\TransfersController::show' => ['privates', '.service_locator.l1XZ2mI', 'get_ServiceLocator_L1XZ2mIService', false],
            'App\\Controller\\TransfersController::showNoTransfer' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\TransportListController::delete' => ['privates', '.service_locator.51x_oDo', 'get_ServiceLocator_51xODoService', false],
            'App\\Controller\\TransportListController::edit' => ['privates', '.service_locator.51x_oDo', 'get_ServiceLocator_51xODoService', false],
            'App\\Controller\\TransportListController::index' => ['privates', '.service_locator.cVn5ICU', 'get_ServiceLocator_CVn5ICUService', false],
            'App\\Controller\\TransportListController::show' => ['privates', '.service_locator.51x_oDo', 'get_ServiceLocator_51xODoService', false],
            'App\\Controller\\UserController::delete' => ['privates', '.service_locator.tIQ5Q0N', 'get_ServiceLocator_TIQ5Q0NService', false],
            'App\\Controller\\UserController::edit' => ['privates', '.service_locator.tIQ5Q0N', 'get_ServiceLocator_TIQ5Q0NService', false],
            'App\\Controller\\UserController::index' => ['privates', '.service_locator.1UuH9tO', 'get_ServiceLocator_1UuH9tOService', false],
            'App\\Controller\\UserController::show' => ['privates', '.service_locator.tIQ5Q0N', 'get_ServiceLocator_TIQ5Q0NService', false],
            'App\\Controller\\VaccinationController::delete' => ['privates', '.service_locator.mQpOpia', 'get_ServiceLocator_MQpOpiaService', false],
            'App\\Controller\\VaccinationController::edit' => ['privates', '.service_locator.mQpOpia', 'get_ServiceLocator_MQpOpiaService', false],
            'App\\Controller\\VaccinationController::index' => ['privates', '.service_locator.aCqsVwX', 'get_ServiceLocator_ACqsVwXService', false],
            'App\\Controller\\VaccinationController::show' => ['privates', '.service_locator.mQpOpia', 'get_ServiceLocator_MQpOpiaService', false],
            'App\\Security\\AccessDeniedHandler::handle' => ['privates', '.service_locator.ISCZ1YP', 'get_ServiceLocator_ISCZ1YPService', false],
            'DH\\AuditorBundle\\Controller\\ViewerController::listAuditsAction' => ['privates', '.service_locator.Kpi1dqa', 'get_ServiceLocator_Kpi1dqaService', false],
            'DH\\AuditorBundle\\Controller\\ViewerController::showEntityHistoryAction' => ['privates', '.service_locator.Kpi1dqa', 'get_ServiceLocator_Kpi1dqaService', false],
            'DH\\AuditorBundle\\Controller\\ViewerController::showTransactionAction' => ['privates', '.service_locator.Kpi1dqa', 'get_ServiceLocator_Kpi1dqaService', false],
            'App\\Controller\\BreedController:delete' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\BreedController:edit' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\BreedController:index' => ['privates', '.service_locator.jxVy_9b', 'get_ServiceLocator_JxVy9bService', false],
            'App\\Controller\\BreedController:show' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\BreedStandardController:delete' => ['privates', '.service_locator.hcga3N6', 'get_ServiceLocator_Hcga3N6Service', false],
            'App\\Controller\\BreedStandardController:edit' => ['privates', '.service_locator.hcga3N6', 'get_ServiceLocator_Hcga3N6Service', false],
            'App\\Controller\\BreedStandardController:index' => ['privates', '.service_locator.UubWFXd', 'get_ServiceLocator_UubWFXdService', false],
            'App\\Controller\\BreedStandardController:show' => ['privates', '.service_locator.hcga3N6', 'get_ServiceLocator_Hcga3N6Service', false],
            'App\\Controller\\CarController:delete' => ['privates', '.service_locator.uzilRCW', 'get_ServiceLocator_UzilRCWService', false],
            'App\\Controller\\CarController:edit' => ['privates', '.service_locator.uzilRCW', 'get_ServiceLocator_UzilRCWService', false],
            'App\\Controller\\CarController:index' => ['privates', '.service_locator.OaAVb7K', 'get_ServiceLocator_OaAVb7KService', false],
            'App\\Controller\\CarController:show' => ['privates', '.service_locator.uzilRCW', 'get_ServiceLocator_UzilRCWService', false],
            'App\\Controller\\ChickIntegrationController:delete' => ['privates', '.service_locator.aPT4Rqb', 'get_ServiceLocator_APT4RqbService', false],
            'App\\Controller\\ChickIntegrationController:edit' => ['privates', '.service_locator.aPT4Rqb', 'get_ServiceLocator_APT4RqbService', false],
            'App\\Controller\\ChickIntegrationController:index' => ['privates', '.service_locator.vc.JCrN', 'get_ServiceLocator_Vc_JCrNService', false],
            'App\\Controller\\ChickIntegrationController:show' => ['privates', '.service_locator.aPT4Rqb', 'get_ServiceLocator_APT4RqbService', false],
            'App\\Controller\\ChickTemperatureController:delete' => ['privates', '.service_locator.Dn9kS4t', 'get_ServiceLocator_Dn9kS4tService', false],
            'App\\Controller\\ChickTemperatureController:edit' => ['privates', '.service_locator.Dn9kS4t', 'get_ServiceLocator_Dn9kS4tService', false],
            'App\\Controller\\ChickTemperatureController:index' => ['privates', '.service_locator.uuLauoa', 'get_ServiceLocator_UuLauoaService', false],
            'App\\Controller\\ChickTemperatureController:show' => ['privates', '.service_locator.Dn9kS4t', 'get_ServiceLocator_Dn9kS4tService', false],
            'App\\Controller\\ChicksRecipientController:customerIndex' => ['privates', '.service_locator.DjlexR7', 'get_ServiceLocator_DjlexR7Service', false],
            'App\\Controller\\ChicksRecipientController:delete' => ['privates', '.service_locator.MtlBFkc', 'get_ServiceLocator_MtlBFkcService', false],
            'App\\Controller\\ChicksRecipientController:edit' => ['privates', '.service_locator.MtlBFkc', 'get_ServiceLocator_MtlBFkcService', false],
            'App\\Controller\\ChicksRecipientController:index' => ['privates', '.service_locator.sOiJzIJ', 'get_ServiceLocator_SOiJzIJService', false],
            'App\\Controller\\ChicksRecipientController:show' => ['privates', '.service_locator.G4rkM_4', 'get_ServiceLocator_G4rkM4Service', false],
            'App\\Controller\\ContactInfoController:delete' => ['privates', '.service_locator.yZPm2Ey', 'get_ServiceLocator_YZPm2EyService', false],
            'App\\Controller\\ContactInfoController:edit' => ['privates', '.service_locator.yZPm2Ey', 'get_ServiceLocator_YZPm2EyService', false],
            'App\\Controller\\ContactInfoController:index' => ['privates', '.service_locator.Ayv8Hbr', 'get_ServiceLocator_Ayv8HbrService', false],
            'App\\Controller\\ContactInfoController:show' => ['privates', '.service_locator.yZPm2Ey', 'get_ServiceLocator_YZPm2EyService', false],
            'App\\Controller\\CustomerController:delete' => ['privates', '.service_locator.7NSCnyQ', 'get_ServiceLocator_7NSCnyQService', false],
            'App\\Controller\\CustomerController:edit' => ['privates', '.service_locator.7NSCnyQ', 'get_ServiceLocator_7NSCnyQService', false],
            'App\\Controller\\CustomerController:index' => ['privates', '.service_locator.heBOatc', 'get_ServiceLocator_HeBOatcService', false],
            'App\\Controller\\CustomerController:show' => ['privates', '.service_locator.7NSCnyQ', 'get_ServiceLocator_7NSCnyQService', false],
            'App\\Controller\\DefaultController:incubators' => ['privates', '.service_locator._aCulUr', 'get_ServiceLocator_ACulUrService', false],
            'App\\Controller\\DefaultController:index' => ['privates', '.service_locator.WiUKNEm', 'get_ServiceLocator_WiUKNEmService', false],
            'App\\Controller\\DefaultController:indexPdf' => ['privates', '.service_locator.CWSFabL', 'get_ServiceLocator_CWSFabLService', false],
            'App\\Controller\\DeliveryController:addPartIndex' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DeliveryController:allDelivery' => ['privates', '.service_locator.FrSsn8W', 'get_ServiceLocator_FrSsn8WService', false],
            'App\\Controller\\DeliveryController:delete' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DeliveryController:edit' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DeliveryController:index' => ['privates', '.service_locator.FrSsn8W', 'get_ServiceLocator_FrSsn8WService', false],
            'App\\Controller\\DeliveryController:new' => ['privates', '.service_locator.iP8eVIx', 'get_ServiceLocator_IP8eVIxService', false],
            'App\\Controller\\DeliveryController:show' => ['privates', '.service_locator.akaboVt', 'get_ServiceLocator_AkaboVtService', false],
            'App\\Controller\\DriverController:delete' => ['privates', '.service_locator.4gHrsrg', 'get_ServiceLocator_4gHrsrgService', false],
            'App\\Controller\\DriverController:edit' => ['privates', '.service_locator.4gHrsrg', 'get_ServiceLocator_4gHrsrgService', false],
            'App\\Controller\\DriverController:index' => ['privates', '.service_locator.lX1ZHLN', 'get_ServiceLocator_LX1ZHLNService', false],
            'App\\Controller\\DriverController:show' => ['privates', '.service_locator.4gHrsrg', 'get_ServiceLocator_4gHrsrgService', false],
            'App\\Controller\\HatchersController:delete' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HatchersController:edit' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HatchersController:getChickTemperatureInHatcher' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HatchersController:index' => ['privates', '.service_locator.8pMVo_M', 'get_ServiceLocator_8pMVoMService', false],
            'App\\Controller\\HatchersController:show' => ['privates', '.service_locator.cYwVkCd', 'get_ServiceLocator_CYwVkCdService', false],
            'App\\Controller\\HerdsController:active' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\HerdsController:breeder' => ['privates', '.service_locator.A0OcCfX', 'get_ServiceLocator_A0OcCfXService', false],
            'App\\Controller\\HerdsController:delete' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\HerdsController:edit' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\HerdsController:index' => ['privates', '.service_locator.KfFw_BS', 'get_ServiceLocator_KfFwBSService', false],
            'App\\Controller\\HerdsController:show' => ['privates', '.service_locator.7GGDOJU', 'get_ServiceLocator_7GGDOJUService', false],
            'App\\Controller\\InputDeliveryController:checkStockEggs' => ['privates', '.service_locator.LhOy3Zo', 'get_ServiceLocator_LhOy3ZoService', false],
            'App\\Controller\\InputDeliveryController:delete' => ['privates', '.service_locator.NBaPSWt', 'get_ServiceLocator_NBaPSWtService', false],
            'App\\Controller\\InputDeliveryController:edit' => ['privates', '.service_locator.NBaPSWt', 'get_ServiceLocator_NBaPSWtService', false],
            'App\\Controller\\InputDeliveryController:herdDeliveryOnStock' => ['privates', '.service_locator.dDx38tR', 'get_ServiceLocator_DDx38tRService', false],
            'App\\Controller\\InputDeliveryController:index' => ['privates', '.service_locator.6Vugu6d', 'get_ServiceLocator_6Vugu6dService', false],
            'App\\Controller\\InputDeliveryController:show' => ['privates', '.service_locator.NBaPSWt', 'get_ServiceLocator_NBaPSWtService', false],
            'App\\Controller\\InputsController:delete' => ['privates', '.service_locator.VrKIhbE', 'get_ServiceLocator_VrKIhbEService', false],
            'App\\Controller\\InputsController:edit' => ['privates', '.service_locator.VrKIhbE', 'get_ServiceLocator_VrKIhbEService', false],
            'App\\Controller\\InputsController:index' => ['privates', '.service_locator.2ViFXR5', 'get_ServiceLocator_2ViFXR5Service', false],
            'App\\Controller\\InputsController:show' => ['privates', '.service_locator.KinxmXU', 'get_ServiceLocator_KinxmXUService', false],
            'App\\Controller\\InputsFarmController:delete' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmController:deletePlan' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmController:edit' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmController:show' => ['privates', '.service_locator.g.guwk1', 'get_ServiceLocator_G_Guwk1Service', false],
            'App\\Controller\\InputsFarmDeliveryPlanController:delete' => ['privates', '.service_locator.cQuFK9R', 'get_ServiceLocator_CQuFK9RService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController:edit' => ['privates', '.service_locator.cQuFK9R', 'get_ServiceLocator_CQuFK9RService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController:index' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController:inputsShow' => ['privates', '.service_locator.v0RJ6N8', 'get_ServiceLocator_V0RJ6N8Service', false],
            'App\\Controller\\InputsFarmDeliveryPlanController:list' => ['privates', '.service_locator.BKc.8Yh', 'get_ServiceLocator_BKc_8YhService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController:new' => ['privates', '.service_locator._OEZtLO', 'get_ServiceLocator_OEZtLOService', false],
            'App\\Controller\\InputsFarmDeliveryPlanController:show' => ['privates', '.service_locator.cQuFK9R', 'get_ServiceLocator_CQuFK9RService', false],
            'App\\Controller\\LightingController:delete' => ['privates', '.service_locator.YVUVBTC', 'get_ServiceLocator_YVUVBTCService', false],
            'App\\Controller\\LightingController:index' => ['privates', '.service_locator.skRqFqk', 'get_ServiceLocator_SkRqFqkService', false],
            'App\\Controller\\LightingController:new' => ['privates', '.service_locator.yyxnYO4', 'get_ServiceLocator_YyxnYO4Service', false],
            'App\\Controller\\LightingController:showNoLighting' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\PlanBreederController:index' => ['privates', '.service_locator._1MUdwY', 'get_ServiceLocator_1MUdwYService', false],
            'App\\Controller\\PlanBreederController:week' => ['privates', '.service_locator._1MUdwY', 'get_ServiceLocator_1MUdwYService', false],
            'App\\Controller\\PlanController:eggsInStock' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\PlanController:herdDeliveryIndex' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\PlanController:herdDeliveryPdf' => ['privates', '.service_locator.VF1w2VI', 'get_ServiceLocator_VF1w2VIService', false],
            'App\\Controller\\PlanController:planEggs' => ['privates', '.service_locator.ufDOk6W', 'get_ServiceLocator_UfDOk6WService', false],
            'App\\Controller\\PlanDeliveryChickController:delete' => ['privates', '.service_locator.z1yUq3Y', 'get_ServiceLocator_Z1yUq3YService', false],
            'App\\Controller\\PlanDeliveryChickController:edit' => ['privates', '.service_locator.z1yUq3Y', 'get_ServiceLocator_Z1yUq3YService', false],
            'App\\Controller\\PlanDeliveryChickController:index' => ['privates', '.service_locator.9YaQrws', 'get_ServiceLocator_9YaQrwsService', false],
            'App\\Controller\\PlanDeliveryChickController:show' => ['privates', '.service_locator.z1yUq3Y', 'get_ServiceLocator_Z1yUq3YService', false],
            'App\\Controller\\PlanDeliveryChickController:weekCustomer' => ['privates', '.service_locator.W.YOCo6', 'get_ServiceLocator_W_YOCo6Service', false],
            'App\\Controller\\PlanDeliveryEggController:delete' => ['privates', '.service_locator.T6odLp1', 'get_ServiceLocator_T6odLp1Service', false],
            'App\\Controller\\PlanDeliveryEggController:edit' => ['privates', '.service_locator.T6odLp1', 'get_ServiceLocator_T6odLp1Service', false],
            'App\\Controller\\PlanDeliveryEggController:herd' => ['privates', '.service_locator._2Plx1P', 'get_ServiceLocator_2Plx1PService', false],
            'App\\Controller\\PlanDeliveryEggController:index' => ['privates', '.service_locator.3fPcA2g', 'get_ServiceLocator_3fPcA2gService', false],
            'App\\Controller\\PlanDeliveryEggController:show' => ['privates', '.service_locator.T6odLp1', 'get_ServiceLocator_T6odLp1Service', false],
            'App\\Controller\\PlanHatchingDateController:index' => ['privates', '.service_locator.KfFw_BS', 'get_ServiceLocator_KfFwBSService', false],
            'App\\Controller\\PlanHatchingDateController:indexDay' => ['privates', '.service_locator.ItH1Gr.', 'get_ServiceLocator_ItH1Gr_Service', false],
            'App\\Controller\\PlanHatchingDateController:week' => ['privates', '.service_locator.ItH1Gr.', 'get_ServiceLocator_ItH1Gr_Service', false],
            'App\\Controller\\PlanIndicatorsController:delete' => ['privates', '.service_locator._WYX_x_', 'get_ServiceLocator_WYXXService', false],
            'App\\Controller\\PlanIndicatorsController:edit' => ['privates', '.service_locator._WYX_x_', 'get_ServiceLocator_WYXXService', false],
            'App\\Controller\\PlanIndicatorsController:index' => ['privates', '.service_locator.ab94eYl', 'get_ServiceLocator_Ab94eYlService', false],
            'App\\Controller\\PlanIndicatorsController:show' => ['privates', '.service_locator._WYX_x_', 'get_ServiceLocator_WYXXService', false],
            'App\\Controller\\PlanInputController:delete' => ['privates', '.service_locator.6uRO9y9', 'get_ServiceLocator_6uRO9y9Service', false],
            'App\\Controller\\PlanInputController:edit' => ['privates', '.service_locator.6uRO9y9', 'get_ServiceLocator_6uRO9y9Service', false],
            'App\\Controller\\PlanInputController:index' => ['privates', '.service_locator.7npc7Mc', 'get_ServiceLocator_7npc7McService', false],
            'App\\Controller\\PlanInputController:show' => ['privates', '.service_locator.6uRO9y9', 'get_ServiceLocator_6uRO9y9Service', false],
            'App\\Controller\\Production\\ProductionChickTemperatureController:chickTemperatureHatcher' => ['privates', '.service_locator.s_RWU_Q', 'get_ServiceLocator_SRWUQService', false],
            'App\\Controller\\Production\\ProductionDeliveryController:deliveryHerd' => ['privates', '.service_locator.bov.xyt', 'get_ServiceLocator_Bov_XytService', false],
            'App\\Controller\\Production\\ProductionDeliveryController:deliveryNew' => ['privates', '.service_locator.QQJCbua', 'get_ServiceLocator_QQJCbuaService', false],
            'App\\Controller\\Production\\ProductionDeliveryController:deliverySupplier' => ['privates', '.service_locator.BnM8aS0', 'get_ServiceLocator_BnM8aS0Service', false],
            'App\\Controller\\Production\\ProductionInputsController:checkStockEggs' => ['privates', '.service_locator.LhOy3Zo', 'get_ServiceLocator_LhOy3ZoService', false],
            'App\\Controller\\Production\\ProductionInputsController:herdDeliveryOnStock' => ['privates', '.service_locator.dDx38tR', 'get_ServiceLocator_DDx38tRService', false],
            'App\\Controller\\Production\\ProductionInputsController:inputNew' => ['privates', '.service_locator.xh.Ejip', 'get_ServiceLocator_Xh_EjipService', false],
            'App\\Controller\\Production\\ProductionInputsController:inputsBreeder' => ['privates', '.service_locator.0RTtFZW', 'get_ServiceLocator_0RTtFZWService', false],
            'App\\Controller\\Production\\ProductionInputsController:inputsHerd' => ['privates', '.service_locator.kgeYX4r', 'get_ServiceLocator_KgeYX4rService', false],
            'App\\Controller\\Production\\ProductionLightingController:lightingHerd' => ['privates', '.service_locator.0RTtFZW', 'get_ServiceLocator_0RTtFZWService', false],
            'App\\Controller\\Production\\ProductionSelectionController:selectionsFarm' => ['privates', '.service_locator.s_RWU_Q', 'get_ServiceLocator_SRWUQService', false],
            'App\\Controller\\Production\\ProductionSelectionController:selectionsHerd' => ['privates', '.service_locator.RVTGs6k', 'get_ServiceLocator_RVTGs6kService', false],
            'App\\Controller\\Production\\ProductionTransferController:transferFarm' => ['privates', '.service_locator.s_RWU_Q', 'get_ServiceLocator_SRWUQService', false],
            'App\\Controller\\Production\\ProductionTransferController:transferHerd' => ['privates', '.service_locator.RVTGs6k', 'get_ServiceLocator_RVTGs6kService', false],
            'App\\Controller\\RegistrationController:register' => ['privates', '.service_locator.ccM2MGC', 'get_ServiceLocator_CcM2MGCService', false],
            'App\\Controller\\ResetPasswordController:request' => ['privates', '.service_locator.8ZuNAXa', 'get_ServiceLocator_8ZuNAXaService', false],
            'App\\Controller\\ResetPasswordController:reset' => ['privates', '.service_locator.ccM2MGC', 'get_ServiceLocator_CcM2MGCService', false],
            'App\\Controller\\SecurityController:login' => ['privates', '.service_locator.g.xob4v', 'get_ServiceLocator_G_Xob4vService', false],
            'App\\Controller\\SelectionsController:delete' => ['privates', '.service_locator.UziN_hh', 'get_ServiceLocator_UziNHhService', false],
            'App\\Controller\\SelectionsController:edit' => ['privates', '.service_locator.UziN_hh', 'get_ServiceLocator_UziNHhService', false],
            'App\\Controller\\SelectionsController:index' => ['privates', '.service_locator.DckF3wx', 'get_ServiceLocator_DckF3wxService', false],
            'App\\Controller\\SelectionsController:new' => ['privates', '.service_locator.fX4ImNz', 'get_ServiceLocator_FX4ImNzService', false],
            'App\\Controller\\SelectionsController:show' => ['privates', '.service_locator.UziN_hh', 'get_ServiceLocator_UziNHhService', false],
            'App\\Controller\\SelectionsController:showNoSelection' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\SellingEggController:delete' => ['privates', '.service_locator.kFWiiLA', 'get_ServiceLocator_KFWiiLAService', false],
            'App\\Controller\\SellingEggController:edit' => ['privates', '.service_locator.kFWiiLA', 'get_ServiceLocator_KFWiiLAService', false],
            'App\\Controller\\SellingEggController:index' => ['privates', '.service_locator.9I6nq7p', 'get_ServiceLocator_9I6nq7pService', false],
            'App\\Controller\\SellingEggController:show' => ['privates', '.service_locator.kFWiiLA', 'get_ServiceLocator_KFWiiLAService', false],
            'App\\Controller\\SettersController:delete' => ['privates', '.service_locator.hl5g9CG', 'get_ServiceLocator_Hl5g9CGService', false],
            'App\\Controller\\SettersController:edit' => ['privates', '.service_locator.hl5g9CG', 'get_ServiceLocator_Hl5g9CGService', false],
            'App\\Controller\\SettersController:index' => ['privates', '.service_locator.CQ5DlG.', 'get_ServiceLocator_CQ5DlG_Service', false],
            'App\\Controller\\SettersController:show' => ['privates', '.service_locator.hl5g9CG', 'get_ServiceLocator_Hl5g9CGService', false],
            'App\\Controller\\SupplierController:delete' => ['privates', '.service_locator.A8uXX_2', 'get_ServiceLocator_A8uXX2Service', false],
            'App\\Controller\\SupplierController:edit' => ['privates', '.service_locator.A8uXX_2', 'get_ServiceLocator_A8uXX2Service', false],
            'App\\Controller\\SupplierController:index' => ['privates', '.service_locator.j7YlT0U', 'get_ServiceLocator_J7YlT0UService', false],
            'App\\Controller\\SupplierController:show' => ['privates', '.service_locator.A8uXX_2', 'get_ServiceLocator_A8uXX2Service', false],
            'App\\Controller\\TransfersController:delete' => ['privates', '.service_locator.l1XZ2mI', 'get_ServiceLocator_L1XZ2mIService', false],
            'App\\Controller\\TransfersController:edit' => ['privates', '.service_locator.l1XZ2mI', 'get_ServiceLocator_L1XZ2mIService', false],
            'App\\Controller\\TransfersController:index' => ['privates', '.service_locator.YjdEfJn', 'get_ServiceLocator_YjdEfJnService', false],
            'App\\Controller\\TransfersController:new' => ['privates', '.service_locator.fX4ImNz', 'get_ServiceLocator_FX4ImNzService', false],
            'App\\Controller\\TransfersController:show' => ['privates', '.service_locator.l1XZ2mI', 'get_ServiceLocator_L1XZ2mIService', false],
            'App\\Controller\\TransfersController:showNoTransfer' => ['privates', '.service_locator.obuVz3B', 'get_ServiceLocator_ObuVz3BService', false],
            'App\\Controller\\TransportListController:delete' => ['privates', '.service_locator.51x_oDo', 'get_ServiceLocator_51xODoService', false],
            'App\\Controller\\TransportListController:edit' => ['privates', '.service_locator.51x_oDo', 'get_ServiceLocator_51xODoService', false],
            'App\\Controller\\TransportListController:index' => ['privates', '.service_locator.cVn5ICU', 'get_ServiceLocator_CVn5ICUService', false],
            'App\\Controller\\TransportListController:show' => ['privates', '.service_locator.51x_oDo', 'get_ServiceLocator_51xODoService', false],
            'App\\Controller\\UserController:delete' => ['privates', '.service_locator.tIQ5Q0N', 'get_ServiceLocator_TIQ5Q0NService', false],
            'App\\Controller\\UserController:edit' => ['privates', '.service_locator.tIQ5Q0N', 'get_ServiceLocator_TIQ5Q0NService', false],
            'App\\Controller\\UserController:index' => ['privates', '.service_locator.1UuH9tO', 'get_ServiceLocator_1UuH9tOService', false],
            'App\\Controller\\UserController:show' => ['privates', '.service_locator.tIQ5Q0N', 'get_ServiceLocator_TIQ5Q0NService', false],
            'App\\Controller\\VaccinationController:delete' => ['privates', '.service_locator.mQpOpia', 'get_ServiceLocator_MQpOpiaService', false],
            'App\\Controller\\VaccinationController:edit' => ['privates', '.service_locator.mQpOpia', 'get_ServiceLocator_MQpOpiaService', false],
            'App\\Controller\\VaccinationController:index' => ['privates', '.service_locator.aCqsVwX', 'get_ServiceLocator_ACqsVwXService', false],
            'App\\Controller\\VaccinationController:show' => ['privates', '.service_locator.mQpOpia', 'get_ServiceLocator_MQpOpiaService', false],
            'App\\Security\\AccessDeniedHandler:handle' => ['privates', '.service_locator.ISCZ1YP', 'get_ServiceLocator_ISCZ1YPService', false],
            'DH\\AuditorBundle\\Controller\\ViewerController:listAuditsAction' => ['privates', '.service_locator.Kpi1dqa', 'get_ServiceLocator_Kpi1dqaService', false],
            'DH\\AuditorBundle\\Controller\\ViewerController:showEntityHistoryAction' => ['privates', '.service_locator.Kpi1dqa', 'get_ServiceLocator_Kpi1dqaService', false],
            'DH\\AuditorBundle\\Controller\\ViewerController:showTransactionAction' => ['privates', '.service_locator.Kpi1dqa', 'get_ServiceLocator_Kpi1dqaService', false],
        ], [
            'App\\Controller\\BreedController::delete' => '?',
            'App\\Controller\\BreedController::edit' => '?',
            'App\\Controller\\BreedController::index' => '?',
            'App\\Controller\\BreedController::show' => '?',
            'App\\Controller\\BreedStandardController::delete' => '?',
            'App\\Controller\\BreedStandardController::edit' => '?',
            'App\\Controller\\BreedStandardController::index' => '?',
            'App\\Controller\\BreedStandardController::show' => '?',
            'App\\Controller\\CarController::delete' => '?',
            'App\\Controller\\CarController::edit' => '?',
            'App\\Controller\\CarController::index' => '?',
            'App\\Controller\\CarController::show' => '?',
            'App\\Controller\\ChickIntegrationController::delete' => '?',
            'App\\Controller\\ChickIntegrationController::edit' => '?',
            'App\\Controller\\ChickIntegrationController::index' => '?',
            'App\\Controller\\ChickIntegrationController::show' => '?',
            'App\\Controller\\ChickTemperatureController::delete' => '?',
            'App\\Controller\\ChickTemperatureController::edit' => '?',
            'App\\Controller\\ChickTemperatureController::index' => '?',
            'App\\Controller\\ChickTemperatureController::show' => '?',
            'App\\Controller\\ChicksRecipientController::customerIndex' => '?',
            'App\\Controller\\ChicksRecipientController::delete' => '?',
            'App\\Controller\\ChicksRecipientController::edit' => '?',
            'App\\Controller\\ChicksRecipientController::index' => '?',
            'App\\Controller\\ChicksRecipientController::show' => '?',
            'App\\Controller\\ContactInfoController::delete' => '?',
            'App\\Controller\\ContactInfoController::edit' => '?',
            'App\\Controller\\ContactInfoController::index' => '?',
            'App\\Controller\\ContactInfoController::show' => '?',
            'App\\Controller\\CustomerController::delete' => '?',
            'App\\Controller\\CustomerController::edit' => '?',
            'App\\Controller\\CustomerController::index' => '?',
            'App\\Controller\\CustomerController::show' => '?',
            'App\\Controller\\DefaultController::incubators' => '?',
            'App\\Controller\\DefaultController::index' => '?',
            'App\\Controller\\DefaultController::indexPdf' => '?',
            'App\\Controller\\DeliveryController::addPartIndex' => '?',
            'App\\Controller\\DeliveryController::allDelivery' => '?',
            'App\\Controller\\DeliveryController::delete' => '?',
            'App\\Controller\\DeliveryController::edit' => '?',
            'App\\Controller\\DeliveryController::index' => '?',
            'App\\Controller\\DeliveryController::new' => '?',
            'App\\Controller\\DeliveryController::show' => '?',
            'App\\Controller\\DriverController::delete' => '?',
            'App\\Controller\\DriverController::edit' => '?',
            'App\\Controller\\DriverController::index' => '?',
            'App\\Controller\\DriverController::show' => '?',
            'App\\Controller\\HatchersController::delete' => '?',
            'App\\Controller\\HatchersController::edit' => '?',
            'App\\Controller\\HatchersController::getChickTemperatureInHatcher' => '?',
            'App\\Controller\\HatchersController::index' => '?',
            'App\\Controller\\HatchersController::show' => '?',
            'App\\Controller\\HerdsController::active' => '?',
            'App\\Controller\\HerdsController::breeder' => '?',
            'App\\Controller\\HerdsController::delete' => '?',
            'App\\Controller\\HerdsController::edit' => '?',
            'App\\Controller\\HerdsController::index' => '?',
            'App\\Controller\\HerdsController::show' => '?',
            'App\\Controller\\InputDeliveryController::checkStockEggs' => '?',
            'App\\Controller\\InputDeliveryController::delete' => '?',
            'App\\Controller\\InputDeliveryController::edit' => '?',
            'App\\Controller\\InputDeliveryController::herdDeliveryOnStock' => '?',
            'App\\Controller\\InputDeliveryController::index' => '?',
            'App\\Controller\\InputDeliveryController::show' => '?',
            'App\\Controller\\InputsController::delete' => '?',
            'App\\Controller\\InputsController::edit' => '?',
            'App\\Controller\\InputsController::index' => '?',
            'App\\Controller\\InputsController::show' => '?',
            'App\\Controller\\InputsFarmController::delete' => '?',
            'App\\Controller\\InputsFarmController::deletePlan' => '?',
            'App\\Controller\\InputsFarmController::edit' => '?',
            'App\\Controller\\InputsFarmController::show' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController::delete' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController::edit' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController::index' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController::inputsShow' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController::list' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController::new' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController::show' => '?',
            'App\\Controller\\LightingController::delete' => '?',
            'App\\Controller\\LightingController::index' => '?',
            'App\\Controller\\LightingController::new' => '?',
            'App\\Controller\\LightingController::showNoLighting' => '?',
            'App\\Controller\\PlanBreederController::index' => '?',
            'App\\Controller\\PlanBreederController::week' => '?',
            'App\\Controller\\PlanController::eggsInStock' => '?',
            'App\\Controller\\PlanController::herdDeliveryIndex' => '?',
            'App\\Controller\\PlanController::herdDeliveryPdf' => '?',
            'App\\Controller\\PlanController::planEggs' => '?',
            'App\\Controller\\PlanDeliveryChickController::delete' => '?',
            'App\\Controller\\PlanDeliveryChickController::edit' => '?',
            'App\\Controller\\PlanDeliveryChickController::index' => '?',
            'App\\Controller\\PlanDeliveryChickController::show' => '?',
            'App\\Controller\\PlanDeliveryChickController::weekCustomer' => '?',
            'App\\Controller\\PlanDeliveryEggController::delete' => '?',
            'App\\Controller\\PlanDeliveryEggController::edit' => '?',
            'App\\Controller\\PlanDeliveryEggController::herd' => '?',
            'App\\Controller\\PlanDeliveryEggController::index' => '?',
            'App\\Controller\\PlanDeliveryEggController::show' => '?',
            'App\\Controller\\PlanHatchingDateController::index' => '?',
            'App\\Controller\\PlanHatchingDateController::indexDay' => '?',
            'App\\Controller\\PlanHatchingDateController::week' => '?',
            'App\\Controller\\PlanIndicatorsController::delete' => '?',
            'App\\Controller\\PlanIndicatorsController::edit' => '?',
            'App\\Controller\\PlanIndicatorsController::index' => '?',
            'App\\Controller\\PlanIndicatorsController::show' => '?',
            'App\\Controller\\PlanInputController::delete' => '?',
            'App\\Controller\\PlanInputController::edit' => '?',
            'App\\Controller\\PlanInputController::index' => '?',
            'App\\Controller\\PlanInputController::show' => '?',
            'App\\Controller\\Production\\ProductionChickTemperatureController::chickTemperatureHatcher' => '?',
            'App\\Controller\\Production\\ProductionDeliveryController::deliveryHerd' => '?',
            'App\\Controller\\Production\\ProductionDeliveryController::deliveryNew' => '?',
            'App\\Controller\\Production\\ProductionDeliveryController::deliverySupplier' => '?',
            'App\\Controller\\Production\\ProductionInputsController::checkStockEggs' => '?',
            'App\\Controller\\Production\\ProductionInputsController::herdDeliveryOnStock' => '?',
            'App\\Controller\\Production\\ProductionInputsController::inputNew' => '?',
            'App\\Controller\\Production\\ProductionInputsController::inputsBreeder' => '?',
            'App\\Controller\\Production\\ProductionInputsController::inputsHerd' => '?',
            'App\\Controller\\Production\\ProductionLightingController::lightingHerd' => '?',
            'App\\Controller\\Production\\ProductionSelectionController::selectionsFarm' => '?',
            'App\\Controller\\Production\\ProductionSelectionController::selectionsHerd' => '?',
            'App\\Controller\\Production\\ProductionTransferController::transferFarm' => '?',
            'App\\Controller\\Production\\ProductionTransferController::transferHerd' => '?',
            'App\\Controller\\RegistrationController::register' => '?',
            'App\\Controller\\ResetPasswordController::request' => '?',
            'App\\Controller\\ResetPasswordController::reset' => '?',
            'App\\Controller\\SecurityController::login' => '?',
            'App\\Controller\\SelectionsController::delete' => '?',
            'App\\Controller\\SelectionsController::edit' => '?',
            'App\\Controller\\SelectionsController::index' => '?',
            'App\\Controller\\SelectionsController::new' => '?',
            'App\\Controller\\SelectionsController::show' => '?',
            'App\\Controller\\SelectionsController::showNoSelection' => '?',
            'App\\Controller\\SellingEggController::delete' => '?',
            'App\\Controller\\SellingEggController::edit' => '?',
            'App\\Controller\\SellingEggController::index' => '?',
            'App\\Controller\\SellingEggController::show' => '?',
            'App\\Controller\\SettersController::delete' => '?',
            'App\\Controller\\SettersController::edit' => '?',
            'App\\Controller\\SettersController::index' => '?',
            'App\\Controller\\SettersController::show' => '?',
            'App\\Controller\\SupplierController::delete' => '?',
            'App\\Controller\\SupplierController::edit' => '?',
            'App\\Controller\\SupplierController::index' => '?',
            'App\\Controller\\SupplierController::show' => '?',
            'App\\Controller\\TransfersController::delete' => '?',
            'App\\Controller\\TransfersController::edit' => '?',
            'App\\Controller\\TransfersController::index' => '?',
            'App\\Controller\\TransfersController::new' => '?',
            'App\\Controller\\TransfersController::show' => '?',
            'App\\Controller\\TransfersController::showNoTransfer' => '?',
            'App\\Controller\\TransportListController::delete' => '?',
            'App\\Controller\\TransportListController::edit' => '?',
            'App\\Controller\\TransportListController::index' => '?',
            'App\\Controller\\TransportListController::show' => '?',
            'App\\Controller\\UserController::delete' => '?',
            'App\\Controller\\UserController::edit' => '?',
            'App\\Controller\\UserController::index' => '?',
            'App\\Controller\\UserController::show' => '?',
            'App\\Controller\\VaccinationController::delete' => '?',
            'App\\Controller\\VaccinationController::edit' => '?',
            'App\\Controller\\VaccinationController::index' => '?',
            'App\\Controller\\VaccinationController::show' => '?',
            'App\\Security\\AccessDeniedHandler::handle' => '?',
            'DH\\AuditorBundle\\Controller\\ViewerController::listAuditsAction' => '?',
            'DH\\AuditorBundle\\Controller\\ViewerController::showEntityHistoryAction' => '?',
            'DH\\AuditorBundle\\Controller\\ViewerController::showTransactionAction' => '?',
            'App\\Controller\\BreedController:delete' => '?',
            'App\\Controller\\BreedController:edit' => '?',
            'App\\Controller\\BreedController:index' => '?',
            'App\\Controller\\BreedController:show' => '?',
            'App\\Controller\\BreedStandardController:delete' => '?',
            'App\\Controller\\BreedStandardController:edit' => '?',
            'App\\Controller\\BreedStandardController:index' => '?',
            'App\\Controller\\BreedStandardController:show' => '?',
            'App\\Controller\\CarController:delete' => '?',
            'App\\Controller\\CarController:edit' => '?',
            'App\\Controller\\CarController:index' => '?',
            'App\\Controller\\CarController:show' => '?',
            'App\\Controller\\ChickIntegrationController:delete' => '?',
            'App\\Controller\\ChickIntegrationController:edit' => '?',
            'App\\Controller\\ChickIntegrationController:index' => '?',
            'App\\Controller\\ChickIntegrationController:show' => '?',
            'App\\Controller\\ChickTemperatureController:delete' => '?',
            'App\\Controller\\ChickTemperatureController:edit' => '?',
            'App\\Controller\\ChickTemperatureController:index' => '?',
            'App\\Controller\\ChickTemperatureController:show' => '?',
            'App\\Controller\\ChicksRecipientController:customerIndex' => '?',
            'App\\Controller\\ChicksRecipientController:delete' => '?',
            'App\\Controller\\ChicksRecipientController:edit' => '?',
            'App\\Controller\\ChicksRecipientController:index' => '?',
            'App\\Controller\\ChicksRecipientController:show' => '?',
            'App\\Controller\\ContactInfoController:delete' => '?',
            'App\\Controller\\ContactInfoController:edit' => '?',
            'App\\Controller\\ContactInfoController:index' => '?',
            'App\\Controller\\ContactInfoController:show' => '?',
            'App\\Controller\\CustomerController:delete' => '?',
            'App\\Controller\\CustomerController:edit' => '?',
            'App\\Controller\\CustomerController:index' => '?',
            'App\\Controller\\CustomerController:show' => '?',
            'App\\Controller\\DefaultController:incubators' => '?',
            'App\\Controller\\DefaultController:index' => '?',
            'App\\Controller\\DefaultController:indexPdf' => '?',
            'App\\Controller\\DeliveryController:addPartIndex' => '?',
            'App\\Controller\\DeliveryController:allDelivery' => '?',
            'App\\Controller\\DeliveryController:delete' => '?',
            'App\\Controller\\DeliveryController:edit' => '?',
            'App\\Controller\\DeliveryController:index' => '?',
            'App\\Controller\\DeliveryController:new' => '?',
            'App\\Controller\\DeliveryController:show' => '?',
            'App\\Controller\\DriverController:delete' => '?',
            'App\\Controller\\DriverController:edit' => '?',
            'App\\Controller\\DriverController:index' => '?',
            'App\\Controller\\DriverController:show' => '?',
            'App\\Controller\\HatchersController:delete' => '?',
            'App\\Controller\\HatchersController:edit' => '?',
            'App\\Controller\\HatchersController:getChickTemperatureInHatcher' => '?',
            'App\\Controller\\HatchersController:index' => '?',
            'App\\Controller\\HatchersController:show' => '?',
            'App\\Controller\\HerdsController:active' => '?',
            'App\\Controller\\HerdsController:breeder' => '?',
            'App\\Controller\\HerdsController:delete' => '?',
            'App\\Controller\\HerdsController:edit' => '?',
            'App\\Controller\\HerdsController:index' => '?',
            'App\\Controller\\HerdsController:show' => '?',
            'App\\Controller\\InputDeliveryController:checkStockEggs' => '?',
            'App\\Controller\\InputDeliveryController:delete' => '?',
            'App\\Controller\\InputDeliveryController:edit' => '?',
            'App\\Controller\\InputDeliveryController:herdDeliveryOnStock' => '?',
            'App\\Controller\\InputDeliveryController:index' => '?',
            'App\\Controller\\InputDeliveryController:show' => '?',
            'App\\Controller\\InputsController:delete' => '?',
            'App\\Controller\\InputsController:edit' => '?',
            'App\\Controller\\InputsController:index' => '?',
            'App\\Controller\\InputsController:show' => '?',
            'App\\Controller\\InputsFarmController:delete' => '?',
            'App\\Controller\\InputsFarmController:deletePlan' => '?',
            'App\\Controller\\InputsFarmController:edit' => '?',
            'App\\Controller\\InputsFarmController:show' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController:delete' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController:edit' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController:index' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController:inputsShow' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController:list' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController:new' => '?',
            'App\\Controller\\InputsFarmDeliveryPlanController:show' => '?',
            'App\\Controller\\LightingController:delete' => '?',
            'App\\Controller\\LightingController:index' => '?',
            'App\\Controller\\LightingController:new' => '?',
            'App\\Controller\\LightingController:showNoLighting' => '?',
            'App\\Controller\\PlanBreederController:index' => '?',
            'App\\Controller\\PlanBreederController:week' => '?',
            'App\\Controller\\PlanController:eggsInStock' => '?',
            'App\\Controller\\PlanController:herdDeliveryIndex' => '?',
            'App\\Controller\\PlanController:herdDeliveryPdf' => '?',
            'App\\Controller\\PlanController:planEggs' => '?',
            'App\\Controller\\PlanDeliveryChickController:delete' => '?',
            'App\\Controller\\PlanDeliveryChickController:edit' => '?',
            'App\\Controller\\PlanDeliveryChickController:index' => '?',
            'App\\Controller\\PlanDeliveryChickController:show' => '?',
            'App\\Controller\\PlanDeliveryChickController:weekCustomer' => '?',
            'App\\Controller\\PlanDeliveryEggController:delete' => '?',
            'App\\Controller\\PlanDeliveryEggController:edit' => '?',
            'App\\Controller\\PlanDeliveryEggController:herd' => '?',
            'App\\Controller\\PlanDeliveryEggController:index' => '?',
            'App\\Controller\\PlanDeliveryEggController:show' => '?',
            'App\\Controller\\PlanHatchingDateController:index' => '?',
            'App\\Controller\\PlanHatchingDateController:indexDay' => '?',
            'App\\Controller\\PlanHatchingDateController:week' => '?',
            'App\\Controller\\PlanIndicatorsController:delete' => '?',
            'App\\Controller\\PlanIndicatorsController:edit' => '?',
            'App\\Controller\\PlanIndicatorsController:index' => '?',
            'App\\Controller\\PlanIndicatorsController:show' => '?',
            'App\\Controller\\PlanInputController:delete' => '?',
            'App\\Controller\\PlanInputController:edit' => '?',
            'App\\Controller\\PlanInputController:index' => '?',
            'App\\Controller\\PlanInputController:show' => '?',
            'App\\Controller\\Production\\ProductionChickTemperatureController:chickTemperatureHatcher' => '?',
            'App\\Controller\\Production\\ProductionDeliveryController:deliveryHerd' => '?',
            'App\\Controller\\Production\\ProductionDeliveryController:deliveryNew' => '?',
            'App\\Controller\\Production\\ProductionDeliveryController:deliverySupplier' => '?',
            'App\\Controller\\Production\\ProductionInputsController:checkStockEggs' => '?',
            'App\\Controller\\Production\\ProductionInputsController:herdDeliveryOnStock' => '?',
            'App\\Controller\\Production\\ProductionInputsController:inputNew' => '?',
            'App\\Controller\\Production\\ProductionInputsController:inputsBreeder' => '?',
            'App\\Controller\\Production\\ProductionInputsController:inputsHerd' => '?',
            'App\\Controller\\Production\\ProductionLightingController:lightingHerd' => '?',
            'App\\Controller\\Production\\ProductionSelectionController:selectionsFarm' => '?',
            'App\\Controller\\Production\\ProductionSelectionController:selectionsHerd' => '?',
            'App\\Controller\\Production\\ProductionTransferController:transferFarm' => '?',
            'App\\Controller\\Production\\ProductionTransferController:transferHerd' => '?',
            'App\\Controller\\RegistrationController:register' => '?',
            'App\\Controller\\ResetPasswordController:request' => '?',
            'App\\Controller\\ResetPasswordController:reset' => '?',
            'App\\Controller\\SecurityController:login' => '?',
            'App\\Controller\\SelectionsController:delete' => '?',
            'App\\Controller\\SelectionsController:edit' => '?',
            'App\\Controller\\SelectionsController:index' => '?',
            'App\\Controller\\SelectionsController:new' => '?',
            'App\\Controller\\SelectionsController:show' => '?',
            'App\\Controller\\SelectionsController:showNoSelection' => '?',
            'App\\Controller\\SellingEggController:delete' => '?',
            'App\\Controller\\SellingEggController:edit' => '?',
            'App\\Controller\\SellingEggController:index' => '?',
            'App\\Controller\\SellingEggController:show' => '?',
            'App\\Controller\\SettersController:delete' => '?',
            'App\\Controller\\SettersController:edit' => '?',
            'App\\Controller\\SettersController:index' => '?',
            'App\\Controller\\SettersController:show' => '?',
            'App\\Controller\\SupplierController:delete' => '?',
            'App\\Controller\\SupplierController:edit' => '?',
            'App\\Controller\\SupplierController:index' => '?',
            'App\\Controller\\SupplierController:show' => '?',
            'App\\Controller\\TransfersController:delete' => '?',
            'App\\Controller\\TransfersController:edit' => '?',
            'App\\Controller\\TransfersController:index' => '?',
            'App\\Controller\\TransfersController:new' => '?',
            'App\\Controller\\TransfersController:show' => '?',
            'App\\Controller\\TransfersController:showNoTransfer' => '?',
            'App\\Controller\\TransportListController:delete' => '?',
            'App\\Controller\\TransportListController:edit' => '?',
            'App\\Controller\\TransportListController:index' => '?',
            'App\\Controller\\TransportListController:show' => '?',
            'App\\Controller\\UserController:delete' => '?',
            'App\\Controller\\UserController:edit' => '?',
            'App\\Controller\\UserController:index' => '?',
            'App\\Controller\\UserController:show' => '?',
            'App\\Controller\\VaccinationController:delete' => '?',
            'App\\Controller\\VaccinationController:edit' => '?',
            'App\\Controller\\VaccinationController:index' => '?',
            'App\\Controller\\VaccinationController:show' => '?',
            'App\\Security\\AccessDeniedHandler:handle' => '?',
            'DH\\AuditorBundle\\Controller\\ViewerController:listAuditsAction' => '?',
            'DH\\AuditorBundle\\Controller\\ViewerController:showEntityHistoryAction' => '?',
            'DH\\AuditorBundle\\Controller\\ViewerController:showTransactionAction' => '?',
        ]));
    }

    /*
     * Gets the private 'cache.annotations' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getCache_AnnotationsService()
    {
        return $this->privates['cache.annotations'] = \Symfony\Component\Cache\Adapter\AbstractAdapter::createSystemCache('ih8WKsSna-', 0, $this->getParameter('container.build_id'), ($this->targetDir.''.'/pools'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the private 'cache.property_access' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getCache_PropertyAccessService()
    {
        return $this->privates['cache.property_access'] = \Symfony\Component\PropertyAccess\PropertyAccessor::createCache('l7ssHqQJKj', 0, $this->getParameter('container.build_id'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the private 'cache.property_info' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getCache_PropertyInfoService()
    {
        return $this->privates['cache.property_info'] = \Symfony\Component\Cache\Adapter\AbstractAdapter::createSystemCache('4U+AEK8gKu', 0, $this->getParameter('container.build_id'), ($this->targetDir.''.'/pools'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the private 'cache.security_expression_language' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getCache_SecurityExpressionLanguageService()
    {
        return $this->privates['cache.security_expression_language'] = \Symfony\Component\Cache\Adapter\AbstractAdapter::createSystemCache('oc+FDZUdix', 0, $this->getParameter('container.build_id'), ($this->targetDir.''.'/pools'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the private 'cache.serializer' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getCache_SerializerService()
    {
        return $this->privates['cache.serializer'] = \Symfony\Component\Cache\Adapter\AbstractAdapter::createSystemCache('OUHq85VVHT', 0, $this->getParameter('container.build_id'), ($this->targetDir.''.'/pools'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the private 'cache.validator' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getCache_ValidatorService()
    {
        return $this->privates['cache.validator'] = \Symfony\Component\Cache\Adapter\AbstractAdapter::createSystemCache('SURg1e+zRm', 0, $this->getParameter('container.build_id'), ($this->targetDir.''.'/pools'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the private 'console.command.about' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\AboutCommand
     */
    protected function getConsole_Command_AboutService()
    {
        $this->privates['console.command.about'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\AboutCommand();

        $instance->setName('about');

        return $instance;
    }

    /*
     * Gets the private 'console.command.assets_install' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\AssetsInstallCommand
     */
    protected function getConsole_Command_AssetsInstallService()
    {
        $this->privates['console.command.assets_install'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\AssetsInstallCommand(($this->services['filesystem'] ?? ($this->services['filesystem'] = new \Symfony\Component\Filesystem\Filesystem())), \dirname(__DIR__, 4));

        $instance->setName('assets:install');

        return $instance;
    }

    /*
     * Gets the private 'console.command.cache_clear' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\CacheClearCommand
     */
    protected function getConsole_Command_CacheClearService()
    {
        $this->privates['console.command.cache_clear'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\CacheClearCommand(($this->services['cache_clearer'] ?? $this->getCacheClearerService()), ($this->services['filesystem'] ?? ($this->services['filesystem'] = new \Symfony\Component\Filesystem\Filesystem())));

        $instance->setName('cache:clear');

        return $instance;
    }

    /*
     * Gets the private 'console.command.cache_pool_clear' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\CachePoolClearCommand
     */
    protected function getConsole_Command_CachePoolClearService()
    {
        $this->privates['console.command.cache_pool_clear'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\CachePoolClearCommand(($this->services['cache.global_clearer'] ?? $this->getCache_GlobalClearerService()));

        $instance->setName('cache:pool:clear');

        return $instance;
    }

    /*
     * Gets the private 'console.command.cache_pool_delete' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\CachePoolDeleteCommand
     */
    protected function getConsole_Command_CachePoolDeleteService()
    {
        $this->privates['console.command.cache_pool_delete'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\CachePoolDeleteCommand(($this->services['cache.global_clearer'] ?? $this->getCache_GlobalClearerService()));

        $instance->setName('cache:pool:delete');

        return $instance;
    }

    /*
     * Gets the private 'console.command.cache_pool_list' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\CachePoolListCommand
     */
    protected function getConsole_Command_CachePoolListService()
    {
        $this->privates['console.command.cache_pool_list'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\CachePoolListCommand([0 => 'cache.app', 1 => 'cache.system', 2 => 'cache.validator', 3 => 'cache.serializer', 4 => 'cache.annotations', 5 => 'cache.property_info', 6 => 'doctrine.result_cache_pool', 7 => 'doctrine.system_cache_pool', 8 => 'cache.property_access', 9 => 'cache.security_expression_language']);

        $instance->setName('cache:pool:list');

        return $instance;
    }

    /*
     * Gets the private 'console.command.cache_pool_prune' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\CachePoolPruneCommand
     */
    protected function getConsole_Command_CachePoolPruneService()
    {
        $this->privates['console.command.cache_pool_prune'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\CachePoolPruneCommand(new RewindableGenerator(function () {
            yield 'cache.app' => ($this->services['cache.app'] ?? $this->getCache_AppService());
            yield 'doctrine.result_cache_pool' => ($this->privates['doctrine.result_cache_pool'] ?? $this->getDoctrine_ResultCachePoolService());
        }, 2));

        $instance->setName('cache:pool:prune');

        return $instance;
    }

    /*
     * Gets the private 'console.command.cache_warmup' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\CacheWarmupCommand
     */
    protected function getConsole_Command_CacheWarmupService()
    {
        $this->privates['console.command.cache_warmup'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\CacheWarmupCommand(($this->services['cache_warmer'] ?? $this->getCacheWarmerService()));

        $instance->setName('cache:warmup');

        return $instance;
    }

    /*
     * Gets the private 'console.command.config_debug' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\ConfigDebugCommand
     */
    protected function getConsole_Command_ConfigDebugService()
    {
        $this->privates['console.command.config_debug'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\ConfigDebugCommand();

        $instance->setName('debug:config');

        return $instance;
    }

    /*
     * Gets the private 'console.command.config_dump_reference' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\ConfigDumpReferenceCommand
     */
    protected function getConsole_Command_ConfigDumpReferenceService()
    {
        $this->privates['console.command.config_dump_reference'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\ConfigDumpReferenceCommand();

        $instance->setName('config:dump-reference');

        return $instance;
    }

    /*
     * Gets the private 'console.command.container_debug' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\ContainerDebugCommand
     */
    protected function getConsole_Command_ContainerDebugService()
    {
        $this->privates['console.command.container_debug'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\ContainerDebugCommand();

        $instance->setName('debug:container');

        return $instance;
    }

    /*
     * Gets the private 'console.command.container_lint' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\ContainerLintCommand
     */
    protected function getConsole_Command_ContainerLintService()
    {
        $this->privates['console.command.container_lint'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\ContainerLintCommand();

        $instance->setName('lint:container');

        return $instance;
    }

    /*
     * Gets the private 'console.command.debug_autowiring' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\DebugAutowiringCommand
     */
    protected function getConsole_Command_DebugAutowiringService()
    {
        $this->privates['console.command.debug_autowiring'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\DebugAutowiringCommand(NULL, ($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))));

        $instance->setName('debug:autowiring');

        return $instance;
    }

    /*
     * Gets the private 'console.command.event_dispatcher_debug' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\EventDispatcherDebugCommand
     */
    protected function getConsole_Command_EventDispatcherDebugService()
    {
        $this->privates['console.command.event_dispatcher_debug'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\EventDispatcherDebugCommand(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));

        $instance->setName('debug:event-dispatcher');

        return $instance;
    }

    /*
     * Gets the private 'console.command.form_debug' shared service.
     *
     * @return \Symfony\Component\Form\Command\DebugCommand
     */
    protected function getConsole_Command_FormDebugService()
    {
        $this->privates['console.command.form_debug'] = $instance = new \Symfony\Component\Form\Command\DebugCommand(($this->privates['form.registry'] ?? $this->getForm_RegistryService()), [0 => 'Symfony\\Component\\Form\\Extension\\Core\\Type', 1 => 'App\\Form', 2 => 'App\\Form\\Production', 3 => 'Symfony\\Bridge\\Doctrine\\Form\\Type'], [0 => 'App\\Form\\BetweenDateType', 1 => 'App\\Form\\BreedStandardType', 2 => 'App\\Form\\BreedType', 3 => 'App\\Form\\CarType', 4 => 'App\\Form\\ChangePasswordFormType', 5 => 'App\\Form\\ChickIntegrationType', 6 => 'App\\Form\\ChickTemperatureType', 7 => 'App\\Form\\ChicksRecipientType', 8 => 'App\\Form\\ContactInfoType', 9 => 'App\\Form\\CustomerType', 10 => 'App\\Form\\DeliveryPartIndexType', 11 => 'App\\Form\\DeliveryProductionType', 12 => 'App\\Form\\DeliveryType', 13 => 'App\\Form\\DriverType', 14 => 'App\\Form\\HatchersType', 15 => 'App\\Form\\HerdActiveType', 16 => 'App\\Form\\HerdsType', 17 => 'App\\Form\\InputDeliveryProductionType', 18 => 'App\\Form\\InputDeliveryType', 19 => 'App\\Form\\InputsDetailsType', 20 => 'App\\Form\\InputsFarmType', 21 => 'App\\Form\\InputsType', 22 => 'App\\Form\\LightingCorrectType', 23 => 'App\\Form\\LightingType', 24 => 'App\\Form\\PlanDeliveryChickType', 25 => 'App\\Form\\PlanDeliveryEggForHerdType', 26 => 'App\\Form\\PlanDeliveryEggType', 27 => 'App\\Form\\PlanIndicatorsType', 28 => 'App\\Form\\PlanInputType', 29 => 'App\\Form\\Production\\TransfersProductionType', 30 => 'App\\Form\\ResetPasswordRequestFormType', 31 => 'App\\Form\\SelectionsType', 32 => 'App\\Form\\SellingEggType', 33 => 'App\\Form\\SettersType', 34 => 'App\\Form\\SupplierType', 35 => 'App\\Form\\TransfersType', 36 => 'App\\Form\\TransportListType', 37 => 'App\\Form\\User1Type', 38 => 'App\\Form\\UserType', 39 => 'App\\Form\\VaccinationType', 40 => 'Symfony\\Component\\Form\\Extension\\Core\\Type\\FormType', 41 => 'Symfony\\Component\\Form\\Extension\\Core\\Type\\ChoiceType', 42 => 'Symfony\\Component\\Form\\Extension\\Core\\Type\\FileType', 43 => 'Symfony\\Bridge\\Doctrine\\Form\\Type\\EntityType'], [0 => 'Symfony\\Component\\Form\\Extension\\Core\\Type\\TransformationFailureExtension', 1 => 'Symfony\\Component\\Form\\Extension\\HttpFoundation\\Type\\FormTypeHttpFoundationExtension', 2 => 'Symfony\\Component\\Form\\Extension\\Validator\\Type\\FormTypeValidatorExtension', 3 => 'Symfony\\Component\\Form\\Extension\\Validator\\Type\\RepeatedTypeValidatorExtension', 4 => 'Symfony\\Component\\Form\\Extension\\Validator\\Type\\SubmitTypeValidatorExtension', 5 => 'Symfony\\Component\\Form\\Extension\\Validator\\Type\\UploadValidatorExtension', 6 => 'Symfony\\Component\\Form\\Extension\\Csrf\\Type\\FormTypeCsrfExtension'], [0 => 'Symfony\\Component\\Form\\Extension\\Validator\\ValidatorTypeGuesser', 1 => 'Symfony\\Bridge\\Doctrine\\Form\\DoctrineOrmTypeGuesser'], ($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))));

        $instance->setName('debug:form');

        return $instance;
    }

    /*
     * Gets the private 'console.command.router_debug' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\RouterDebugCommand
     */
    protected function getConsole_Command_RouterDebugService()
    {
        $this->privates['console.command.router_debug'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\RouterDebugCommand(($this->services['router'] ?? $this->getRouterService()), ($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))));

        $instance->setName('debug:router');

        return $instance;
    }

    /*
     * Gets the private 'console.command.router_match' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\RouterMatchCommand
     */
    protected function getConsole_Command_RouterMatchService()
    {
        $this->privates['console.command.router_match'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\RouterMatchCommand(($this->services['router'] ?? $this->getRouterService()));

        $instance->setName('router:match');

        return $instance;
    }

    /*
     * Gets the private 'console.command.secrets_decrypt_to_local' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\SecretsDecryptToLocalCommand
     */
    protected function getConsole_Command_SecretsDecryptToLocalService()
    {
        $this->privates['console.command.secrets_decrypt_to_local'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\SecretsDecryptToLocalCommand(($this->privates['secrets.vault'] ?? ($this->privates['secrets.vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\SodiumVault((\dirname(__DIR__, 4).'/config/secrets/prod'), $this->getEnv('base64:default::SYMFONY_DECRYPTION_SECRET')))), ($this->privates['secrets.local_vault'] ?? ($this->privates['secrets.local_vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\DotenvVault((\dirname(__DIR__, 4).'/.env.prod.local')))));

        $instance->setName('secrets:decrypt-to-local');

        return $instance;
    }

    /*
     * Gets the private 'console.command.secrets_encrypt_from_local' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\SecretsEncryptFromLocalCommand
     */
    protected function getConsole_Command_SecretsEncryptFromLocalService()
    {
        $this->privates['console.command.secrets_encrypt_from_local'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\SecretsEncryptFromLocalCommand(($this->privates['secrets.vault'] ?? ($this->privates['secrets.vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\SodiumVault((\dirname(__DIR__, 4).'/config/secrets/prod'), $this->getEnv('base64:default::SYMFONY_DECRYPTION_SECRET')))), ($this->privates['secrets.local_vault'] ?? ($this->privates['secrets.local_vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\DotenvVault((\dirname(__DIR__, 4).'/.env.prod.local')))));

        $instance->setName('secrets:encrypt-from-local');

        return $instance;
    }

    /*
     * Gets the private 'console.command.secrets_generate_key' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\SecretsGenerateKeysCommand
     */
    protected function getConsole_Command_SecretsGenerateKeyService()
    {
        $this->privates['console.command.secrets_generate_key'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\SecretsGenerateKeysCommand(($this->privates['secrets.vault'] ?? ($this->privates['secrets.vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\SodiumVault((\dirname(__DIR__, 4).'/config/secrets/prod'), $this->getEnv('base64:default::SYMFONY_DECRYPTION_SECRET')))), ($this->privates['secrets.local_vault'] ?? ($this->privates['secrets.local_vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\DotenvVault((\dirname(__DIR__, 4).'/.env.prod.local')))));

        $instance->setName('secrets:generate-keys');

        return $instance;
    }

    /*
     * Gets the private 'console.command.secrets_list' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\SecretsListCommand
     */
    protected function getConsole_Command_SecretsListService()
    {
        $this->privates['console.command.secrets_list'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\SecretsListCommand(($this->privates['secrets.vault'] ?? ($this->privates['secrets.vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\SodiumVault((\dirname(__DIR__, 4).'/config/secrets/prod'), $this->getEnv('base64:default::SYMFONY_DECRYPTION_SECRET')))), ($this->privates['secrets.local_vault'] ?? ($this->privates['secrets.local_vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\DotenvVault((\dirname(__DIR__, 4).'/.env.prod.local')))));

        $instance->setName('secrets:list');

        return $instance;
    }

    /*
     * Gets the private 'console.command.secrets_remove' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\SecretsRemoveCommand
     */
    protected function getConsole_Command_SecretsRemoveService()
    {
        $this->privates['console.command.secrets_remove'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\SecretsRemoveCommand(($this->privates['secrets.vault'] ?? ($this->privates['secrets.vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\SodiumVault((\dirname(__DIR__, 4).'/config/secrets/prod'), $this->getEnv('base64:default::SYMFONY_DECRYPTION_SECRET')))), ($this->privates['secrets.local_vault'] ?? ($this->privates['secrets.local_vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\DotenvVault((\dirname(__DIR__, 4).'/.env.prod.local')))));

        $instance->setName('secrets:remove');

        return $instance;
    }

    /*
     * Gets the private 'console.command.secrets_set' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\SecretsSetCommand
     */
    protected function getConsole_Command_SecretsSetService()
    {
        $this->privates['console.command.secrets_set'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\SecretsSetCommand(($this->privates['secrets.vault'] ?? ($this->privates['secrets.vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\SodiumVault((\dirname(__DIR__, 4).'/config/secrets/prod'), $this->getEnv('base64:default::SYMFONY_DECRYPTION_SECRET')))), ($this->privates['secrets.local_vault'] ?? ($this->privates['secrets.local_vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\DotenvVault((\dirname(__DIR__, 4).'/.env.prod.local')))));

        $instance->setName('secrets:set');

        return $instance;
    }

    /*
     * Gets the private 'console.command.translation_debug' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\TranslationDebugCommand
     */
    protected function getConsole_Command_TranslationDebugService()
    {
        $this->privates['console.command.translation_debug'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\TranslationDebugCommand(($this->services['translator'] ?? $this->getTranslatorService()), ($this->privates['translation.reader'] ?? $this->getTranslation_ReaderService()), ($this->privates['translation.extractor'] ?? $this->getTranslation_ExtractorService()), (\dirname(__DIR__, 4).'/translations'), (\dirname(__DIR__, 4).'/templates'), [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations')], [0 => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Email'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Form'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/http-kernel/EventListener/LocaleAwareListener.php'), 3 => (\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle/Command/TranslationDebugCommand.php'), 4 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Core/Type/ChoiceType.php'), 5 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Core/Type/FileType.php'), 6 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Core/Type/TransformationFailureExtension.php'), 7 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Validator/Type/UploadValidatorExtension.php'), 8 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Csrf/Type/FormTypeCsrfExtension.php'), 9 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Util/LegacyTranslatorProxy.php'), 10 => (\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle/CacheWarmer/TranslationsCacheWarmer.php'), 11 => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Extension/TranslationExtension.php'), 12 => (\dirname(__DIR__, 4).'/src/Controller/PlanController.php')]);

        $instance->setName('debug:translation');

        return $instance;
    }

    /*
     * Gets the private 'console.command.translation_update' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\TranslationUpdateCommand
     */
    protected function getConsole_Command_TranslationUpdateService()
    {
        $a = new \Symfony\Component\Translation\Writer\TranslationWriter();
        $a->addDumper('php', new \Symfony\Component\Translation\Dumper\PhpFileDumper());
        $a->addDumper('xlf', new \Symfony\Component\Translation\Dumper\XliffFileDumper());
        $a->addDumper('po', new \Symfony\Component\Translation\Dumper\PoFileDumper());
        $a->addDumper('mo', new \Symfony\Component\Translation\Dumper\MoFileDumper());
        $a->addDumper('yml', new \Symfony\Component\Translation\Dumper\YamlFileDumper());
        $a->addDumper('yaml', new \Symfony\Component\Translation\Dumper\YamlFileDumper('yaml'));
        $a->addDumper('ts', new \Symfony\Component\Translation\Dumper\QtFileDumper());
        $a->addDumper('csv', new \Symfony\Component\Translation\Dumper\CsvFileDumper());
        $a->addDumper('ini', new \Symfony\Component\Translation\Dumper\IniFileDumper());
        $a->addDumper('json', new \Symfony\Component\Translation\Dumper\JsonFileDumper());
        $a->addDumper('res', new \Symfony\Component\Translation\Dumper\IcuResFileDumper());

        $this->privates['console.command.translation_update'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\TranslationUpdateCommand($a, ($this->privates['translation.reader'] ?? $this->getTranslation_ReaderService()), ($this->privates['translation.extractor'] ?? $this->getTranslation_ExtractorService()), 'pl', (\dirname(__DIR__, 4).'/translations'), (\dirname(__DIR__, 4).'/templates'), [0 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Resources/translations'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/translations'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/security-core/Resources/translations')], [0 => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Email'), 1 => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Form'), 2 => (\dirname(__DIR__, 4).'/vendor/symfony/http-kernel/EventListener/LocaleAwareListener.php'), 3 => (\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle/Command/TranslationDebugCommand.php'), 4 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Core/Type/ChoiceType.php'), 5 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Core/Type/FileType.php'), 6 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Core/Type/TransformationFailureExtension.php'), 7 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Validator/Type/UploadValidatorExtension.php'), 8 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Extension/Csrf/Type/FormTypeCsrfExtension.php'), 9 => (\dirname(__DIR__, 4).'/vendor/symfony/validator/Util/LegacyTranslatorProxy.php'), 10 => (\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle/CacheWarmer/TranslationsCacheWarmer.php'), 11 => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Extension/TranslationExtension.php'), 12 => (\dirname(__DIR__, 4).'/src/Controller/PlanController.php')]);

        $instance->setName('translation:update');

        return $instance;
    }

    /*
     * Gets the private 'console.command.xliff_lint' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\XliffLintCommand
     */
    protected function getConsole_Command_XliffLintService()
    {
        $this->privates['console.command.xliff_lint'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\XliffLintCommand();

        $instance->setName('lint:xliff');

        return $instance;
    }

    /*
     * Gets the private 'console.command.yaml_lint' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Command\YamlLintCommand
     */
    protected function getConsole_Command_YamlLintService()
    {
        $this->privates['console.command.yaml_lint'] = $instance = new \Symfony\Bundle\FrameworkBundle\Command\YamlLintCommand();

        $instance->setName('lint:yaml');

        return $instance;
    }

    /*
     * Gets the private 'console.error_listener' shared service.
     *
     * @return \Symfony\Component\Console\EventListener\ErrorListener
     */
    protected function getConsole_ErrorListenerService()
    {
        $a = new \Symfony\Bridge\Monolog\Logger('console');
        $a->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $a->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $this->privates['console.error_listener'] = new \Symfony\Component\Console\EventListener\ErrorListener($a);
    }

    /*
     * Gets the private 'container.env_var_processor' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\EnvVarProcessor
     */
    protected function getContainer_EnvVarProcessorService()
    {
        return $this->privates['container.env_var_processor'] = new \Symfony\Component\DependencyInjection\EnvVarProcessor($this, new RewindableGenerator(function () {
            yield 0 => ($this->privates['secrets.vault'] ?? ($this->privates['secrets.vault'] = new \Symfony\Bundle\FrameworkBundle\Secrets\SodiumVault((\dirname(__DIR__, 4).'/config/secrets/prod'), $this->getEnv('base64:default::SYMFONY_DECRYPTION_SECRET'))));
        }, 1));
    }

    /*
     * Gets the private 'debug.debug_handlers_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\DebugHandlersListener
     */
    protected function getDebug_DebugHandlersListenerService()
    {
        $a = new \Symfony\Bridge\Monolog\Logger('php');
        $a->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $a->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $this->privates['debug.debug_handlers_listener'] = new \Symfony\Component\HttpKernel\EventListener\DebugHandlersListener(NULL, $a, NULL, 0, false, ($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))), false);
    }

    /*
     * Gets the private 'doctrine.cache_clear_metadata_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ClearMetadataCacheDoctrineCommand
     */
    protected function getDoctrine_CacheClearMetadataCommandService()
    {
        $this->privates['doctrine.cache_clear_metadata_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ClearMetadataCacheDoctrineCommand();

        $instance->setName('doctrine:cache:clear-metadata');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.cache_clear_query_cache_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ClearQueryCacheDoctrineCommand
     */
    protected function getDoctrine_CacheClearQueryCacheCommandService()
    {
        $this->privates['doctrine.cache_clear_query_cache_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ClearQueryCacheDoctrineCommand();

        $instance->setName('doctrine:cache:clear-query');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.cache_clear_result_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ClearResultCacheDoctrineCommand
     */
    protected function getDoctrine_CacheClearResultCommandService()
    {
        $this->privates['doctrine.cache_clear_result_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ClearResultCacheDoctrineCommand();

        $instance->setName('doctrine:cache:clear-result');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.cache_collection_region_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\CollectionRegionDoctrineCommand
     */
    protected function getDoctrine_CacheCollectionRegionCommandService()
    {
        $this->privates['doctrine.cache_collection_region_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\CollectionRegionDoctrineCommand();

        $instance->setName('doctrine:cache:clear-collection-region');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.clear_entity_region_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\EntityRegionCacheDoctrineCommand
     */
    protected function getDoctrine_ClearEntityRegionCommandService()
    {
        $this->privates['doctrine.clear_entity_region_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\EntityRegionCacheDoctrineCommand();

        $instance->setName('doctrine:cache:clear-entity-region');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.clear_query_region_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\QueryRegionCacheDoctrineCommand
     */
    protected function getDoctrine_ClearQueryRegionCommandService()
    {
        $this->privates['doctrine.clear_query_region_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\QueryRegionCacheDoctrineCommand();

        $instance->setName('doctrine:cache:clear-query-region');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.database_create_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\CreateDatabaseDoctrineCommand
     */
    protected function getDoctrine_DatabaseCreateCommandService()
    {
        $this->privates['doctrine.database_create_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\CreateDatabaseDoctrineCommand(($this->services['doctrine'] ?? $this->getDoctrineService()));

        $instance->setName('doctrine:database:create');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.database_drop_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\DropDatabaseDoctrineCommand
     */
    protected function getDoctrine_DatabaseDropCommandService()
    {
        $this->privates['doctrine.database_drop_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\DropDatabaseDoctrineCommand(($this->services['doctrine'] ?? $this->getDoctrineService()));

        $instance->setName('doctrine:database:drop');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.database_import_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ImportDoctrineCommand
     */
    protected function getDoctrine_DatabaseImportCommandService()
    {
        $this->privates['doctrine.database_import_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ImportDoctrineCommand();

        $instance->setName('doctrine:database:import');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.ensure_production_settings_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\EnsureProductionSettingsDoctrineCommand
     */
    protected function getDoctrine_EnsureProductionSettingsCommandService()
    {
        $this->privates['doctrine.ensure_production_settings_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\EnsureProductionSettingsDoctrineCommand();

        $instance->setName('doctrine:ensure-production-settings');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.mapping_convert_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ConvertMappingDoctrineCommand
     */
    protected function getDoctrine_MappingConvertCommandService()
    {
        $this->privates['doctrine.mapping_convert_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ConvertMappingDoctrineCommand();

        $instance->setName('doctrine:mapping:convert');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.mapping_import_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\ImportMappingDoctrineCommand
     */
    protected function getDoctrine_MappingImportCommandService()
    {
        $this->privates['doctrine.mapping_import_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\ImportMappingDoctrineCommand(($this->services['doctrine'] ?? $this->getDoctrineService()), $this->parameters['kernel.bundles']);

        $instance->setName('doctrine:mapping:import');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.mapping_info_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\InfoDoctrineCommand
     */
    protected function getDoctrine_MappingInfoCommandService()
    {
        $this->privates['doctrine.mapping_info_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\InfoDoctrineCommand();

        $instance->setName('doctrine:mapping:info');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.migrations.container_aware_migrations_factory' shared service.
     *
     * @return \Doctrine\Bundle\MigrationsBundle\MigrationsFactory\ContainerAwareMigrationFactory
     */
    protected function getDoctrine_Migrations_ContainerAwareMigrationsFactoryService()
    {
        return $this->privates['doctrine.migrations.container_aware_migrations_factory'] = new \Doctrine\Bundle\MigrationsBundle\MigrationsFactory\ContainerAwareMigrationFactory(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService())->getMigrationFactory(), $this);
    }

    /*
     * Gets the private 'doctrine.migrations.dependency_factory' shared service.
     *
     * @return \Doctrine\Migrations\DependencyFactory
     */
    protected function getDoctrine_Migrations_DependencyFactoryService()
    {
        $a = new \Doctrine\Migrations\Configuration\Configuration();
        $a->addMigrationsDirectory('DoctrineMigrations', (\dirname(__DIR__, 4).'/migrations'));
        $a->setAllOrNothing(false);
        $a->setCheckDatabasePlatform(true);
        $a->setMetadataStorageConfiguration(new \Doctrine\Migrations\Metadata\Storage\TableMetadataStorageConfiguration());

        $this->privates['doctrine.migrations.dependency_factory'] = $instance = \Doctrine\Migrations\DependencyFactory::fromEntityManager(new \Doctrine\Migrations\Configuration\Migration\ExistingConfiguration($a), \Doctrine\Migrations\Configuration\EntityManager\ManagerRegistryEntityManager::withSimpleDefault(($this->services['doctrine'] ?? $this->getDoctrineService())), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));

        $instance->setDefinition('Doctrine\\Migrations\\Version\\MigrationFactory', function () {
            return ($this->privates['doctrine.migrations.container_aware_migrations_factory'] ?? $this->getDoctrine_Migrations_ContainerAwareMigrationsFactoryService());
        });

        return $instance;
    }

    /*
     * Gets the private 'doctrine.orm.default_entity_manager.property_info_extractor' shared service.
     *
     * @return \Symfony\Bridge\Doctrine\PropertyInfo\DoctrineExtractor
     */
    protected function getDoctrine_Orm_DefaultEntityManager_PropertyInfoExtractorService()
    {
        return $this->privates['doctrine.orm.default_entity_manager.property_info_extractor'] = new \Symfony\Bridge\Doctrine\PropertyInfo\DoctrineExtractor(($this->services['doctrine.orm.default_entity_manager'] ?? $this->getDoctrine_Orm_DefaultEntityManagerService()));
    }

    /*
     * Gets the private 'doctrine.orm.default_listeners.attach_entity_listeners' shared service.
     *
     * @return \Doctrine\ORM\Tools\AttachEntityListenersListener
     */
    protected function getDoctrine_Orm_DefaultListeners_AttachEntityListenersService()
    {
        return $this->privates['doctrine.orm.default_listeners.attach_entity_listeners'] = new \Doctrine\ORM\Tools\AttachEntityListenersListener();
    }

    /*
     * Gets the private 'doctrine.orm.default_metadata_cache_warmer' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\CacheWarmer\DoctrineMetadataCacheWarmer
     */
    protected function getDoctrine_Orm_DefaultMetadataCacheWarmerService()
    {
        return $this->privates['doctrine.orm.default_metadata_cache_warmer'] = new \Doctrine\Bundle\DoctrineBundle\CacheWarmer\DoctrineMetadataCacheWarmer(($this->services['doctrine.orm.default_entity_manager'] ?? $this->getDoctrine_Orm_DefaultEntityManagerService()), ($this->targetDir.''.'/doctrine/orm/default_metadata.php'));
    }

    /*
     * Gets the private 'doctrine.orm.proxy_cache_warmer' shared service.
     *
     * @return \Symfony\Bridge\Doctrine\CacheWarmer\ProxyCacheWarmer
     */
    protected function getDoctrine_Orm_ProxyCacheWarmerService()
    {
        return $this->privates['doctrine.orm.proxy_cache_warmer'] = new \Symfony\Bridge\Doctrine\CacheWarmer\ProxyCacheWarmer(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'doctrine.orm.validator.unique' shared service.
     *
     * @return \Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntityValidator
     */
    protected function getDoctrine_Orm_Validator_UniqueService()
    {
        return $this->privates['doctrine.orm.validator.unique'] = new \Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntityValidator(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'doctrine.query_dql_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\RunDqlDoctrineCommand
     */
    protected function getDoctrine_QueryDqlCommandService()
    {
        $this->privates['doctrine.query_dql_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\RunDqlDoctrineCommand();

        $instance->setName('doctrine:query:dql');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.query_sql_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\RunSqlDoctrineCommand
     */
    protected function getDoctrine_QuerySqlCommandService()
    {
        $this->privates['doctrine.query_sql_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\RunSqlDoctrineCommand(($this->privates['Doctrine\\Bundle\\DoctrineBundle\\Dbal\\ManagerRegistryAwareConnectionProvider'] ?? $this->getManagerRegistryAwareConnectionProviderService()));

        $instance->setName('doctrine:query:sql');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.result_cache_pool' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\FilesystemAdapter
     */
    protected function getDoctrine_ResultCachePoolService()
    {
        $this->privates['doctrine.result_cache_pool'] = $instance = new \Symfony\Component\Cache\Adapter\FilesystemAdapter('x0tWPIQt7Q', 0, ($this->targetDir.''.'/pools'), ($this->privates['cache.default_marshaller'] ?? ($this->privates['cache.default_marshaller'] = new \Symfony\Component\Cache\Marshaller\DefaultMarshaller(NULL))));

        $instance->setLogger(($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));

        return $instance;
    }

    /*
     * Gets the private 'doctrine.schema_create_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\CreateSchemaDoctrineCommand
     */
    protected function getDoctrine_SchemaCreateCommandService()
    {
        $this->privates['doctrine.schema_create_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\CreateSchemaDoctrineCommand();

        $instance->setName('doctrine:schema:create');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.schema_drop_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\DropSchemaDoctrineCommand
     */
    protected function getDoctrine_SchemaDropCommandService()
    {
        $this->privates['doctrine.schema_drop_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\DropSchemaDoctrineCommand();

        $instance->setName('doctrine:schema:drop');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.schema_update_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\UpdateSchemaDoctrineCommand
     */
    protected function getDoctrine_SchemaUpdateCommandService()
    {
        $this->privates['doctrine.schema_update_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\UpdateSchemaDoctrineCommand();

        $instance->setName('doctrine:schema:update');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.schema_validate_command' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ValidateSchemaCommand
     */
    protected function getDoctrine_SchemaValidateCommandService()
    {
        $this->privates['doctrine.schema_validate_command'] = $instance = new \Doctrine\Bundle\DoctrineBundle\Command\Proxy\ValidateSchemaCommand();

        $instance->setName('doctrine:schema:validate');

        return $instance;
    }

    /*
     * Gets the private 'doctrine.system_cache_pool' shared service.
     *
     * @return \Symfony\Component\Cache\Adapter\AdapterInterface
     */
    protected function getDoctrine_SystemCachePoolService()
    {
        return $this->privates['doctrine.system_cache_pool'] = \Symfony\Component\Cache\Adapter\AbstractAdapter::createSystemCache('2QKw4nC5C9', 0, $this->getParameter('container.build_id'), ($this->targetDir.''.'/pools'), ($this->privates['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));
    }

    /*
     * Gets the private 'doctrine_migrations.current_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\CurrentCommand
     */
    protected function getDoctrineMigrations_CurrentCommandService()
    {
        $this->privates['doctrine_migrations.current_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\CurrentCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:current');

        $instance->setName('doctrine:migrations:current');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.diff_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\DiffCommand
     */
    protected function getDoctrineMigrations_DiffCommandService()
    {
        $this->privates['doctrine_migrations.diff_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\DiffCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:diff');

        $instance->setName('doctrine:migrations:diff');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.dump_schema_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\DumpSchemaCommand
     */
    protected function getDoctrineMigrations_DumpSchemaCommandService()
    {
        $this->privates['doctrine_migrations.dump_schema_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\DumpSchemaCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:dump-schema');

        $instance->setName('doctrine:migrations:dump-schema');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.execute_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\ExecuteCommand
     */
    protected function getDoctrineMigrations_ExecuteCommandService()
    {
        $this->privates['doctrine_migrations.execute_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\ExecuteCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:execute');

        $instance->setName('doctrine:migrations:execute');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.generate_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\GenerateCommand
     */
    protected function getDoctrineMigrations_GenerateCommandService()
    {
        $this->privates['doctrine_migrations.generate_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\GenerateCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:generate');

        $instance->setName('doctrine:migrations:generate');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.latest_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\LatestCommand
     */
    protected function getDoctrineMigrations_LatestCommandService()
    {
        $this->privates['doctrine_migrations.latest_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\LatestCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:latest');

        $instance->setName('doctrine:migrations:latest');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.migrate_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\MigrateCommand
     */
    protected function getDoctrineMigrations_MigrateCommandService()
    {
        $this->privates['doctrine_migrations.migrate_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\MigrateCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:migrate');

        $instance->setName('doctrine:migrations:migrate');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.rollup_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\RollupCommand
     */
    protected function getDoctrineMigrations_RollupCommandService()
    {
        $this->privates['doctrine_migrations.rollup_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\RollupCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:rollup');

        $instance->setName('doctrine:migrations:rollup');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.status_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\StatusCommand
     */
    protected function getDoctrineMigrations_StatusCommandService()
    {
        $this->privates['doctrine_migrations.status_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\StatusCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:status');

        $instance->setName('doctrine:migrations:status');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.sync_metadata_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\SyncMetadataCommand
     */
    protected function getDoctrineMigrations_SyncMetadataCommandService()
    {
        $this->privates['doctrine_migrations.sync_metadata_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\SyncMetadataCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:sync-metadata-storage');

        $instance->setName('doctrine:migrations:sync-metadata-storage');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.up_to_date_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\UpToDateCommand
     */
    protected function getDoctrineMigrations_UpToDateCommandService()
    {
        $this->privates['doctrine_migrations.up_to_date_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\UpToDateCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:up-to-date');

        $instance->setName('doctrine:migrations:up-to-date');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.version_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\VersionCommand
     */
    protected function getDoctrineMigrations_VersionCommandService()
    {
        $this->privates['doctrine_migrations.version_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\VersionCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:version');

        $instance->setName('doctrine:migrations:version');

        return $instance;
    }

    /*
     * Gets the private 'doctrine_migrations.versions_command' shared service.
     *
     * @return \Doctrine\Migrations\Tools\Console\Command\ListCommand
     */
    protected function getDoctrineMigrations_VersionsCommandService()
    {
        $this->privates['doctrine_migrations.versions_command'] = $instance = new \Doctrine\Migrations\Tools\Console\Command\ListCommand(($this->privates['doctrine.migrations.dependency_factory'] ?? $this->getDoctrine_Migrations_DependencyFactoryService()), 'doctrine:migrations:versions');

        $instance->setName('doctrine:migrations:list');

        return $instance;
    }

    /*
     * Gets the private 'exception_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\ErrorListener
     */
    protected function getExceptionListenerService()
    {
        return $this->privates['exception_listener'] = new \Symfony\Component\HttpKernel\EventListener\ErrorListener('error_controller', ($this->privates['monolog.logger.request'] ?? $this->getMonolog_Logger_RequestService()), false);
    }

    /*
     * Gets the private 'form.choice_list_factory.cached' shared service.
     *
     * @return \Symfony\Component\Form\ChoiceList\Factory\CachingFactoryDecorator
     */
    protected function getForm_ChoiceListFactory_CachedService()
    {
        return $this->privates['form.choice_list_factory.cached'] = new \Symfony\Component\Form\ChoiceList\Factory\CachingFactoryDecorator(new \Symfony\Component\Form\ChoiceList\Factory\PropertyAccessDecorator(new \Symfony\Component\Form\ChoiceList\Factory\DefaultChoiceListFactory(), ($this->privates['property_accessor'] ?? $this->getPropertyAccessorService())));
    }

    /*
     * Gets the private 'form.registry' shared service.
     *
     * @return \Symfony\Component\Form\FormRegistry
     */
    protected function getForm_RegistryService()
    {
        return $this->privates['form.registry'] = new \Symfony\Component\Form\FormRegistry([0 => new \Symfony\Component\Form\Extension\DependencyInjection\DependencyInjectionExtension(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'App\\Form\\BetweenDateType' => ['privates', 'App\\Form\\BetweenDateType', 'getBetweenDateTypeService', false],
            'App\\Form\\BreedStandardType' => ['privates', 'App\\Form\\BreedStandardType', 'getBreedStandardTypeService', false],
            'App\\Form\\BreedType' => ['privates', 'App\\Form\\BreedType', 'getBreedTypeService', false],
            'App\\Form\\CarType' => ['privates', 'App\\Form\\CarType', 'getCarTypeService', false],
            'App\\Form\\ChangePasswordFormType' => ['privates', 'App\\Form\\ChangePasswordFormType', 'getChangePasswordFormTypeService', false],
            'App\\Form\\ChickIntegrationType' => ['privates', 'App\\Form\\ChickIntegrationType', 'getChickIntegrationTypeService', false],
            'App\\Form\\ChickTemperatureType' => ['privates', 'App\\Form\\ChickTemperatureType', 'getChickTemperatureTypeService', false],
            'App\\Form\\ChicksRecipientType' => ['privates', 'App\\Form\\ChicksRecipientType', 'getChicksRecipientTypeService', false],
            'App\\Form\\ContactInfoType' => ['privates', 'App\\Form\\ContactInfoType', 'getContactInfoTypeService', false],
            'App\\Form\\CustomerType' => ['privates', 'App\\Form\\CustomerType', 'getCustomerTypeService', false],
            'App\\Form\\DeliveryPartIndexType' => ['privates', 'App\\Form\\DeliveryPartIndexType', 'getDeliveryPartIndexTypeService', false],
            'App\\Form\\DeliveryProductionType' => ['privates', 'App\\Form\\DeliveryProductionType', 'getDeliveryProductionTypeService', false],
            'App\\Form\\DeliveryType' => ['privates', 'App\\Form\\DeliveryType', 'getDeliveryTypeService', false],
            'App\\Form\\DriverType' => ['privates', 'App\\Form\\DriverType', 'getDriverTypeService', false],
            'App\\Form\\HatchersType' => ['privates', 'App\\Form\\HatchersType', 'getHatchersTypeService', false],
            'App\\Form\\HerdActiveType' => ['privates', 'App\\Form\\HerdActiveType', 'getHerdActiveTypeService', false],
            'App\\Form\\HerdsType' => ['privates', 'App\\Form\\HerdsType', 'getHerdsTypeService', false],
            'App\\Form\\InputDeliveryProductionType' => ['privates', 'App\\Form\\InputDeliveryProductionType', 'getInputDeliveryProductionTypeService', false],
            'App\\Form\\InputDeliveryType' => ['privates', 'App\\Form\\InputDeliveryType', 'getInputDeliveryTypeService', false],
            'App\\Form\\InputsDetailsType' => ['privates', 'App\\Form\\InputsDetailsType', 'getInputsDetailsTypeService', false],
            'App\\Form\\InputsFarmType' => ['privates', 'App\\Form\\InputsFarmType', 'getInputsFarmTypeService', false],
            'App\\Form\\InputsType' => ['privates', 'App\\Form\\InputsType', 'getInputsTypeService', false],
            'App\\Form\\LightingCorrectType' => ['privates', 'App\\Form\\LightingCorrectType', 'getLightingCorrectTypeService', false],
            'App\\Form\\LightingType' => ['privates', 'App\\Form\\LightingType', 'getLightingTypeService', false],
            'App\\Form\\PlanDeliveryChickType' => ['privates', 'App\\Form\\PlanDeliveryChickType', 'getPlanDeliveryChickTypeService', false],
            'App\\Form\\PlanDeliveryEggForHerdType' => ['privates', 'App\\Form\\PlanDeliveryEggForHerdType', 'getPlanDeliveryEggForHerdTypeService', false],
            'App\\Form\\PlanDeliveryEggType' => ['privates', 'App\\Form\\PlanDeliveryEggType', 'getPlanDeliveryEggTypeService', false],
            'App\\Form\\PlanIndicatorsType' => ['privates', 'App\\Form\\PlanIndicatorsType', 'getPlanIndicatorsTypeService', false],
            'App\\Form\\PlanInputType' => ['privates', 'App\\Form\\PlanInputType', 'getPlanInputTypeService', false],
            'App\\Form\\Production\\TransfersProductionType' => ['privates', 'App\\Form\\Production\\TransfersProductionType', 'getTransfersProductionTypeService', false],
            'App\\Form\\ResetPasswordRequestFormType' => ['privates', 'App\\Form\\ResetPasswordRequestFormType', 'getResetPasswordRequestFormTypeService', false],
            'App\\Form\\SelectionsType' => ['privates', 'App\\Form\\SelectionsType', 'getSelectionsTypeService', false],
            'App\\Form\\SellingEggType' => ['privates', 'App\\Form\\SellingEggType', 'getSellingEggTypeService', false],
            'App\\Form\\SettersType' => ['privates', 'App\\Form\\SettersType', 'getSettersTypeService', false],
            'App\\Form\\SupplierType' => ['privates', 'App\\Form\\SupplierType', 'getSupplierTypeService', false],
            'App\\Form\\TransfersType' => ['privates', 'App\\Form\\TransfersType', 'getTransfersTypeService', false],
            'App\\Form\\TransportListType' => ['privates', 'App\\Form\\TransportListType', 'getTransportListTypeService', false],
            'App\\Form\\User1Type' => ['privates', 'App\\Form\\User1Type', 'getUser1TypeService', false],
            'App\\Form\\UserType' => ['privates', 'App\\Form\\UserType', 'getUserTypeService', false],
            'App\\Form\\VaccinationType' => ['privates', 'App\\Form\\VaccinationType', 'getVaccinationTypeService', false],
            'Symfony\\Bridge\\Doctrine\\Form\\Type\\EntityType' => ['privates', 'form.type.entity', 'getForm_Type_EntityService', false],
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\ChoiceType' => ['privates', 'form.type.choice', 'getForm_Type_ChoiceService', false],
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FileType' => ['services', 'form.type.file', 'getForm_Type_FileService', false],
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FormType' => ['privates', 'form.type.form', 'getForm_Type_FormService', false],
        ], [
            'App\\Form\\BetweenDateType' => '?',
            'App\\Form\\BreedStandardType' => '?',
            'App\\Form\\BreedType' => '?',
            'App\\Form\\CarType' => '?',
            'App\\Form\\ChangePasswordFormType' => '?',
            'App\\Form\\ChickIntegrationType' => '?',
            'App\\Form\\ChickTemperatureType' => '?',
            'App\\Form\\ChicksRecipientType' => '?',
            'App\\Form\\ContactInfoType' => '?',
            'App\\Form\\CustomerType' => '?',
            'App\\Form\\DeliveryPartIndexType' => '?',
            'App\\Form\\DeliveryProductionType' => '?',
            'App\\Form\\DeliveryType' => '?',
            'App\\Form\\DriverType' => '?',
            'App\\Form\\HatchersType' => '?',
            'App\\Form\\HerdActiveType' => '?',
            'App\\Form\\HerdsType' => '?',
            'App\\Form\\InputDeliveryProductionType' => '?',
            'App\\Form\\InputDeliveryType' => '?',
            'App\\Form\\InputsDetailsType' => '?',
            'App\\Form\\InputsFarmType' => '?',
            'App\\Form\\InputsType' => '?',
            'App\\Form\\LightingCorrectType' => '?',
            'App\\Form\\LightingType' => '?',
            'App\\Form\\PlanDeliveryChickType' => '?',
            'App\\Form\\PlanDeliveryEggForHerdType' => '?',
            'App\\Form\\PlanDeliveryEggType' => '?',
            'App\\Form\\PlanIndicatorsType' => '?',
            'App\\Form\\PlanInputType' => '?',
            'App\\Form\\Production\\TransfersProductionType' => '?',
            'App\\Form\\ResetPasswordRequestFormType' => '?',
            'App\\Form\\SelectionsType' => '?',
            'App\\Form\\SellingEggType' => '?',
            'App\\Form\\SettersType' => '?',
            'App\\Form\\SupplierType' => '?',
            'App\\Form\\TransfersType' => '?',
            'App\\Form\\TransportListType' => '?',
            'App\\Form\\User1Type' => '?',
            'App\\Form\\UserType' => '?',
            'App\\Form\\VaccinationType' => '?',
            'Symfony\\Bridge\\Doctrine\\Form\\Type\\EntityType' => '?',
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\ChoiceType' => '?',
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FileType' => '?',
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FormType' => '?',
        ]), ['Symfony\\Component\\Form\\Extension\\Core\\Type\\FormType' => new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_extension.form.transformation_failure_handling'] ?? $this->getForm_TypeExtension_Form_TransformationFailureHandlingService());
            yield 1 => ($this->privates['form.type_extension.form.http_foundation'] ?? $this->getForm_TypeExtension_Form_HttpFoundationService());
            yield 2 => ($this->privates['form.type_extension.form.validator'] ?? $this->getForm_TypeExtension_Form_ValidatorService());
            yield 3 => ($this->privates['form.type_extension.upload.validator'] ?? $this->getForm_TypeExtension_Upload_ValidatorService());
            yield 4 => ($this->privates['form.type_extension.csrf'] ?? $this->getForm_TypeExtension_CsrfService());
        }, 5), 'Symfony\\Component\\Form\\Extension\\Core\\Type\\RepeatedType' => new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_extension.repeated.validator'] ?? ($this->privates['form.type_extension.repeated.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\RepeatedTypeValidatorExtension()));
        }, 1), 'Symfony\\Component\\Form\\Extension\\Core\\Type\\SubmitType' => new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_extension.submit.validator'] ?? ($this->privates['form.type_extension.submit.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\SubmitTypeValidatorExtension()));
        }, 1)], new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_guesser.validator'] ?? $this->getForm_TypeGuesser_ValidatorService());
            yield 1 => ($this->privates['form.type_guesser.doctrine'] ?? $this->getForm_TypeGuesser_DoctrineService());
        }, 2))], new \Symfony\Component\Form\ResolvedFormTypeFactory());
    }

    /*
     * Gets the private 'form.server_params' shared service.
     *
     * @return \Symfony\Component\Form\Util\ServerParams
     */
    protected function getForm_ServerParamsService()
    {
        return $this->privates['form.server_params'] = new \Symfony\Component\Form\Util\ServerParams(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the private 'form.type.choice' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\ChoiceType
     */
    protected function getForm_Type_ChoiceService()
    {
        return $this->privates['form.type.choice'] = new \Symfony\Component\Form\Extension\Core\Type\ChoiceType(($this->privates['form.choice_list_factory.cached'] ?? $this->getForm_ChoiceListFactory_CachedService()), ($this->services['translator'] ?? $this->getTranslatorService()));
    }

    /*
     * Gets the private 'form.type.entity' shared service.
     *
     * @return \Symfony\Bridge\Doctrine\Form\Type\EntityType
     */
    protected function getForm_Type_EntityService()
    {
        return $this->privates['form.type.entity'] = new \Symfony\Bridge\Doctrine\Form\Type\EntityType(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'form.type.form' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\FormType
     */
    protected function getForm_Type_FormService()
    {
        return $this->privates['form.type.form'] = new \Symfony\Component\Form\Extension\Core\Type\FormType(($this->privates['property_accessor'] ?? $this->getPropertyAccessorService()));
    }

    /*
     * Gets the private 'form.type_extension.csrf' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Csrf\Type\FormTypeCsrfExtension
     */
    protected function getForm_TypeExtension_CsrfService()
    {
        return $this->privates['form.type_extension.csrf'] = new \Symfony\Component\Form\Extension\Csrf\Type\FormTypeCsrfExtension(($this->services['security.csrf.token_manager'] ?? $this->getSecurity_Csrf_TokenManagerService()), true, '_token', ($this->services['translator'] ?? $this->getTranslatorService()), 'validators', ($this->privates['form.server_params'] ?? $this->getForm_ServerParamsService()));
    }

    /*
     * Gets the private 'form.type_extension.form.http_foundation' shared service.
     *
     * @return \Symfony\Component\Form\Extension\HttpFoundation\Type\FormTypeHttpFoundationExtension
     */
    protected function getForm_TypeExtension_Form_HttpFoundationService()
    {
        return $this->privates['form.type_extension.form.http_foundation'] = new \Symfony\Component\Form\Extension\HttpFoundation\Type\FormTypeHttpFoundationExtension(new \Symfony\Component\Form\Extension\HttpFoundation\HttpFoundationRequestHandler(($this->privates['form.server_params'] ?? $this->getForm_ServerParamsService())));
    }

    /*
     * Gets the private 'form.type_extension.form.transformation_failure_handling' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Core\Type\TransformationFailureExtension
     */
    protected function getForm_TypeExtension_Form_TransformationFailureHandlingService()
    {
        return $this->privates['form.type_extension.form.transformation_failure_handling'] = new \Symfony\Component\Form\Extension\Core\Type\TransformationFailureExtension(($this->services['translator'] ?? $this->getTranslatorService()));
    }

    /*
     * Gets the private 'form.type_extension.form.validator' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Validator\Type\FormTypeValidatorExtension
     */
    protected function getForm_TypeExtension_Form_ValidatorService()
    {
        return $this->privates['form.type_extension.form.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\FormTypeValidatorExtension(($this->services['validator'] ?? $this->getValidatorService()));
    }

    /*
     * Gets the private 'form.type_extension.upload.validator' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Validator\Type\UploadValidatorExtension
     */
    protected function getForm_TypeExtension_Upload_ValidatorService()
    {
        return $this->privates['form.type_extension.upload.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\UploadValidatorExtension(($this->services['translator'] ?? $this->getTranslatorService()), 'validators');
    }

    /*
     * Gets the private 'form.type_guesser.doctrine' shared service.
     *
     * @return \Symfony\Bridge\Doctrine\Form\DoctrineOrmTypeGuesser
     */
    protected function getForm_TypeGuesser_DoctrineService()
    {
        return $this->privates['form.type_guesser.doctrine'] = new \Symfony\Bridge\Doctrine\Form\DoctrineOrmTypeGuesser(($this->services['doctrine'] ?? $this->getDoctrineService()));
    }

    /*
     * Gets the private 'form.type_guesser.validator' shared service.
     *
     * @return \Symfony\Component\Form\Extension\Validator\ValidatorTypeGuesser
     */
    protected function getForm_TypeGuesser_ValidatorService()
    {
        return $this->privates['form.type_guesser.validator'] = new \Symfony\Component\Form\Extension\Validator\ValidatorTypeGuesser(($this->services['validator'] ?? $this->getValidatorService()));
    }

    /*
     * Gets the private 'fragment.renderer.inline' shared service.
     *
     * @return \Symfony\Component\HttpKernel\Fragment\InlineFragmentRenderer
     */
    protected function getFragment_Renderer_InlineService()
    {
        $this->privates['fragment.renderer.inline'] = $instance = new \Symfony\Component\HttpKernel\Fragment\InlineFragmentRenderer(($this->services['http_kernel'] ?? $this->getHttpKernelService()), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));

        $instance->setFragmentPath('/_fragment');

        return $instance;
    }

    /*
     * Gets the private 'framework_extra_bundle.argument_name_convertor' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\Request\ArgumentNameConverter
     */
    protected function getFrameworkExtraBundle_ArgumentNameConvertorService()
    {
        return $this->privates['framework_extra_bundle.argument_name_convertor'] = new \Sensio\Bundle\FrameworkExtraBundle\Request\ArgumentNameConverter(($this->privates['argument_metadata_factory'] ?? ($this->privates['argument_metadata_factory'] = new \Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadataFactory())));
    }

    /*
     * Gets the private 'framework_extra_bundle.event.is_granted' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\IsGrantedListener
     */
    protected function getFrameworkExtraBundle_Event_IsGrantedService()
    {
        return $this->privates['framework_extra_bundle.event.is_granted'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\IsGrantedListener(($this->privates['framework_extra_bundle.argument_name_convertor'] ?? $this->getFrameworkExtraBundle_ArgumentNameConvertorService()), ($this->services['security.authorization_checker'] ?? $this->getSecurity_AuthorizationCheckerService()));
    }

    /*
     * Gets the private 'http_client' shared service.
     *
     * @return \Symfony\Contracts\HttpClient\HttpClientInterface
     */
    protected function getHttpClientService()
    {
        $this->privates['http_client'] = $instance = \Symfony\Component\HttpClient\HttpClient::create([], 6);

        $a = new \Symfony\Bridge\Monolog\Logger('http_client');
        $a->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $a->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        $instance->setLogger($a);

        return $instance;
    }

    /*
     * Gets the private 'locale_aware_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\LocaleAwareListener
     */
    protected function getLocaleAwareListenerService()
    {
        return $this->privates['locale_aware_listener'] = new \Symfony\Component\HttpKernel\EventListener\LocaleAwareListener(new RewindableGenerator(function () {
            yield 0 => ($this->services['translator'] ?? $this->getTranslatorService());
        }, 1), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the private 'locale_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\LocaleListener
     */
    protected function getLocaleListenerService()
    {
        return $this->privates['locale_listener'] = new \Symfony\Component\HttpKernel\EventListener\LocaleListener(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), 'pl', ($this->services['router'] ?? $this->getRouterService()));
    }

    /*
     * Gets the private 'mailer.mailer' shared service.
     *
     * @return \Symfony\Component\Mailer\Mailer
     */
    protected function getMailer_MailerService()
    {
        return $this->privates['mailer.mailer'] = new \Symfony\Component\Mailer\Mailer((new \Symfony\Component\Mailer\Transport(new RewindableGenerator(function () {
            yield 0 => $this->getMailer_TransportFactory_GmailService();
            yield 1 => $this->getMailer_TransportFactory_NullService();
            yield 2 => $this->getMailer_TransportFactory_SendmailService();
            yield 3 => $this->getMailer_TransportFactory_SmtpService();
        }, 4)))->fromStrings(['main' => $this->getEnv('MAILER_DSN')]), NULL, ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));
    }

    /*
     * Gets the private 'mailer.transport_factory.gmail' shared service.
     *
     * @return \Symfony\Component\Mailer\Bridge\Google\Transport\GmailTransportFactory
     */
    protected function getMailer_TransportFactory_GmailService()
    {
        return new \Symfony\Component\Mailer\Bridge\Google\Transport\GmailTransportFactory(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['http_client'] ?? $this->getHttpClientService()), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'mailer.transport_factory.null' shared service.
     *
     * @return \Symfony\Component\Mailer\Transport\NullTransportFactory
     */
    protected function getMailer_TransportFactory_NullService()
    {
        return new \Symfony\Component\Mailer\Transport\NullTransportFactory(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['http_client'] ?? $this->getHttpClientService()), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'mailer.transport_factory.sendmail' shared service.
     *
     * @return \Symfony\Component\Mailer\Transport\SendmailTransportFactory
     */
    protected function getMailer_TransportFactory_SendmailService()
    {
        return new \Symfony\Component\Mailer\Transport\SendmailTransportFactory(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['http_client'] ?? $this->getHttpClientService()), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'mailer.transport_factory.smtp' shared service.
     *
     * @return \Symfony\Component\Mailer\Transport\Smtp\EsmtpTransportFactory
     */
    protected function getMailer_TransportFactory_SmtpService()
    {
        return new \Symfony\Component\Mailer\Transport\Smtp\EsmtpTransportFactory(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['http_client'] ?? $this->getHttpClientService()), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'mime_types' shared service.
     *
     * @return \Symfony\Component\Mime\MimeTypes
     */
    protected function getMimeTypesService()
    {
        $this->privates['mime_types'] = $instance = new \Symfony\Component\Mime\MimeTypes();

        $instance->setDefault($instance);

        return $instance;
    }

    /*
     * Gets the private 'monolog.handler.console' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Handler\ConsoleHandler
     */
    protected function getMonolog_Handler_ConsoleService()
    {
        return $this->privates['monolog.handler.console'] = new \Symfony\Bridge\Monolog\Handler\ConsoleHandler(NULL, true, [], []);
    }

    /*
     * Gets the private 'monolog.handler.main' shared service.
     *
     * @return \Monolog\Handler\FingersCrossedHandler
     */
    protected function getMonolog_Handler_MainService()
    {
        $a = new \Monolog\Handler\StreamHandler('php://stderr', 100, true, NULL, false);
        $a->pushProcessor(new \Monolog\Processor\PsrLogMessageProcessor());
        $a->setFormatter(new \Monolog\Formatter\JsonFormatter());

        return $this->privates['monolog.handler.main'] = new \Monolog\Handler\FingersCrossedHandler($a, new \Symfony\Bridge\Monolog\Handler\FingersCrossed\HttpCodeActivationStrategy(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), [0 => ['code' => 404, 'urls' => []], 1 => ['code' => 405, 'urls' => []]], 400), 50, true, true, NULL);
    }

    /*
     * Gets the private 'monolog.logger' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_LoggerService()
    {
        $this->privates['monolog.logger'] = $instance = new \Symfony\Bridge\Monolog\Logger('app');

        $instance->useMicrosecondTimestamps(true);
        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the private 'monolog.logger.cache' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_CacheService()
    {
        $this->privates['monolog.logger.cache'] = $instance = new \Symfony\Bridge\Monolog\Logger('cache');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the private 'monolog.logger.request' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_RequestService()
    {
        $this->privates['monolog.logger.request'] = $instance = new \Symfony\Bridge\Monolog\Logger('request');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the private 'monolog.logger.security' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_SecurityService()
    {
        $this->privates['monolog.logger.security'] = $instance = new \Symfony\Bridge\Monolog\Logger('security');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the private 'monolog.logger.snappy' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_SnappyService()
    {
        $this->privates['monolog.logger.snappy'] = $instance = new \Symfony\Bridge\Monolog\Logger('snappy');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the private 'parameter_bag' shared service.
     *
     * @return \Symfony\Component\DependencyInjection\ParameterBag\ContainerBag
     */
    protected function getParameterBagService()
    {
        return $this->privates['parameter_bag'] = new \Symfony\Component\DependencyInjection\ParameterBag\ContainerBag($this);
    }

    /*
     * Gets the private 'property_accessor' shared service.
     *
     * @return \Symfony\Component\PropertyAccess\PropertyAccessor
     */
    protected function getPropertyAccessorService()
    {
        return $this->privates['property_accessor'] = new \Symfony\Component\PropertyAccess\PropertyAccessor(false, false, ($this->privates['cache.property_access'] ?? $this->getCache_PropertyAccessService()), true);
    }

    /*
     * Gets the private 'property_info.cache' shared service.
     *
     * @return \Symfony\Component\PropertyInfo\PropertyInfoCacheExtractor
     */
    protected function getPropertyInfo_CacheService()
    {
        return $this->privates['property_info.cache'] = new \Symfony\Component\PropertyInfo\PropertyInfoCacheExtractor(new \Symfony\Component\PropertyInfo\PropertyInfoExtractor(new RewindableGenerator(function () {
            yield 0 => ($this->privates['property_info.serializer_extractor'] ?? $this->getPropertyInfo_SerializerExtractorService());
            yield 1 => ($this->privates['property_info.reflection_extractor'] ?? ($this->privates['property_info.reflection_extractor'] = new \Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor()));
            yield 2 => ($this->privates['doctrine.orm.default_entity_manager.property_info_extractor'] ?? $this->getDoctrine_Orm_DefaultEntityManager_PropertyInfoExtractorService());
        }, 3), new RewindableGenerator(function () {
            yield 0 => ($this->privates['doctrine.orm.default_entity_manager.property_info_extractor'] ?? $this->getDoctrine_Orm_DefaultEntityManager_PropertyInfoExtractorService());
            yield 1 => ($this->privates['property_info.php_doc_extractor'] ?? ($this->privates['property_info.php_doc_extractor'] = new \Symfony\Component\PropertyInfo\Extractor\PhpDocExtractor()));
            yield 2 => ($this->privates['property_info.reflection_extractor'] ?? ($this->privates['property_info.reflection_extractor'] = new \Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor()));
        }, 3), new RewindableGenerator(function () {
            yield 0 => ($this->privates['property_info.php_doc_extractor'] ?? ($this->privates['property_info.php_doc_extractor'] = new \Symfony\Component\PropertyInfo\Extractor\PhpDocExtractor()));
        }, 1), new RewindableGenerator(function () {
            yield 0 => ($this->privates['doctrine.orm.default_entity_manager.property_info_extractor'] ?? $this->getDoctrine_Orm_DefaultEntityManager_PropertyInfoExtractorService());
            yield 1 => ($this->privates['property_info.reflection_extractor'] ?? ($this->privates['property_info.reflection_extractor'] = new \Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor()));
        }, 2), new RewindableGenerator(function () {
            yield 0 => ($this->privates['property_info.reflection_extractor'] ?? ($this->privates['property_info.reflection_extractor'] = new \Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor()));
        }, 1)), ($this->privates['cache.property_info'] ?? $this->getCache_PropertyInfoService()));
    }

    /*
     * Gets the private 'property_info.serializer_extractor' shared service.
     *
     * @return \Symfony\Component\PropertyInfo\Extractor\SerializerExtractor
     */
    protected function getPropertyInfo_SerializerExtractorService()
    {
        return $this->privates['property_info.serializer_extractor'] = new \Symfony\Component\PropertyInfo\Extractor\SerializerExtractor(($this->privates['serializer.mapping.cache_class_metadata_factory'] ?? $this->getSerializer_Mapping_CacheClassMetadataFactoryService()));
    }

    /*
     * Gets the private 'router.cache_warmer' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\CacheWarmer\RouterCacheWarmer
     */
    protected function getRouter_CacheWarmerService()
    {
        return $this->privates['router.cache_warmer'] = new \Symfony\Bundle\FrameworkBundle\CacheWarmer\RouterCacheWarmer((new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'router' => ['services', 'router', 'getRouterService', false],
        ], [
            'router' => '?',
        ]))->withContext('router.cache_warmer', $this));
    }

    /*
     * Gets the private 'router.request_context' shared service.
     *
     * @return \Symfony\Component\Routing\RequestContext
     */
    protected function getRouter_RequestContextService()
    {
        return $this->privates['router.request_context'] = new \Symfony\Component\Routing\RequestContext('', 'GET', 'localhost', 'http', 80, 443);
    }

    /*
     * Gets the private 'router_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\RouterListener
     */
    protected function getRouterListenerService()
    {
        return $this->privates['router_listener'] = new \Symfony\Component\HttpKernel\EventListener\RouterListener(($this->services['router'] ?? $this->getRouterService()), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->privates['router.request_context'] ?? $this->getRouter_RequestContextService()), ($this->privates['monolog.logger.request'] ?? $this->getMonolog_Logger_RequestService()), \dirname(__DIR__, 4), false);
    }

    /*
     * Gets the private 'security.access.authenticated_voter' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\Voter\AuthenticatedVoter
     */
    protected function getSecurity_Access_AuthenticatedVoterService()
    {
        return $this->privates['security.access.authenticated_voter'] = new \Symfony\Component\Security\Core\Authorization\Voter\AuthenticatedVoter(($this->privates['security.authentication.trust_resolver'] ?? ($this->privates['security.authentication.trust_resolver'] = new \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver(NULL, NULL))));
    }

    /*
     * Gets the private 'security.access.decision_manager' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\AccessDecisionManager
     */
    protected function getSecurity_Access_DecisionManagerService()
    {
        return $this->privates['security.access.decision_manager'] = new \Symfony\Component\Security\Core\Authorization\AccessDecisionManager(new RewindableGenerator(function () {
            yield 0 => ($this->privates['security.access.authenticated_voter'] ?? $this->getSecurity_Access_AuthenticatedVoterService());
            yield 1 => ($this->privates['security.access.role_hierarchy_voter'] ?? $this->getSecurity_Access_RoleHierarchyVoterService());
            yield 2 => ($this->privates['security.access.expression_voter'] ?? $this->getSecurity_Access_ExpressionVoterService());
        }, 3), 'affirmative', false, true);
    }

    /*
     * Gets the private 'security.access.expression_voter' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\Voter\ExpressionVoter
     */
    protected function getSecurity_Access_ExpressionVoterService()
    {
        return $this->privates['security.access.expression_voter'] = new \Symfony\Component\Security\Core\Authorization\Voter\ExpressionVoter(new \Symfony\Component\Security\Core\Authorization\ExpressionLanguage(($this->privates['cache.security_expression_language'] ?? $this->getCache_SecurityExpressionLanguageService())), ($this->privates['security.authentication.trust_resolver'] ?? ($this->privates['security.authentication.trust_resolver'] = new \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver(NULL, NULL))), ($this->services['security.authorization_checker'] ?? $this->getSecurity_AuthorizationCheckerService()), ($this->privates['security.role_hierarchy'] ?? $this->getSecurity_RoleHierarchyService()));
    }

    /*
     * Gets the private 'security.access.role_hierarchy_voter' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\Voter\RoleHierarchyVoter
     */
    protected function getSecurity_Access_RoleHierarchyVoterService()
    {
        return $this->privates['security.access.role_hierarchy_voter'] = new \Symfony\Component\Security\Core\Authorization\Voter\RoleHierarchyVoter(($this->privates['security.role_hierarchy'] ?? $this->getSecurity_RoleHierarchyService()));
    }

    /*
     * Gets the private 'security.access_listener' shared service.
     *
     * @return \Symfony\Component\Security\Http\Firewall\AccessListener
     */
    protected function getSecurity_AccessListenerService()
    {
        return $this->privates['security.access_listener'] = new \Symfony\Component\Security\Http\Firewall\AccessListener(($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()), ($this->privates['security.access.decision_manager'] ?? $this->getSecurity_Access_DecisionManagerService()), ($this->privates['security.access_map'] ?? $this->getSecurity_AccessMapService()), ($this->privates['security.authentication.manager'] ?? $this->getSecurity_Authentication_ManagerService()));
    }

    /*
     * Gets the private 'security.access_map' shared service.
     *
     * @return \Symfony\Component\Security\Http\AccessMap
     */
    protected function getSecurity_AccessMapService()
    {
        $this->privates['security.access_map'] = $instance = new \Symfony\Component\Security\Http\AccessMap();

        $instance->add(new \Symfony\Component\HttpFoundation\RequestMatcher('^/audit'), [0 => 'ROLE_ADMIN'], NULL);

        return $instance;
    }

    /*
     * Gets the private 'security.authentication.listener.anonymous.main' shared service.
     *
     * @return \Symfony\Component\Security\Http\Firewall\AnonymousAuthenticationListener
     */
    protected function getSecurity_Authentication_Listener_Anonymous_MainService()
    {
        return $this->privates['security.authentication.listener.anonymous.main'] = new \Symfony\Component\Security\Http\Firewall\AnonymousAuthenticationListener(($this->privates['security.untracked_token_storage'] ?? ($this->privates['security.untracked_token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())), $this->getParameter('container.build_hash'), ($this->privates['monolog.logger.security'] ?? $this->getMonolog_Logger_SecurityService()), ($this->privates['security.authentication.manager'] ?? $this->getSecurity_Authentication_ManagerService()));
    }

    /*
     * Gets the private 'security.authentication.listener.guard.main' shared service.
     *
     * @return \Symfony\Component\Security\Guard\Firewall\GuardAuthenticationListener
     */
    protected function getSecurity_Authentication_Listener_Guard_MainService()
    {
        $a = new \Symfony\Component\Security\Guard\GuardAuthenticatorHandler(($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), []);
        $a->setSessionAuthenticationStrategy(new \Symfony\Component\Security\Http\Session\SessionAuthenticationStrategy('migrate'));

        return $this->privates['security.authentication.listener.guard.main'] = new \Symfony\Component\Security\Guard\Firewall\GuardAuthenticationListener($a, ($this->privates['security.authentication.manager'] ?? $this->getSecurity_Authentication_ManagerService()), 'main', new RewindableGenerator(function () {
            yield 0 => ($this->privates['App\\Security\\LoginFormAuthenticator'] ?? $this->getLoginFormAuthenticatorService());
        }, 1), ($this->privates['monolog.logger.security'] ?? $this->getMonolog_Logger_SecurityService()));
    }

    /*
     * Gets the private 'security.authentication.manager' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager
     */
    protected function getSecurity_Authentication_ManagerService()
    {
        $this->privates['security.authentication.manager'] = $instance = new \Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager(new RewindableGenerator(function () {
            yield 0 => ($this->privates['security.authentication.provider.guard.main'] ?? $this->getSecurity_Authentication_Provider_Guard_MainService());
            yield 1 => ($this->privates['security.authentication.provider.anonymous.main'] ?? ($this->privates['security.authentication.provider.anonymous.main'] = new \Symfony\Component\Security\Core\Authentication\Provider\AnonymousAuthenticationProvider($this->getParameter('container.build_hash'))));
        }, 2), true);

        $instance->setEventDispatcher(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));

        return $instance;
    }

    /*
     * Gets the private 'security.authentication.provider.guard.main' shared service.
     *
     * @return \Symfony\Component\Security\Guard\Provider\GuardAuthenticationProvider
     */
    protected function getSecurity_Authentication_Provider_Guard_MainService()
    {
        return $this->privates['security.authentication.provider.guard.main'] = new \Symfony\Component\Security\Guard\Provider\GuardAuthenticationProvider(new RewindableGenerator(function () {
            yield 0 => ($this->privates['App\\Security\\LoginFormAuthenticator'] ?? $this->getLoginFormAuthenticatorService());
        }, 1), ($this->privates['security.user.provider.concrete.app_user_provider'] ?? $this->getSecurity_User_Provider_Concrete_AppUserProviderService()), 'main', new \Symfony\Component\Security\Core\User\UserChecker(), ($this->services['security.password_encoder'] ?? $this->getSecurity_PasswordEncoderService()));
    }

    /*
     * Gets the private 'security.channel_listener' shared service.
     *
     * @return \Symfony\Component\Security\Http\Firewall\ChannelListener
     */
    protected function getSecurity_ChannelListenerService()
    {
        return $this->privates['security.channel_listener'] = new \Symfony\Component\Security\Http\Firewall\ChannelListener(($this->privates['security.access_map'] ?? $this->getSecurity_AccessMapService()), new \Symfony\Component\Security\Http\EntryPoint\RetryAuthenticationEntryPoint(80, 443), ($this->privates['monolog.logger.security'] ?? $this->getMonolog_Logger_SecurityService()));
    }

    /*
     * Gets the private 'security.command.user_password_encoder' shared service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Command\UserPasswordEncoderCommand
     */
    protected function getSecurity_Command_UserPasswordEncoderService()
    {
        $this->privates['security.command.user_password_encoder'] = $instance = new \Symfony\Bundle\SecurityBundle\Command\UserPasswordEncoderCommand(($this->privates['security.encoder_factory.generic'] ?? $this->getSecurity_EncoderFactory_GenericService()), [0 => 'App\\Entity\\User']);

        $instance->setName('security:encode-password');

        return $instance;
    }

    /*
     * Gets the private 'security.context_listener.0' shared service.
     *
     * @return \Symfony\Component\Security\Http\Firewall\ContextListener
     */
    protected function getSecurity_ContextListener_0Service()
    {
        return $this->privates['security.context_listener.0'] = new \Symfony\Component\Security\Http\Firewall\ContextListener(($this->privates['security.untracked_token_storage'] ?? ($this->privates['security.untracked_token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())), new RewindableGenerator(function () {
            yield 0 => ($this->privates['security.user.provider.concrete.app_user_provider'] ?? $this->getSecurity_User_Provider_Concrete_AppUserProviderService());
        }, 1), 'main', ($this->privates['monolog.logger.security'] ?? $this->getMonolog_Logger_SecurityService()), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['security.authentication.trust_resolver'] ?? ($this->privates['security.authentication.trust_resolver'] = new \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver(NULL, NULL))), [0 => ($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()), 1 => 'enableUsageTracking']);
    }

    /*
     * Gets the private 'security.csrf.token_storage' shared service.
     *
     * @return \Symfony\Component\Security\Csrf\TokenStorage\SessionTokenStorage
     */
    protected function getSecurity_Csrf_TokenStorageService()
    {
        return $this->privates['security.csrf.token_storage'] = new \Symfony\Component\Security\Csrf\TokenStorage\SessionTokenStorage(($this->services['session'] ?? $this->getSessionService()));
    }

    /*
     * Gets the private 'security.encoder_factory.generic' shared service.
     *
     * @return \Symfony\Component\Security\Core\Encoder\EncoderFactory
     */
    protected function getSecurity_EncoderFactory_GenericService()
    {
        return $this->privates['security.encoder_factory.generic'] = new \Symfony\Component\Security\Core\Encoder\EncoderFactory(['App\\Entity\\User' => ['class' => 'Symfony\\Component\\Security\\Core\\Encoder\\NativePasswordEncoder', 'arguments' => [0 => NULL, 1 => NULL, 2 => NULL, 3 => '2y']]]);
    }

    /*
     * Gets the private 'security.firewall' shared service.
     *
     * @return \Symfony\Bundle\SecurityBundle\EventListener\FirewallListener
     */
    protected function getSecurity_FirewallService()
    {
        return $this->privates['security.firewall'] = new \Symfony\Bundle\SecurityBundle\EventListener\FirewallListener(($this->privates['security.firewall.map'] ?? $this->getSecurity_Firewall_MapService()), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['security.logout_url_generator'] ?? $this->getSecurity_LogoutUrlGeneratorService()));
    }

    /*
     * Gets the private 'security.firewall.map' shared service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Security\FirewallMap
     */
    protected function getSecurity_Firewall_MapService()
    {
        return $this->privates['security.firewall.map'] = new \Symfony\Bundle\SecurityBundle\Security\FirewallMap(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'security.firewall.map.context.dev' => ['privates', 'security.firewall.map.context.dev', 'getSecurity_Firewall_Map_Context_DevService', false],
            'security.firewall.map.context.main' => ['privates', 'security.firewall.map.context.main', 'getSecurity_Firewall_Map_Context_MainService', false],
        ], [
            'security.firewall.map.context.dev' => '?',
            'security.firewall.map.context.main' => '?',
        ]), new RewindableGenerator(function () {
            yield 'security.firewall.map.context.dev' => ($this->privates['.security.request_matcher.Iy.T22O'] ?? ($this->privates['.security.request_matcher.Iy.T22O'] = new \Symfony\Component\HttpFoundation\RequestMatcher('^/(_(profiler|wdt)|css|images|js)/')));
            yield 'security.firewall.map.context.main' => NULL;
        }, 2));
    }

    /*
     * Gets the private 'security.firewall.map.context.dev' shared service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Security\FirewallContext
     */
    protected function getSecurity_Firewall_Map_Context_DevService()
    {
        return $this->privates['security.firewall.map.context.dev'] = new \Symfony\Bundle\SecurityBundle\Security\FirewallContext(new RewindableGenerator(function () {
            return new \EmptyIterator();
        }, 0), NULL, NULL, new \Symfony\Bundle\SecurityBundle\Security\FirewallConfig('dev', 'security.user_checker', '.security.request_matcher.Iy.T22O', false, false, '', '', '', '', '', [], NULL));
    }

    /*
     * Gets the private 'security.firewall.map.context.main' shared service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Security\LazyFirewallContext
     */
    protected function getSecurity_Firewall_Map_Context_MainService()
    {
        $a = ($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService());
        $b = ($this->services['router'] ?? $this->getRouterService());

        $c = new \Symfony\Component\Security\Http\HttpUtils($b, $b, '{^https?://%s$}i', '{^https://%s$}i');
        $d = new \Symfony\Component\Security\Http\Firewall\LogoutListener($a, $c, new \Symfony\Component\Security\Http\Logout\DefaultLogoutSuccessHandler($c, '/'), ['csrf_parameter' => '_csrf_token', 'csrf_token_id' => 'logout', 'logout_path' => 'app_logout']);
        $d->addHandler(new \Symfony\Component\Security\Http\Logout\CsrfTokenClearingLogoutHandler(($this->privates['security.csrf.token_storage'] ?? $this->getSecurity_Csrf_TokenStorageService())));
        $d->addHandler(new \Symfony\Component\Security\Http\Logout\SessionLogoutHandler());

        return $this->privates['security.firewall.map.context.main'] = new \Symfony\Bundle\SecurityBundle\Security\LazyFirewallContext(new RewindableGenerator(function () {
            yield 0 => ($this->privates['security.channel_listener'] ?? $this->getSecurity_ChannelListenerService());
            yield 1 => ($this->privates['security.context_listener.0'] ?? $this->getSecurity_ContextListener_0Service());
            yield 2 => ($this->privates['security.authentication.listener.guard.main'] ?? $this->getSecurity_Authentication_Listener_Guard_MainService());
            yield 3 => ($this->privates['security.authentication.listener.anonymous.main'] ?? $this->getSecurity_Authentication_Listener_Anonymous_MainService());
            yield 4 => ($this->privates['security.access_listener'] ?? $this->getSecurity_AccessListenerService());
        }, 5), new \Symfony\Component\Security\Http\Firewall\ExceptionListener($a, ($this->privates['security.authentication.trust_resolver'] ?? ($this->privates['security.authentication.trust_resolver'] = new \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver(NULL, NULL))), $c, 'main', ($this->privates['App\\Security\\LoginFormAuthenticator'] ?? $this->getLoginFormAuthenticatorService()), NULL, ($this->services['App\\Security\\AccessDeniedHandler'] ?? $this->getAccessDeniedHandlerService()), ($this->privates['monolog.logger.security'] ?? $this->getMonolog_Logger_SecurityService()), false), $d, new \Symfony\Bundle\SecurityBundle\Security\FirewallConfig('main', 'security.user_checker', NULL, true, false, 'security.user.provider.concrete.app_user_provider', 'main', 'App\\Security\\LoginFormAuthenticator', 'App\\Security\\AccessDeniedHandler', NULL, [0 => 'guard', 1 => 'anonymous'], NULL), ($this->privates['security.untracked_token_storage'] ?? ($this->privates['security.untracked_token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())));
    }

    /*
     * Gets the private 'security.helper' shared service.
     *
     * @return \Symfony\Component\Security\Core\Security
     */
    protected function getSecurity_HelperService()
    {
        return $this->privates['security.helper'] = new \Symfony\Component\Security\Core\Security(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'security.authorization_checker' => ['services', 'security.authorization_checker', 'getSecurity_AuthorizationCheckerService', false],
            'security.token_storage' => ['services', 'security.token_storage', 'getSecurity_TokenStorageService', false],
        ], [
            'security.authorization_checker' => '?',
            'security.token_storage' => '?',
        ]));
    }

    /*
     * Gets the private 'security.logout_url_generator' shared service.
     *
     * @return \Symfony\Component\Security\Http\Logout\LogoutUrlGenerator
     */
    protected function getSecurity_LogoutUrlGeneratorService()
    {
        $this->privates['security.logout_url_generator'] = $instance = new \Symfony\Component\Security\Http\Logout\LogoutUrlGenerator(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->services['router'] ?? $this->getRouterService()), ($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()));

        $instance->registerListener('main', 'app_logout', 'logout', '_csrf_token', NULL, NULL);

        return $instance;
    }

    /*
     * Gets the private 'security.role_hierarchy' shared service.
     *
     * @return \Symfony\Component\Security\Core\Role\RoleHierarchy
     */
    protected function getSecurity_RoleHierarchyService()
    {
        return $this->privates['security.role_hierarchy'] = new \Symfony\Component\Security\Core\Role\RoleHierarchy($this->parameters['security.role_hierarchy.roles']);
    }

    /*
     * Gets the private 'security.user.provider.concrete.app_user_provider' shared service.
     *
     * @return \Symfony\Bridge\Doctrine\Security\User\EntityUserProvider
     */
    protected function getSecurity_User_Provider_Concrete_AppUserProviderService()
    {
        return $this->privates['security.user.provider.concrete.app_user_provider'] = new \Symfony\Bridge\Doctrine\Security\User\EntityUserProvider(($this->services['doctrine'] ?? $this->getDoctrineService()), 'App\\Entity\\User', 'email', NULL);
    }

    /*
     * Gets the private 'security.user_value_resolver' shared service.
     *
     * @return \Symfony\Component\Security\Http\Controller\UserValueResolver
     */
    protected function getSecurity_UserValueResolverService()
    {
        return $this->privates['security.user_value_resolver'] = new \Symfony\Component\Security\Http\Controller\UserValueResolver(($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()));
    }

    /*
     * Gets the private 'security.validator.user_password' shared service.
     *
     * @return \Symfony\Component\Security\Core\Validator\Constraints\UserPasswordValidator
     */
    protected function getSecurity_Validator_UserPasswordService()
    {
        return $this->privates['security.validator.user_password'] = new \Symfony\Component\Security\Core\Validator\Constraints\UserPasswordValidator(($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()), ($this->privates['security.encoder_factory.generic'] ?? $this->getSecurity_EncoderFactory_GenericService()));
    }

    /*
     * Gets the private 'sensio_framework_extra.controller.listener' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\ControllerListener
     */
    protected function getSensioFrameworkExtra_Controller_ListenerService()
    {
        return $this->privates['sensio_framework_extra.controller.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\ControllerListener(($this->privates['annotations.cached_reader'] ?? $this->getAnnotations_CachedReaderService()));
    }

    /*
     * Gets the private 'sensio_framework_extra.converter.listener' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\ParamConverterListener
     */
    protected function getSensioFrameworkExtra_Converter_ListenerService()
    {
        $a = new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\ParamConverterManager();
        $a->add(new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DoctrineParamConverter(($this->services['doctrine'] ?? $this->getDoctrineService()), new \Symfony\Component\ExpressionLanguage\ExpressionLanguage()), 0, 'doctrine.orm');
        $a->add(new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DateTimeParamConverter(), 0, 'datetime');

        return $this->privates['sensio_framework_extra.converter.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\ParamConverterListener($a, true);
    }

    /*
     * Gets the private 'sensio_framework_extra.security.listener' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener
     */
    protected function getSensioFrameworkExtra_Security_ListenerService()
    {
        return $this->privates['sensio_framework_extra.security.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener(($this->privates['framework_extra_bundle.argument_name_convertor'] ?? $this->getFrameworkExtraBundle_ArgumentNameConvertorService()), new \Sensio\Bundle\FrameworkExtraBundle\Security\ExpressionLanguage(), ($this->privates['security.authentication.trust_resolver'] ?? ($this->privates['security.authentication.trust_resolver'] = new \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver(NULL, NULL))), ($this->privates['security.role_hierarchy'] ?? $this->getSecurity_RoleHierarchyService()), ($this->services['security.token_storage'] ?? $this->getSecurity_TokenStorageService()), ($this->services['security.authorization_checker'] ?? $this->getSecurity_AuthorizationCheckerService()), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'sensio_framework_extra.view.listener' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\TemplateListener
     */
    protected function getSensioFrameworkExtra_View_ListenerService()
    {
        $this->privates['sensio_framework_extra.view.listener'] = $instance = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\TemplateListener(new \Sensio\Bundle\FrameworkExtraBundle\Templating\TemplateGuesser(($this->services['kernel'] ?? $this->get('kernel', 1))));

        $instance->setContainer((new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'twig' => ['services', 'twig', 'getTwigService', false],
        ], [
            'twig' => 'Twig\\Environment',
        ]))->withContext('sensio_framework_extra.view.listener', $this));

        return $instance;
    }

    /*
     * Gets the private 'serializer.mapping.cache_class_metadata_factory' shared service.
     *
     * @return \Symfony\Component\Serializer\Mapping\Factory\CacheClassMetadataFactory
     */
    protected function getSerializer_Mapping_CacheClassMetadataFactoryService()
    {
        return $this->privates['serializer.mapping.cache_class_metadata_factory'] = new \Symfony\Component\Serializer\Mapping\Factory\CacheClassMetadataFactory(new \Symfony\Component\Serializer\Mapping\Factory\ClassMetadataFactory(new \Symfony\Component\Serializer\Mapping\Loader\LoaderChain([0 => new \Symfony\Component\Serializer\Mapping\Loader\AnnotationLoader(($this->privates['annotations.cached_reader'] ?? $this->getAnnotations_CachedReaderService()))])), \Symfony\Component\Cache\Adapter\PhpArrayAdapter::create(($this->targetDir.''.'/serialization.php'), ($this->privates['cache.serializer'] ?? $this->getCache_SerializerService())));
    }

    /*
     * Gets the private 'serializer.mapping.cache_warmer' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\CacheWarmer\SerializerCacheWarmer
     */
    protected function getSerializer_Mapping_CacheWarmerService()
    {
        return $this->privates['serializer.mapping.cache_warmer'] = new \Symfony\Bundle\FrameworkBundle\CacheWarmer\SerializerCacheWarmer([0 => new \Symfony\Component\Serializer\Mapping\Loader\AnnotationLoader(($this->privates['annotations.cached_reader'] ?? $this->getAnnotations_CachedReaderService()))], ($this->targetDir.''.'/serialization.php'));
    }

    /*
     * Gets the private 'session.storage.native' shared service.
     *
     * @return \Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage
     */
    protected function getSession_Storage_NativeService()
    {
        return $this->privates['session.storage.native'] = new \Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage($this->parameters['session.storage.options'], NULL, new \Symfony\Component\HttpFoundation\Session\Storage\MetadataBag('_sf2_meta', 0));
    }

    /*
     * Gets the private 'session_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\SessionListener
     */
    protected function getSessionListenerService()
    {
        return $this->privates['session_listener'] = new \Symfony\Component\HttpKernel\EventListener\SessionListener(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'initialized_session' => ['services', 'session', NULL, false],
            'request_stack' => ['services', 'request_stack', 'getRequestStackService', false],
            'session' => ['services', 'session', 'getSessionService', false],
            'session_storage' => ['privates', 'session.storage.native', 'getSession_Storage_NativeService', false],
        ], [
            'initialized_session' => '?',
            'request_stack' => '?',
            'session' => '?',
            'session_storage' => '?',
        ]));
    }

    /*
     * Gets the private 'swiftmailer.command.debug' shared service.
     *
     * @return \Symfony\Bundle\SwiftmailerBundle\Command\DebugCommand
     */
    protected function getSwiftmailer_Command_DebugService()
    {
        $this->privates['swiftmailer.command.debug'] = $instance = new \Symfony\Bundle\SwiftmailerBundle\Command\DebugCommand();

        $instance->setName('debug:swiftmailer');

        return $instance;
    }

    /*
     * Gets the private 'swiftmailer.command.new_email' shared service.
     *
     * @return \Symfony\Bundle\SwiftmailerBundle\Command\NewEmailCommand
     */
    protected function getSwiftmailer_Command_NewEmailService()
    {
        $this->privates['swiftmailer.command.new_email'] = $instance = new \Symfony\Bundle\SwiftmailerBundle\Command\NewEmailCommand();

        $instance->setName('swiftmailer:email:send');

        return $instance;
    }

    /*
     * Gets the private 'swiftmailer.command.send_email' shared service.
     *
     * @return \Symfony\Bundle\SwiftmailerBundle\Command\SendEmailCommand
     */
    protected function getSwiftmailer_Command_SendEmailService()
    {
        $this->privates['swiftmailer.command.send_email'] = $instance = new \Symfony\Bundle\SwiftmailerBundle\Command\SendEmailCommand();

        $instance->setName('swiftmailer:spool:send');

        return $instance;
    }

    /*
     * Gets the private 'swiftmailer.email_sender.listener' shared service.
     *
     * @return \Symfony\Bundle\SwiftmailerBundle\EventListener\EmailSenderListener
     */
    protected function getSwiftmailer_EmailSender_ListenerService()
    {
        return $this->privates['swiftmailer.email_sender.listener'] = new \Symfony\Bundle\SwiftmailerBundle\EventListener\EmailSenderListener($this, ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'symfonycasts.reset_password.cleaner' shared service.
     *
     * @return \SymfonyCasts\Bundle\ResetPassword\Util\ResetPasswordCleaner
     */
    protected function getSymfonycasts_ResetPassword_CleanerService()
    {
        return $this->privates['symfonycasts.reset_password.cleaner'] = new \SymfonyCasts\Bundle\ResetPassword\Util\ResetPasswordCleaner(($this->privates['App\\Repository\\ResetPasswordRequestRepository'] ?? $this->getResetPasswordRequestRepositoryService()), true);
    }

    /*
     * Gets the private 'translation.extractor' shared service.
     *
     * @return \Symfony\Component\Translation\Extractor\ChainExtractor
     */
    protected function getTranslation_ExtractorService()
    {
        $this->privates['translation.extractor'] = $instance = new \Symfony\Component\Translation\Extractor\ChainExtractor();

        $instance->addExtractor('php', new \Symfony\Component\Translation\Extractor\PhpExtractor());
        $instance->addExtractor('twig', new \Symfony\Bridge\Twig\Translation\TwigExtractor(($this->services['twig'] ?? $this->getTwigService())));

        return $instance;
    }

    /*
     * Gets the private 'translation.loader.csv' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\CsvFileLoader
     */
    protected function getTranslation_Loader_CsvService()
    {
        return $this->privates['translation.loader.csv'] = new \Symfony\Component\Translation\Loader\CsvFileLoader();
    }

    /*
     * Gets the private 'translation.loader.dat' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\IcuDatFileLoader
     */
    protected function getTranslation_Loader_DatService()
    {
        return $this->privates['translation.loader.dat'] = new \Symfony\Component\Translation\Loader\IcuDatFileLoader();
    }

    /*
     * Gets the private 'translation.loader.ini' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\IniFileLoader
     */
    protected function getTranslation_Loader_IniService()
    {
        return $this->privates['translation.loader.ini'] = new \Symfony\Component\Translation\Loader\IniFileLoader();
    }

    /*
     * Gets the private 'translation.loader.json' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\JsonFileLoader
     */
    protected function getTranslation_Loader_JsonService()
    {
        return $this->privates['translation.loader.json'] = new \Symfony\Component\Translation\Loader\JsonFileLoader();
    }

    /*
     * Gets the private 'translation.loader.mo' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\MoFileLoader
     */
    protected function getTranslation_Loader_MoService()
    {
        return $this->privates['translation.loader.mo'] = new \Symfony\Component\Translation\Loader\MoFileLoader();
    }

    /*
     * Gets the private 'translation.loader.php' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\PhpFileLoader
     */
    protected function getTranslation_Loader_PhpService()
    {
        return $this->privates['translation.loader.php'] = new \Symfony\Component\Translation\Loader\PhpFileLoader();
    }

    /*
     * Gets the private 'translation.loader.po' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\PoFileLoader
     */
    protected function getTranslation_Loader_PoService()
    {
        return $this->privates['translation.loader.po'] = new \Symfony\Component\Translation\Loader\PoFileLoader();
    }

    /*
     * Gets the private 'translation.loader.qt' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\QtFileLoader
     */
    protected function getTranslation_Loader_QtService()
    {
        return $this->privates['translation.loader.qt'] = new \Symfony\Component\Translation\Loader\QtFileLoader();
    }

    /*
     * Gets the private 'translation.loader.res' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\IcuResFileLoader
     */
    protected function getTranslation_Loader_ResService()
    {
        return $this->privates['translation.loader.res'] = new \Symfony\Component\Translation\Loader\IcuResFileLoader();
    }

    /*
     * Gets the private 'translation.loader.xliff' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\XliffFileLoader
     */
    protected function getTranslation_Loader_XliffService()
    {
        return $this->privates['translation.loader.xliff'] = new \Symfony\Component\Translation\Loader\XliffFileLoader();
    }

    /*
     * Gets the private 'translation.loader.yml' shared service.
     *
     * @return \Symfony\Component\Translation\Loader\YamlFileLoader
     */
    protected function getTranslation_Loader_YmlService()
    {
        return $this->privates['translation.loader.yml'] = new \Symfony\Component\Translation\Loader\YamlFileLoader();
    }

    /*
     * Gets the private 'translation.reader' shared service.
     *
     * @return \Symfony\Component\Translation\Reader\TranslationReader
     */
    protected function getTranslation_ReaderService()
    {
        $this->privates['translation.reader'] = $instance = new \Symfony\Component\Translation\Reader\TranslationReader();

        $a = ($this->privates['translation.loader.yml'] ?? ($this->privates['translation.loader.yml'] = new \Symfony\Component\Translation\Loader\YamlFileLoader()));
        $b = ($this->privates['translation.loader.xliff'] ?? ($this->privates['translation.loader.xliff'] = new \Symfony\Component\Translation\Loader\XliffFileLoader()));

        $instance->addLoader('php', ($this->privates['translation.loader.php'] ?? ($this->privates['translation.loader.php'] = new \Symfony\Component\Translation\Loader\PhpFileLoader())));
        $instance->addLoader('yaml', $a);
        $instance->addLoader('yml', $a);
        $instance->addLoader('xlf', $b);
        $instance->addLoader('xliff', $b);
        $instance->addLoader('po', ($this->privates['translation.loader.po'] ?? ($this->privates['translation.loader.po'] = new \Symfony\Component\Translation\Loader\PoFileLoader())));
        $instance->addLoader('mo', ($this->privates['translation.loader.mo'] ?? ($this->privates['translation.loader.mo'] = new \Symfony\Component\Translation\Loader\MoFileLoader())));
        $instance->addLoader('ts', ($this->privates['translation.loader.qt'] ?? ($this->privates['translation.loader.qt'] = new \Symfony\Component\Translation\Loader\QtFileLoader())));
        $instance->addLoader('csv', ($this->privates['translation.loader.csv'] ?? ($this->privates['translation.loader.csv'] = new \Symfony\Component\Translation\Loader\CsvFileLoader())));
        $instance->addLoader('res', ($this->privates['translation.loader.res'] ?? ($this->privates['translation.loader.res'] = new \Symfony\Component\Translation\Loader\IcuResFileLoader())));
        $instance->addLoader('dat', ($this->privates['translation.loader.dat'] ?? ($this->privates['translation.loader.dat'] = new \Symfony\Component\Translation\Loader\IcuDatFileLoader())));
        $instance->addLoader('ini', ($this->privates['translation.loader.ini'] ?? ($this->privates['translation.loader.ini'] = new \Symfony\Component\Translation\Loader\IniFileLoader())));
        $instance->addLoader('json', ($this->privates['translation.loader.json'] ?? ($this->privates['translation.loader.json'] = new \Symfony\Component\Translation\Loader\JsonFileLoader())));

        return $instance;
    }

    /*
     * Gets the private 'translation.warmer' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\CacheWarmer\TranslationsCacheWarmer
     */
    protected function getTranslation_WarmerService()
    {
        return $this->privates['translation.warmer'] = new \Symfony\Bundle\FrameworkBundle\CacheWarmer\TranslationsCacheWarmer((new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'translator' => ['services', 'translator', 'getTranslatorService', false],
        ], [
            'translator' => '?',
        ]))->withContext('translation.warmer', $this));
    }

    /*
     * Gets the private 'twig.command.debug' shared service.
     *
     * @return \Symfony\Bridge\Twig\Command\DebugCommand
     */
    protected function getTwig_Command_DebugService()
    {
        $this->privates['twig.command.debug'] = $instance = new \Symfony\Bridge\Twig\Command\DebugCommand(($this->services['twig'] ?? $this->getTwigService()), \dirname(__DIR__, 4), $this->parameters['kernel.bundles_metadata'], (\dirname(__DIR__, 4).'/templates'), ($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))), (\dirname(__DIR__, 4).'/src'));

        $instance->setName('debug:twig');

        return $instance;
    }

    /*
     * Gets the private 'twig.command.lint' shared service.
     *
     * @return \Symfony\Bundle\TwigBundle\Command\LintCommand
     */
    protected function getTwig_Command_LintService()
    {
        $this->privates['twig.command.lint'] = $instance = new \Symfony\Bundle\TwigBundle\Command\LintCommand(($this->services['twig'] ?? $this->getTwigService()));

        $instance->setName('lint:twig');

        return $instance;
    }

    /*
     * Gets the private 'twig.form.renderer' shared service.
     *
     * @return \Symfony\Component\Form\FormRenderer
     */
    protected function getTwig_Form_RendererService()
    {
        return $this->privates['twig.form.renderer'] = new \Symfony\Component\Form\FormRenderer(new \Symfony\Bridge\Twig\Form\TwigRendererEngine($this->parameters['twig.form.resources'], ($this->services['twig'] ?? $this->getTwigService())), ($this->services['security.csrf.token_manager'] ?? $this->getSecurity_Csrf_TokenManagerService()));
    }

    /*
     * Gets the private 'twig.mailer.message_listener' shared service.
     *
     * @return \Symfony\Component\Mailer\EventListener\MessageListener
     */
    protected function getTwig_Mailer_MessageListenerService()
    {
        return $this->privates['twig.mailer.message_listener'] = new \Symfony\Component\Mailer\EventListener\MessageListener(NULL, new \Symfony\Bridge\Twig\Mime\BodyRenderer(($this->services['twig'] ?? $this->getTwigService())));
    }

    /*
     * Gets the private 'twig.runtime.httpkernel' shared service.
     *
     * @return \Symfony\Bridge\Twig\Extension\HttpKernelRuntime
     */
    protected function getTwig_Runtime_HttpkernelService()
    {
        return $this->privates['twig.runtime.httpkernel'] = new \Symfony\Bridge\Twig\Extension\HttpKernelRuntime(new \Symfony\Component\HttpKernel\DependencyInjection\LazyLoadingFragmentHandler(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'inline' => ['privates', 'fragment.renderer.inline', 'getFragment_Renderer_InlineService', false],
        ], [
            'inline' => '?',
        ]), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), false));
    }

    /*
     * Gets the private 'twig.runtime.security_csrf' shared service.
     *
     * @return \Symfony\Bridge\Twig\Extension\CsrfRuntime
     */
    protected function getTwig_Runtime_SecurityCsrfService()
    {
        return $this->privates['twig.runtime.security_csrf'] = new \Symfony\Bridge\Twig\Extension\CsrfRuntime(($this->services['security.csrf.token_manager'] ?? $this->getSecurity_Csrf_TokenManagerService()));
    }

    /*
     * Gets the private 'twig.template_cache_warmer' shared service.
     *
     * @return \Symfony\Bundle\TwigBundle\CacheWarmer\TemplateCacheWarmer
     */
    protected function getTwig_TemplateCacheWarmerService()
    {
        return $this->privates['twig.template_cache_warmer'] = new \Symfony\Bundle\TwigBundle\CacheWarmer\TemplateCacheWarmer((new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'twig' => ['services', 'twig', 'getTwigService', false],
        ], [
            'twig' => 'Twig\\Environment',
        ]))->withContext('twig.template_cache_warmer', $this), new \Symfony\Bundle\TwigBundle\TemplateIterator(($this->services['kernel'] ?? $this->get('kernel', 1)), (\dirname(__DIR__, 4).'/src'), [(\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Email') => 'email', (\dirname(__DIR__, 4).'/vendor/symfony/twig-bridge/Resources/views/Form') => NULL], (\dirname(__DIR__, 4).'/templates')));
    }

    /*
     * Gets the private 'validator.builder' shared service.
     *
     * @return \Symfony\Component\Validator\ValidatorBuilder
     */
    protected function getValidator_BuilderService()
    {
        $this->privates['validator.builder'] = $instance = \Symfony\Component\Validator\Validation::createValidatorBuilder();

        $a = ($this->privates['property_info.cache'] ?? $this->getPropertyInfo_CacheService());

        $instance->setConstraintValidatorFactory(new \Symfony\Component\Validator\ContainerConstraintValidatorFactory(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'Symfony\\Bridge\\Doctrine\\Validator\\Constraints\\UniqueEntityValidator' => ['privates', 'doctrine.orm.validator.unique', 'getDoctrine_Orm_Validator_UniqueService', false],
            'Symfony\\Component\\Security\\Core\\Validator\\Constraints\\UserPasswordValidator' => ['privates', 'security.validator.user_password', 'getSecurity_Validator_UserPasswordService', false],
            'Symfony\\Component\\Validator\\Constraints\\EmailValidator' => ['privates', 'validator.email', 'getValidator_EmailService', false],
            'Symfony\\Component\\Validator\\Constraints\\ExpressionValidator' => ['privates', 'validator.expression', 'getValidator_ExpressionService', false],
            'Symfony\\Component\\Validator\\Constraints\\NotCompromisedPasswordValidator' => ['privates', 'validator.not_compromised_password', 'getValidator_NotCompromisedPasswordService', false],
            'doctrine.orm.validator.unique' => ['privates', 'doctrine.orm.validator.unique', 'getDoctrine_Orm_Validator_UniqueService', false],
            'security.validator.user_password' => ['privates', 'security.validator.user_password', 'getSecurity_Validator_UserPasswordService', false],
            'validator.expression' => ['privates', 'validator.expression', 'getValidator_ExpressionService', false],
        ], [
            'Symfony\\Bridge\\Doctrine\\Validator\\Constraints\\UniqueEntityValidator' => '?',
            'Symfony\\Component\\Security\\Core\\Validator\\Constraints\\UserPasswordValidator' => '?',
            'Symfony\\Component\\Validator\\Constraints\\EmailValidator' => '?',
            'Symfony\\Component\\Validator\\Constraints\\ExpressionValidator' => '?',
            'Symfony\\Component\\Validator\\Constraints\\NotCompromisedPasswordValidator' => '?',
            'doctrine.orm.validator.unique' => '?',
            'security.validator.user_password' => '?',
            'validator.expression' => '?',
        ])));
        $instance->setTranslator(new \Symfony\Component\Validator\Util\LegacyTranslatorProxy(($this->services['translator'] ?? $this->getTranslatorService())));
        $instance->setTranslationDomain('validators');
        $instance->addXmlMappings([0 => (\dirname(__DIR__, 4).'/vendor/symfony/form/Resources/config/validation.xml')]);
        $instance->enableAnnotationMapping(($this->privates['annotations.cached_reader'] ?? $this->getAnnotations_CachedReaderService()));
        $instance->addMethodMapping('loadValidatorMetadata');
        $instance->setMappingCache(\Symfony\Component\Cache\Adapter\PhpArrayAdapter::create(($this->targetDir.''.'/validation.php'), ($this->privates['cache.validator'] ?? $this->getCache_ValidatorService())));
        $instance->addObjectInitializers([0 => new \Symfony\Bridge\Doctrine\Validator\DoctrineInitializer(($this->services['doctrine'] ?? $this->getDoctrineService()))]);
        $instance->addLoader(new \Symfony\Component\Validator\Mapping\Loader\PropertyInfoLoader($a, $a, $a, NULL));
        $instance->addLoader(new \Symfony\Bridge\Doctrine\Validator\DoctrineLoader(($this->services['doctrine.orm.default_entity_manager'] ?? $this->getDoctrine_Orm_DefaultEntityManagerService()), NULL));

        return $instance;
    }

    /*
     * Gets the private 'validator.email' shared service.
     *
     * @return \Symfony\Component\Validator\Constraints\EmailValidator
     */
    protected function getValidator_EmailService()
    {
        return $this->privates['validator.email'] = new \Symfony\Component\Validator\Constraints\EmailValidator('html5');
    }

    /*
     * Gets the private 'validator.expression' shared service.
     *
     * @return \Symfony\Component\Validator\Constraints\ExpressionValidator
     */
    protected function getValidator_ExpressionService()
    {
        return $this->privates['validator.expression'] = new \Symfony\Component\Validator\Constraints\ExpressionValidator();
    }

    /*
     * Gets the private 'validator.mapping.cache_warmer' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\CacheWarmer\ValidatorCacheWarmer
     */
    protected function getValidator_Mapping_CacheWarmerService()
    {
        return $this->privates['validator.mapping.cache_warmer'] = new \Symfony\Bundle\FrameworkBundle\CacheWarmer\ValidatorCacheWarmer(($this->privates['validator.builder'] ?? $this->getValidator_BuilderService()), ($this->targetDir.''.'/validation.php'));
    }

    /*
     * Gets the private 'validator.not_compromised_password' shared service.
     *
     * @return \Symfony\Component\Validator\Constraints\NotCompromisedPasswordValidator
     */
    protected function getValidator_NotCompromisedPasswordService()
    {
        return $this->privates['validator.not_compromised_password'] = new \Symfony\Component\Validator\Constraints\NotCompromisedPasswordValidator(($this->privates['http_client'] ?? $this->getHttpClientService()), 'UTF-8', true, NULL);
    }

    /**
     * @return array|bool|float|int|string|null
     */
    public function getParameter($name)
    {
        $name = (string) $name;
        if (isset($this->buildParameters[$name])) {
            return $this->buildParameters[$name];
        }

        if (!(isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters))) {
            throw new InvalidArgumentException(sprintf('The parameter "%s" must be defined.', $name));
        }
        if (isset($this->loadedDynamicParameters[$name])) {
            return $this->loadedDynamicParameters[$name] ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
        }

        return $this->parameters[$name];
    }

    public function hasParameter($name): bool
    {
        $name = (string) $name;
        if (isset($this->buildParameters[$name])) {
            return true;
        }

        return isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters);
    }

    public function setParameter($name, $value): void
    {
        throw new LogicException('Impossible to call set() on a frozen ParameterBag.');
    }

    public function getParameterBag(): ParameterBagInterface
    {
        if (null === $this->parameterBag) {
            $parameters = $this->parameters;
            foreach ($this->loadedDynamicParameters as $name => $loaded) {
                $parameters[$name] = $loaded ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
            }
            foreach ($this->buildParameters as $name => $value) {
                $parameters[$name] = $value;
            }
            $this->parameterBag = new FrozenParameterBag($parameters);
        }

        return $this->parameterBag;
    }

    private $loadedDynamicParameters = [
        'kernel.cache_dir' => false,
        'app.smstoken' => false,
        'app.mapskey' => false,
        'kernel.secret' => false,
        'session.save_path' => false,
        'validator.mapping.cache.file' => false,
        'serializer.mapping.cache.file' => false,
        'doctrine.orm.proxy_dir' => false,
        'swiftmailer.spool.default.memory.path' => false,
    ];
    private $dynamicParameters = [];

    private function getDynamicParameter(string $name)
    {
        switch ($name) {
            case 'kernel.cache_dir': $value = $this->targetDir.''; break;
            case 'app.smstoken': $value = $this->getEnv('SMS_TOKEN'); break;
            case 'app.mapskey': $value = $this->getEnv('MAPS_API'); break;
            case 'kernel.secret': $value = $this->getEnv('APP_SECRET'); break;
            case 'session.save_path': $value = ($this->targetDir.''.'/sessions'); break;
            case 'validator.mapping.cache.file': $value = ($this->targetDir.''.'/validation.php'); break;
            case 'serializer.mapping.cache.file': $value = ($this->targetDir.''.'/serialization.php'); break;
            case 'doctrine.orm.proxy_dir': $value = ($this->targetDir.''.'/doctrine/orm/Proxies'); break;
            case 'swiftmailer.spool.default.memory.path': $value = ($this->targetDir.''.'/swiftmailer/spool/default'); break;
            default: throw new InvalidArgumentException(sprintf('The dynamic parameter "%s" must be defined.', $name));
        }
        $this->loadedDynamicParameters[$name] = true;

        return $this->dynamicParameters[$name] = $value;
    }

    protected function getDefaultParameters(): array
    {
        return [
            'kernel.root_dir' => (\dirname(__DIR__, 4).'/src'),
            'kernel.project_dir' => \dirname(__DIR__, 4),
            'kernel.environment' => 'prod',
            'kernel.debug' => false,
            'kernel.name' => 'src',
            'kernel.logs_dir' => (\dirname(__DIR__, 3).'/log'),
            'kernel.bundles' => [
                'FrameworkBundle' => 'Symfony\\Bundle\\FrameworkBundle\\FrameworkBundle',
                'SensioFrameworkExtraBundle' => 'Sensio\\Bundle\\FrameworkExtraBundle\\SensioFrameworkExtraBundle',
                'TwigBundle' => 'Symfony\\Bundle\\TwigBundle\\TwigBundle',
                'MonologBundle' => 'Symfony\\Bundle\\MonologBundle\\MonologBundle',
                'DoctrineBundle' => 'Doctrine\\Bundle\\DoctrineBundle\\DoctrineBundle',
                'DoctrineMigrationsBundle' => 'Doctrine\\Bundle\\MigrationsBundle\\DoctrineMigrationsBundle',
                'SecurityBundle' => 'Symfony\\Bundle\\SecurityBundle\\SecurityBundle',
                'TwigExtraBundle' => 'Twig\\Extra\\TwigExtraBundle\\TwigExtraBundle',
                'SymfonyCastsResetPasswordBundle' => 'SymfonyCasts\\Bundle\\ResetPassword\\SymfonyCastsResetPasswordBundle',
                'SwiftmailerBundle' => 'Symfony\\Bundle\\SwiftmailerBundle\\SwiftmailerBundle',
                'StofDoctrineExtensionsBundle' => 'Stof\\DoctrineExtensionsBundle\\StofDoctrineExtensionsBundle',
                'KnpSnappyBundle' => 'Knp\\Bundle\\SnappyBundle\\KnpSnappyBundle',
                'DHAuditorBundle' => 'DH\\AuditorBundle\\DHAuditorBundle',
            ],
            'kernel.bundles_metadata' => [
                'FrameworkBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/symfony/framework-bundle'),
                    'namespace' => 'Symfony\\Bundle\\FrameworkBundle',
                ],
                'SensioFrameworkExtraBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/sensio/framework-extra-bundle/src'),
                    'namespace' => 'Sensio\\Bundle\\FrameworkExtraBundle',
                ],
                'TwigBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/symfony/twig-bundle'),
                    'namespace' => 'Symfony\\Bundle\\TwigBundle',
                ],
                'MonologBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/symfony/monolog-bundle'),
                    'namespace' => 'Symfony\\Bundle\\MonologBundle',
                ],
                'DoctrineBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-bundle'),
                    'namespace' => 'Doctrine\\Bundle\\DoctrineBundle',
                ],
                'DoctrineMigrationsBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/doctrine/doctrine-migrations-bundle'),
                    'namespace' => 'Doctrine\\Bundle\\MigrationsBundle',
                ],
                'SecurityBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/symfony/security-bundle'),
                    'namespace' => 'Symfony\\Bundle\\SecurityBundle',
                ],
                'TwigExtraBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/twig/extra-bundle'),
                    'namespace' => 'Twig\\Extra\\TwigExtraBundle',
                ],
                'SymfonyCastsResetPasswordBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/symfonycasts/reset-password-bundle/src'),
                    'namespace' => 'SymfonyCasts\\Bundle\\ResetPassword',
                ],
                'SwiftmailerBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/symfony/swiftmailer-bundle'),
                    'namespace' => 'Symfony\\Bundle\\SwiftmailerBundle',
                ],
                'StofDoctrineExtensionsBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/stof/doctrine-extensions-bundle/src'),
                    'namespace' => 'Stof\\DoctrineExtensionsBundle',
                ],
                'KnpSnappyBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/knplabs/knp-snappy-bundle/src'),
                    'namespace' => 'Knp\\Bundle\\SnappyBundle',
                ],
                'DHAuditorBundle' => [
                    'path' => (\dirname(__DIR__, 4).'/vendor/damienharper/auditor-bundle/src'),
                    'namespace' => 'DH\\AuditorBundle',
                ],
            ],
            'kernel.charset' => 'UTF-8',
            'kernel.container_class' => 'srcApp_KernelProdContainer',
            'container.dumper.inline_class_loader' => false,
            'container.dumper.inline_factories' => true,
            'event_dispatcher.event_aliases' => [
                'Symfony\\Component\\Console\\Event\\ConsoleCommandEvent' => 'console.command',
                'Symfony\\Component\\Console\\Event\\ConsoleErrorEvent' => 'console.error',
                'Symfony\\Component\\Console\\Event\\ConsoleTerminateEvent' => 'console.terminate',
                'Symfony\\Component\\Form\\Event\\PreSubmitEvent' => 'form.pre_submit',
                'Symfony\\Component\\Form\\Event\\SubmitEvent' => 'form.submit',
                'Symfony\\Component\\Form\\Event\\PostSubmitEvent' => 'form.post_submit',
                'Symfony\\Component\\Form\\Event\\PreSetDataEvent' => 'form.pre_set_data',
                'Symfony\\Component\\Form\\Event\\PostSetDataEvent' => 'form.post_set_data',
                'Symfony\\Component\\HttpKernel\\Event\\ControllerArgumentsEvent' => 'kernel.controller_arguments',
                'Symfony\\Component\\HttpKernel\\Event\\ControllerEvent' => 'kernel.controller',
                'Symfony\\Component\\HttpKernel\\Event\\ResponseEvent' => 'kernel.response',
                'Symfony\\Component\\HttpKernel\\Event\\FinishRequestEvent' => 'kernel.finish_request',
                'Symfony\\Component\\HttpKernel\\Event\\RequestEvent' => 'kernel.request',
                'Symfony\\Component\\HttpKernel\\Event\\ViewEvent' => 'kernel.view',
                'Symfony\\Component\\HttpKernel\\Event\\ExceptionEvent' => 'kernel.exception',
                'Symfony\\Component\\HttpKernel\\Event\\TerminateEvent' => 'kernel.terminate',
                'Symfony\\Component\\Workflow\\Event\\GuardEvent' => 'workflow.guard',
                'Symfony\\Component\\Workflow\\Event\\LeaveEvent' => 'workflow.leave',
                'Symfony\\Component\\Workflow\\Event\\TransitionEvent' => 'workflow.transition',
                'Symfony\\Component\\Workflow\\Event\\EnterEvent' => 'workflow.enter',
                'Symfony\\Component\\Workflow\\Event\\EnteredEvent' => 'workflow.entered',
                'Symfony\\Component\\Workflow\\Event\\CompletedEvent' => 'workflow.completed',
                'Symfony\\Component\\Workflow\\Event\\AnnounceEvent' => 'workflow.announce',
                'Symfony\\Component\\Security\\Core\\Event\\AuthenticationSuccessEvent' => 'security.authentication.success',
                'Symfony\\Component\\Security\\Core\\Event\\AuthenticationFailureEvent' => 'security.authentication.failure',
                'Symfony\\Component\\Security\\Http\\Event\\InteractiveLoginEvent' => 'security.interactive_login',
                'Symfony\\Component\\Security\\Http\\Event\\SwitchUserEvent' => 'security.switch_user',
            ],
            'fragment.renderer.hinclude.global_template' => '',
            'fragment.path' => '/_fragment',
            'kernel.http_method_override' => true,
            'kernel.trusted_hosts' => [

            ],
            'kernel.default_locale' => 'pl',
            'kernel.error_controller' => 'error_controller',
            'templating.helper.code.file_link_format' => NULL,
            'debug.file_link_format' => NULL,
            'session.metadata.storage_key' => '_sf2_meta',
            'session.storage.options' => [
                'cache_limiter' => '0',
                'cookie_secure' => 'auto',
                'cookie_httponly' => true,
                'cookie_samesite' => 'lax',
                'gc_probability' => 1,
            ],
            'session.metadata.update_threshold' => 0,
            'form.type_extension.csrf.enabled' => true,
            'form.type_extension.csrf.field_name' => '_token',
            'asset.request_context.base_path' => '',
            'asset.request_context.secure' => false,
            'validator.translation_domain' => 'validators',
            'translator.logging' => false,
            'translator.default_path' => (\dirname(__DIR__, 4).'/translations'),
            'data_collector.templates' => [

            ],
            'debug.error_handler.throw_at' => 0,
            'router.request_context.host' => 'localhost',
            'router.request_context.scheme' => 'http',
            'router.request_context.base_url' => '',
            'router.resource' => 'kernel::loadRoutes',
            'router.cache_class_prefix' => 'srcApp_KernelProdContainer',
            'request_listener.http_port' => 80,
            'request_listener.https_port' => 443,
            'twig.exception_listener.controller' => NULL,
            'twig.form.resources' => [
                0 => 'form_div_layout.html.twig',
            ],
            'twig.default_path' => (\dirname(__DIR__, 4).'/templates'),
            'monolog.use_microseconds' => true,
            'monolog.swift_mailer.handlers' => [

            ],
            'monolog.handlers_to_channels' => [
                'monolog.handler.console' => [
                    'type' => 'exclusive',
                    'elements' => [
                        0 => 'event',
                        1 => 'doctrine',
                    ],
                ],
                'monolog.handler.main' => NULL,
            ],
            'doctrine.dbal.logger.chain.class' => 'Doctrine\\DBAL\\Logging\\LoggerChain',
            'doctrine.dbal.logger.profiling.class' => 'Doctrine\\DBAL\\Logging\\DebugStack',
            'doctrine.dbal.logger.class' => 'Symfony\\Bridge\\Doctrine\\Logger\\DbalLogger',
            'doctrine.dbal.configuration.class' => 'Doctrine\\DBAL\\Configuration',
            'doctrine.data_collector.class' => 'Doctrine\\Bundle\\DoctrineBundle\\DataCollector\\DoctrineDataCollector',
            'doctrine.dbal.connection.event_manager.class' => 'Symfony\\Bridge\\Doctrine\\ContainerAwareEventManager',
            'doctrine.dbal.connection_factory.class' => 'Doctrine\\Bundle\\DoctrineBundle\\ConnectionFactory',
            'doctrine.dbal.events.mysql_session_init.class' => 'Doctrine\\DBAL\\Event\\Listeners\\MysqlSessionInit',
            'doctrine.dbal.events.oracle_session_init.class' => 'Doctrine\\DBAL\\Event\\Listeners\\OracleSessionInit',
            'doctrine.class' => 'Doctrine\\Bundle\\DoctrineBundle\\Registry',
            'doctrine.entity_managers' => [
                'default' => 'doctrine.orm.default_entity_manager',
            ],
            'doctrine.default_entity_manager' => 'default',
            'doctrine.dbal.connection_factory.types' => [

            ],
            'doctrine.connections' => [
                'default' => 'doctrine.dbal.default_connection',
            ],
            'doctrine.default_connection' => 'default',
            'doctrine.orm.configuration.class' => 'Doctrine\\ORM\\Configuration',
            'doctrine.orm.entity_manager.class' => 'Doctrine\\ORM\\EntityManager',
            'doctrine.orm.manager_configurator.class' => 'Doctrine\\Bundle\\DoctrineBundle\\ManagerConfigurator',
            'doctrine.orm.cache.array.class' => 'Doctrine\\Common\\Cache\\ArrayCache',
            'doctrine.orm.cache.apc.class' => 'Doctrine\\Common\\Cache\\ApcCache',
            'doctrine.orm.cache.memcache.class' => 'Doctrine\\Common\\Cache\\MemcacheCache',
            'doctrine.orm.cache.memcache_host' => 'localhost',
            'doctrine.orm.cache.memcache_port' => 11211,
            'doctrine.orm.cache.memcache_instance.class' => 'Memcache',
            'doctrine.orm.cache.memcached.class' => 'Doctrine\\Common\\Cache\\MemcachedCache',
            'doctrine.orm.cache.memcached_host' => 'localhost',
            'doctrine.orm.cache.memcached_port' => 11211,
            'doctrine.orm.cache.memcached_instance.class' => 'Memcached',
            'doctrine.orm.cache.redis.class' => 'Doctrine\\Common\\Cache\\RedisCache',
            'doctrine.orm.cache.redis_host' => 'localhost',
            'doctrine.orm.cache.redis_port' => 6379,
            'doctrine.orm.cache.redis_instance.class' => 'Redis',
            'doctrine.orm.cache.xcache.class' => 'Doctrine\\Common\\Cache\\XcacheCache',
            'doctrine.orm.cache.wincache.class' => 'Doctrine\\Common\\Cache\\WinCacheCache',
            'doctrine.orm.cache.zenddata.class' => 'Doctrine\\Common\\Cache\\ZendDataCache',
            'doctrine.orm.metadata.driver_chain.class' => 'Doctrine\\Persistence\\Mapping\\Driver\\MappingDriverChain',
            'doctrine.orm.metadata.annotation.class' => 'Doctrine\\ORM\\Mapping\\Driver\\AnnotationDriver',
            'doctrine.orm.metadata.xml.class' => 'Doctrine\\ORM\\Mapping\\Driver\\SimplifiedXmlDriver',
            'doctrine.orm.metadata.yml.class' => 'Doctrine\\ORM\\Mapping\\Driver\\SimplifiedYamlDriver',
            'doctrine.orm.metadata.php.class' => 'Doctrine\\ORM\\Mapping\\Driver\\PHPDriver',
            'doctrine.orm.metadata.staticphp.class' => 'Doctrine\\ORM\\Mapping\\Driver\\StaticPHPDriver',
            'doctrine.orm.proxy_cache_warmer.class' => 'Symfony\\Bridge\\Doctrine\\CacheWarmer\\ProxyCacheWarmer',
            'form.type_guesser.doctrine.class' => 'Symfony\\Bridge\\Doctrine\\Form\\DoctrineOrmTypeGuesser',
            'doctrine.orm.validator.unique.class' => 'Symfony\\Bridge\\Doctrine\\Validator\\Constraints\\UniqueEntityValidator',
            'doctrine.orm.validator_initializer.class' => 'Symfony\\Bridge\\Doctrine\\Validator\\DoctrineInitializer',
            'doctrine.orm.security.user.provider.class' => 'Symfony\\Bridge\\Doctrine\\Security\\User\\EntityUserProvider',
            'doctrine.orm.listeners.resolve_target_entity.class' => 'Doctrine\\ORM\\Tools\\ResolveTargetEntityListener',
            'doctrine.orm.listeners.attach_entity_listeners.class' => 'Doctrine\\ORM\\Tools\\AttachEntityListenersListener',
            'doctrine.orm.naming_strategy.default.class' => 'Doctrine\\ORM\\Mapping\\DefaultNamingStrategy',
            'doctrine.orm.naming_strategy.underscore.class' => 'Doctrine\\ORM\\Mapping\\UnderscoreNamingStrategy',
            'doctrine.orm.quote_strategy.default.class' => 'Doctrine\\ORM\\Mapping\\DefaultQuoteStrategy',
            'doctrine.orm.quote_strategy.ansi.class' => 'Doctrine\\ORM\\Mapping\\AnsiQuoteStrategy',
            'doctrine.orm.entity_listener_resolver.class' => 'Doctrine\\Bundle\\DoctrineBundle\\Mapping\\ContainerEntityListenerResolver',
            'doctrine.orm.second_level_cache.default_cache_factory.class' => 'Doctrine\\ORM\\Cache\\DefaultCacheFactory',
            'doctrine.orm.second_level_cache.default_region.class' => 'Doctrine\\ORM\\Cache\\Region\\DefaultRegion',
            'doctrine.orm.second_level_cache.filelock_region.class' => 'Doctrine\\ORM\\Cache\\Region\\FileLockRegion',
            'doctrine.orm.second_level_cache.logger_chain.class' => 'Doctrine\\ORM\\Cache\\Logging\\CacheLoggerChain',
            'doctrine.orm.second_level_cache.logger_statistics.class' => 'Doctrine\\ORM\\Cache\\Logging\\StatisticsCacheLogger',
            'doctrine.orm.second_level_cache.cache_configuration.class' => 'Doctrine\\ORM\\Cache\\CacheConfiguration',
            'doctrine.orm.second_level_cache.regions_configuration.class' => 'Doctrine\\ORM\\Cache\\RegionsConfiguration',
            'doctrine.orm.auto_generate_proxy_classes' => false,
            'doctrine.orm.proxy_namespace' => 'Proxies',
            'doctrine.migrations.preferred_em' => NULL,
            'doctrine.migrations.preferred_connection' => NULL,
            'security.authentication.trust_resolver.anonymous_class' => NULL,
            'security.authentication.trust_resolver.rememberme_class' => NULL,
            'security.role_hierarchy.roles' => [
                'ROLE_ADMIN' => [
                    0 => 'ROLE_ADMIN',
                    1 => 'ROLE_MANAGER',
                    2 => 'ROLE_TRANSPORT',
                ],
                'ROLE_TRANSPORT' => [
                    0 => 'ROLE_USER',
                ],
                'ROLE_MANAGER' => [
                    0 => 'ROLE_MANAGER',
                    1 => 'ROLE_PRODUCTION',
                ],
                'ROLE_PRODUCTION' => [
                    0 => 'ROLE_PRODUCTION',
                    1 => 'ROLE_USER',
                ],
                'ROLE_USER' => [
                    0 => 'ROLE_USER',
                ],
            ],
            'security.access.denied_url' => NULL,
            'security.authentication.manager.erase_credentials' => true,
            'security.authentication.session_strategy.strategy' => 'migrate',
            'security.access.always_authenticate_before_granting' => false,
            'security.authentication.hide_user_not_found' => true,
            'swiftmailer.mailer.default.transport.name' => 'dynamic',
            'swiftmailer.mailer.default.spool.enabled' => true,
            'swiftmailer.mailer.default.plugin.impersonate' => NULL,
            'swiftmailer.mailer.default.single_address' => NULL,
            'swiftmailer.mailer.default.delivery.enabled' => true,
            'swiftmailer.spool.enabled' => true,
            'swiftmailer.delivery.enabled' => true,
            'swiftmailer.single_address' => NULL,
            'swiftmailer.mailers' => [
                'default' => 'swiftmailer.mailer.default',
            ],
            'swiftmailer.default_mailer' => 'default',
            'stof_doctrine_extensions.default_locale' => 'en_US',
            'stof_doctrine_extensions.translation_fallback' => false,
            'stof_doctrine_extensions.persist_default_translation' => false,
            'stof_doctrine_extensions.skip_translation_on_load' => false,
            'stof_doctrine_extensions.listener.translatable.class' => 'Gedmo\\Translatable\\TranslatableListener',
            'stof_doctrine_extensions.listener.timestampable.class' => 'Gedmo\\Timestampable\\TimestampableListener',
            'stof_doctrine_extensions.listener.blameable.class' => 'Gedmo\\Blameable\\BlameableListener',
            'stof_doctrine_extensions.listener.sluggable.class' => 'Gedmo\\Sluggable\\SluggableListener',
            'stof_doctrine_extensions.listener.tree.class' => 'Gedmo\\Tree\\TreeListener',
            'stof_doctrine_extensions.listener.loggable.class' => 'Gedmo\\Loggable\\LoggableListener',
            'stof_doctrine_extensions.listener.sortable.class' => 'Gedmo\\Sortable\\SortableListener',
            'stof_doctrine_extensions.listener.softdeleteable.class' => 'Gedmo\\SoftDeleteable\\SoftDeleteableListener',
            'stof_doctrine_extensions.listener.uploadable.class' => 'Gedmo\\Uploadable\\UploadableListener',
            'stof_doctrine_extensions.listener.reference_integrity.class' => 'Gedmo\\ReferenceIntegrity\\ReferenceIntegrityListener',
            'knp_snappy.pdf.binary' => '/usr/bin/wkhtmltopdf',
            'knp_snappy.pdf.options' => [

            ],
            'knp_snappy.pdf.env' => [

            ],
            'knp_snappy.image.binary' => '/var/wkhtmltoimage',
            'knp_snappy.image.options' => [

            ],
            'knp_snappy.image.env' => [

            ],
            'dh_auditor.configuration' => [
                'timezone' => 'Europe/Warsaw',
                'enabled' => true,
                'user_provider' => 'dh_auditor.user_provider',
                'security_provider' => 'dh_auditor.security_provider',
                'role_checker' => 'dh_auditor.role_checker',
            ],
            'dh_auditor.provider.doctrine.configuration' => [
                'table_prefix' => '',
                'table_suffix' => '_audit',
                'viewer' => true,
                'storage_services' => [
                    0 => 'doctrine.orm.default_entity_manager',
                ],
                'auditing_services' => [
                    0 => 'doctrine.orm.default_entity_manager',
                ],
                'storage_mapper' => NULL,
            ],
            'console.command.ids' => [

            ],
        ];
    }

    protected function throw($message)
    {
        throw new RuntimeException($message);
    }
}

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    private $valueHolderf338b = null;
    private $initializeradc29 = null;
    private static $publicPropertiesef6c4 = [
        
    ];
    public function getConnection()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getConnection', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getConnection();
    }
    public function getMetadataFactory()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getMetadataFactory', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getMetadataFactory();
    }
    public function getExpressionBuilder()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getExpressionBuilder', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getExpressionBuilder();
    }
    public function beginTransaction()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'beginTransaction', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->beginTransaction();
    }
    public function getCache()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getCache', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getCache();
    }
    public function transactional($func)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'transactional', array('func' => $func), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->transactional($func);
    }
    public function commit()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'commit', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->commit();
    }
    public function rollback()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'rollback', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->rollback();
    }
    public function getClassMetadata($className)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getClassMetadata', array('className' => $className), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getClassMetadata($className);
    }
    public function createQuery($dql = '')
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'createQuery', array('dql' => $dql), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->createQuery($dql);
    }
    public function createNamedQuery($name)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'createNamedQuery', array('name' => $name), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->createNamedQuery($name);
    }
    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->createNativeQuery($sql, $rsm);
    }
    public function createNamedNativeQuery($name)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->createNamedNativeQuery($name);
    }
    public function createQueryBuilder()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'createQueryBuilder', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->createQueryBuilder();
    }
    public function flush($entity = null)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'flush', array('entity' => $entity), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->flush($entity);
    }
    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->find($className, $id, $lockMode, $lockVersion);
    }
    public function getReference($entityName, $id)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getReference($entityName, $id);
    }
    public function getPartialReference($entityName, $identifier)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getPartialReference($entityName, $identifier);
    }
    public function clear($entityName = null)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'clear', array('entityName' => $entityName), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->clear($entityName);
    }
    public function close()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'close', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->close();
    }
    public function persist($entity)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'persist', array('entity' => $entity), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->persist($entity);
    }
    public function remove($entity)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'remove', array('entity' => $entity), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->remove($entity);
    }
    public function refresh($entity)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'refresh', array('entity' => $entity), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->refresh($entity);
    }
    public function detach($entity)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'detach', array('entity' => $entity), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->detach($entity);
    }
    public function merge($entity)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'merge', array('entity' => $entity), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->merge($entity);
    }
    public function copy($entity, $deep = false)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->copy($entity, $deep);
    }
    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->lock($entity, $lockMode, $lockVersion);
    }
    public function getRepository($entityName)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getRepository', array('entityName' => $entityName), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getRepository($entityName);
    }
    public function contains($entity)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'contains', array('entity' => $entity), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->contains($entity);
    }
    public function getEventManager()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getEventManager', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getEventManager();
    }
    public function getConfiguration()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getConfiguration', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getConfiguration();
    }
    public function isOpen()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'isOpen', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->isOpen();
    }
    public function getUnitOfWork()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getUnitOfWork', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getUnitOfWork();
    }
    public function getHydrator($hydrationMode)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getHydrator($hydrationMode);
    }
    public function newHydrator($hydrationMode)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->newHydrator($hydrationMode);
    }
    public function getProxyFactory()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getProxyFactory', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getProxyFactory();
    }
    public function initializeObject($obj)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'initializeObject', array('obj' => $obj), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->initializeObject($obj);
    }
    public function getFilters()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'getFilters', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->getFilters();
    }
    public function isFiltersStateClean()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'isFiltersStateClean', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->isFiltersStateClean();
    }
    public function hasFilters()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'hasFilters', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return $this->valueHolderf338b->hasFilters();
    }
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;
        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);
        $instance->initializeradc29 = $initializer;
        return $instance;
    }
    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;
        if (! $this->valueHolderf338b) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderf338b = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
        }
        $this->valueHolderf338b->__construct($conn, $config, $eventManager);
    }
    public function & __get($name)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, '__get', ['name' => $name], $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        if (isset(self::$publicPropertiesef6c4[$name])) {
            return $this->valueHolderf338b->$name;
        }
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf338b;
            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }
        $targetObject = $this->valueHolderf338b;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __set($name, $value)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, '__set', array('name' => $name, 'value' => $value), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf338b;
            $targetObject->$name = $value;
            return $targetObject->$name;
        }
        $targetObject = $this->valueHolderf338b;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __isset($name)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, '__isset', array('name' => $name), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf338b;
            return isset($targetObject->$name);
        }
        $targetObject = $this->valueHolderf338b;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();
        return $returnValue;
    }
    public function __unset($name)
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, '__unset', array('name' => $name), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf338b;
            unset($targetObject->$name);
            return;
        }
        $targetObject = $this->valueHolderf338b;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }
    public function __clone()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, '__clone', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        $this->valueHolderf338b = clone $this->valueHolderf338b;
    }
    public function __sleep()
    {
        $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, '__sleep', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
        return array('valueHolderf338b');
    }
    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }
    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializeradc29 = $initializer;
    }
    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializeradc29;
    }
    public function initializeProxy() : bool
    {
        return $this->initializeradc29 && ($this->initializeradc29->__invoke($valueHolderf338b, $this, 'initializeProxy', array(), $this->initializeradc29) || 1) && $this->valueHolderf338b = $valueHolderf338b;
    }
    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderf338b;
    }
    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderf338b;
    }
}
