<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/breed' => [[['_route' => 'breed_index', '_controller' => 'App\\Controller\\BreedController::index'], null, ['GET' => 0], null, true, false, null]],
        '/breed/new' => [[['_route' => 'breed_new', '_controller' => 'App\\Controller\\BreedController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/breed_standard' => [[['_route' => 'breed_standard_index', '_controller' => 'App\\Controller\\BreedStandardController::index'], null, ['GET' => 0], null, true, false, null]],
        '/breed_standard/new' => [[['_route' => 'breed_standard_new', '_controller' => 'App\\Controller\\BreedStandardController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/car' => [[['_route' => 'car_index', '_controller' => 'App\\Controller\\CarController::index'], null, ['GET' => 0], null, true, false, null]],
        '/car/new' => [[['_route' => 'car_new', '_controller' => 'App\\Controller\\CarController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/chick_integration' => [[['_route' => 'chick_integration_index', '_controller' => 'App\\Controller\\ChickIntegrationController::index'], null, ['GET' => 0], null, true, false, null]],
        '/chick_integration/new' => [[['_route' => 'chick_integration_new', '_controller' => 'App\\Controller\\ChickIntegrationController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/chick_temperature' => [[['_route' => 'chick_temperature_index', '_controller' => 'App\\Controller\\ChickTemperatureController::index'], null, ['GET' => 0], null, true, false, null]],
        '/chicks_recipient' => [[['_route' => 'chicks_recipient_index', '_controller' => 'App\\Controller\\ChicksRecipientController::index'], null, ['GET' => 0], null, true, false, null]],
        '/contact_info' => [[['_route' => 'contact_info_index', '_controller' => 'App\\Controller\\ContactInfoController::index'], null, ['GET' => 0], null, true, false, null]],
        '/contact_info/new' => [[['_route' => 'contact_info_new', '_controller' => 'App\\Controller\\ContactInfoController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/customer' => [[['_route' => 'customer_index', '_controller' => 'App\\Controller\\CustomerController::index'], null, ['GET' => 0], null, true, false, null]],
        '/customer/new' => [[['_route' => 'customer_new', '_controller' => 'App\\Controller\\CustomerController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/customer_phone' => [[['_route' => 'customer_phone_index', '_controller' => 'App\\Controller\\CustomerPhoneController::index'], null, ['GET' => 0], null, true, false, null]],
        '/pdf' => [[['_route' => 'app_default_indexpdf', '_controller' => 'App\\Controller\\DefaultController::indexPdf'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'main_page', '_controller' => 'App\\Controller\\DefaultController::index'], null, null, null, false, false, null]],
        '/incubators' => [[['_route' => 'incubators_index', '_controller' => 'App\\Controller\\DefaultController::incubators'], null, null, null, false, false, null]],
        '/delivery' => [[['_route' => 'eggs_delivery_index', '_controller' => 'App\\Controller\\DeliveryController::index'], null, ['GET' => 0], null, true, false, null]],
        '/delivery/all' => [[['_route' => 'eggs_delivery_all_index', '_controller' => 'App\\Controller\\DeliveryController::allDelivery'], null, ['GET' => 0], null, false, false, null]],
        '/delivery/new' => [[['_route' => 'eggs_delivery_new', '_controller' => 'App\\Controller\\DeliveryController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/driver' => [[['_route' => 'driver_index', '_controller' => 'App\\Controller\\DriverController::index'], null, ['GET' => 0], null, true, false, null]],
        '/driver/new' => [[['_route' => 'driver_new', '_controller' => 'App\\Controller\\DriverController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/hatchers' => [[['_route' => 'hatchers_index', '_controller' => 'App\\Controller\\HatchersController::index'], null, ['GET' => 0], null, true, false, null]],
        '/hatchers/new' => [[['_route' => 'hatchers_new', '_controller' => 'App\\Controller\\HatchersController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/herds' => [[['_route' => 'herds_index', '_controller' => 'App\\Controller\\HerdsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/herds/new' => [[['_route' => 'herds_new', '_controller' => 'App\\Controller\\HerdsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/input_delivery' => [[['_route' => 'input_delivery_index', '_controller' => 'App\\Controller\\InputDeliveryController::index'], null, ['GET' => 0], null, true, false, null]],
        '/input_delivery/new' => [[['_route' => 'input_delivery_new', '_controller' => 'App\\Controller\\InputDeliveryController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/inputs' => [[['_route' => 'eggs_inputs_index', '_controller' => 'App\\Controller\\InputsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/inputs/new' => [[['_route' => 'eggs_inputs_new', '_controller' => 'App\\Controller\\InputsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/inputs_farm_delivery_plan' => [[['_route' => 'inputs_farm_delivery_plan_index', '_controller' => 'App\\Controller\\InputsFarmDeliveryPlanController::index'], null, ['GET' => 0], null, true, false, null]],
        '/lighting' => [[['_route' => 'eggs_inputs_lighting_index', '_controller' => 'App\\Controller\\LightingController::index'], null, ['GET' => 0], null, true, false, null]],
        '/lighting/lighting' => [[['_route' => 'no_lighting_index', '_controller' => 'App\\Controller\\LightingController::showNoLighting'], null, ['GET' => 0], null, false, false, null]],
        '/plans' => [[['_route' => 'plan_week', '_controller' => 'App\\Controller\\PlanController::index'], null, ['GET' => 0], null, true, false, null]],
        '/plan_delivery_chick' => [[['_route' => 'plan_delivery_chick_index', '_controller' => 'App\\Controller\\PlanDeliveryChickController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/plan_delivery_chick/new' => [[['_route' => 'plan_delivery_chick_new', '_controller' => 'App\\Controller\\PlanDeliveryChickController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/plan_delivery_egg' => [[['_route' => 'plan_delivery_egg_index', '_controller' => 'App\\Controller\\PlanDeliveryEggController::index'], null, ['GET' => 0], null, true, false, null]],
        '/plan_delivery_egg/new' => [[['_route' => 'plan_delivery_egg_new', '_controller' => 'App\\Controller\\PlanDeliveryEggController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/plan_detail' => [[['_route' => 'plan_detail', '_controller' => 'App\\Controller\\PlanDetailController::index'], null, null, null, false, false, null]],
        '/plans_hatching_date' => [[['_route' => 'plan_hatching_date', '_controller' => 'App\\Controller\\PlanHatchingDateController::index'], null, null, null, true, false, null]],
        '/plan_indicators' => [[['_route' => 'plan_indicators_index', '_controller' => 'App\\Controller\\PlanIndicatorsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/plan_indicators/new' => [[['_route' => 'plan_indicators_new', '_controller' => 'App\\Controller\\PlanIndicatorsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/plan_input' => [[['_route' => 'plan_input_index', '_controller' => 'App\\Controller\\PlanInputController::index'], null, ['GET' => 0], null, true, false, null]],
        '/plan_input/new' => [[['_route' => 'plan_input_new', '_controller' => 'App\\Controller\\PlanInputController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/production/chick_temperature' => [[['_route' => 'production_chick_temperature_index', '_controller' => 'App\\Controller\\Production\\ProductionChickTemperatureController::chickTemperatureSite'], null, null, null, false, false, null]],
        '/production' => [[['_route' => 'production_index', '_controller' => 'App\\Controller\\Production\\ProductionController::productionSite'], null, null, null, true, false, null]],
        '/production/delivery/supplier' => [[['_route' => 'production_delivery_supplier', '_controller' => 'App\\Controller\\Production\\ProductionDeliveryController::deliverySupplier'], null, null, null, false, false, null]],
        '/production/inputs' => [[['_route' => 'production_inputs_index', '_controller' => 'App\\Controller\\Production\\ProductionInputsController::inputsSite'], null, null, null, false, false, null]],
        '/production/lightings' => [[['_route' => 'production_lightings_index', '_controller' => 'App\\Controller\\Production\\ProductionLightingController::lightningsSite'], null, null, null, false, false, null]],
        '/production/selections' => [[['_route' => 'production_selections_index', '_controller' => 'App\\Controller\\Production\\ProductionSelectionController::selectionsSite'], null, null, null, false, false, null]],
        '/production/transfers' => [[['_route' => 'production_transfers_index', '_controller' => 'App\\Controller\\Production\\ProductionTransferController::transfersSite'], null, null, null, false, false, null]],
        '/register' => [[['_route' => 'registration', '_controller' => 'App\\Controller\\RegistrationController::register'], null, null, null, false, false, null]],
        '/reset-password' => [[['_route' => 'app_forgot_password_request', '_controller' => 'App\\Controller\\ResetPasswordController::request'], null, null, null, false, false, null]],
        '/reset-password/check-email' => [[['_route' => 'app_check_email', '_controller' => 'App\\Controller\\ResetPasswordController::checkEmail'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/selections' => [[['_route' => 'eggs_selections_index', '_controller' => 'App\\Controller\\SelectionsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/selections/transfer' => [[['_route' => 'no_selection_index', '_controller' => 'App\\Controller\\SelectionsController::showNoSelection'], null, ['GET' => 0], null, false, false, null]],
        '/selling_egg' => [[['_route' => 'selling_egg_index', '_controller' => 'App\\Controller\\SellingEggController::index'], null, ['GET' => 0], null, true, false, null]],
        '/selling_egg/new' => [[['_route' => 'selling_egg_new', '_controller' => 'App\\Controller\\SellingEggController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/setters' => [[['_route' => 'setters_index', '_controller' => 'App\\Controller\\SettersController::index'], null, ['GET' => 0], null, true, false, null]],
        '/setters/new' => [[['_route' => 'setters_new', '_controller' => 'App\\Controller\\SettersController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/supplier' => [[['_route' => 'egg_supplier_index', '_controller' => 'App\\Controller\\SupplierController::index'], null, ['GET' => 0], null, true, false, null]],
        '/supplier/new' => [[['_route' => 'egg_supplier_new', '_controller' => 'App\\Controller\\SupplierController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/transfers' => [[['_route' => 'eggs_inputs_transfers_index', '_controller' => 'App\\Controller\\TransfersController::index'], null, ['GET' => 0], null, true, false, null]],
        '/transfers/transfer' => [[['_route' => 'no_transfer_index', '_controller' => 'App\\Controller\\TransfersController::showNoTransfer'], null, ['GET' => 0], null, false, false, null]],
        '/transport_list' => [[['_route' => 'transport_list_index', '_controller' => 'App\\Controller\\TransportListController::index'], null, ['GET' => 0], null, true, false, null]],
        '/transport_list/new' => [[['_route' => 'transport_list_new', '_controller' => 'App\\Controller\\TransportListController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/user' => [[['_route' => 'user_index', '_controller' => 'App\\Controller\\UserController::index'], null, ['GET' => 0], null, true, false, null]],
        '/vaccination' => [[['_route' => 'vaccination_index', '_controller' => 'App\\Controller\\VaccinationController::index'], null, ['GET' => 0], null, true, false, null]],
        '/vaccination/new' => [[['_route' => 'vaccination_new', '_controller' => 'App\\Controller\\VaccinationController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/audit' => [[['_route' => 'dh_auditor_list_audits', '_controller' => 'DH\\AuditorBundle\\Controller\\ViewerController::listAuditsAction'], null, ['GET' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/breed(?'
                    .'|/([^/]++)(?'
                        .'|(*:28)'
                        .'|/edit(*:40)'
                        .'|(*:47)'
                    .')'
                    .'|_standard/([^/]++)(?'
                        .'|(*:76)'
                        .'|/edit(*:88)'
                        .'|(*:95)'
                    .')'
                .')'
                .'|/c(?'
                    .'|ar/([^/]++)(?'
                        .'|(*:123)'
                        .'|/edit(*:136)'
                        .'|(*:144)'
                    .')'
                    .'|hick(?'
                        .'|_(?'
                            .'|integration/([^/]++)(?'
                                .'|(*:187)'
                                .'|/edit(*:200)'
                                .'|(*:208)'
                            .')'
                            .'|temperature/(?'
                                .'|new(?:/([^/]++)(?:/([^/]++))?)?(*:263)'
                                .'|([^/]++)(?'
                                    .'|(*:282)'
                                    .'|/edit(*:295)'
                                    .'|(*:303)'
                                .')'
                            .')'
                        .')'
                        .'|s_recipient/(?'
                            .'|customer/([^/]++)(*:346)'
                            .'|new(?:/([^/]++))?(*:371)'
                            .'|([^/]++)(?'
                                .'|(*:390)'
                                .'|/edit(*:403)'
                                .'|(*:411)'
                            .')'
                        .')'
                    .')'
                    .'|ontact_info/([^/]++)(?'
                        .'|(*:445)'
                        .'|/edit(*:458)'
                        .'|(*:466)'
                    .')'
                    .'|ustomer(?'
                        .'|/([^/]++)(?'
                            .'|(*:497)'
                            .'|/edit(*:510)'
                            .'|(*:518)'
                        .')'
                        .'|_phone/(?'
                            .'|new(?:/([^/]++))?(*:554)'
                            .'|([^/]++)(?'
                                .'|(*:573)'
                                .'|/edit(*:586)'
                                .'|(*:594)'
                            .')'
                        .')'
                    .')'
                .')'
                .'|/d(?'
                    .'|elivery/([^/]++)(?'
                        .'|(*:630)'
                        .'|/(?'
                            .'|edit(*:646)'
                            .'|add(*:657)'
                        .')'
                        .'|(*:666)'
                    .')'
                    .'|river/([^/]++)(?'
                        .'|(*:692)'
                        .'|/edit(*:705)'
                        .'|(*:713)'
                    .')'
                .')'
                .'|/h(?'
                    .'|atchers/([^/]++)(?'
                        .'|(*:747)'
                        .'|/edit(*:760)'
                        .'|(*:768)'
                    .')'
                    .'|erds/(?'
                        .'|breeder/([^/]++)(*:801)'
                        .'|([^/]++)(?'
                            .'|(*:820)'
                            .'|/(?'
                                .'|edit(*:836)'
                                .'|active(*:850)'
                            .')'
                            .'|(*:859)'
                        .')'
                    .')'
                .')'
                .'|/input(?'
                    .'|_delivery/([^/]++)(?'
                        .'|(*:900)'
                        .'|/edit(*:913)'
                        .'|(*:921)'
                    .')'
                    .'|s(?'
                        .'|/([^/]++)(?'
                            .'|(*:946)'
                            .'|/edit(*:959)'
                            .'|(*:967)'
                        .')'
                        .'|_farm(?'
                            .'|/(?'
                                .'|new(?'
                                    .'|/([^/]++)(*:1003)'
                                    .'|_plan/([^/]++)(*:1026)'
                                .')'
                                .'|([^/]++)(?'
                                    .'|(*:1047)'
                                    .'|/edit(*:1061)'
                                    .'|(*:1070)'
                                .')'
                                .'|plan_delete/([^/]++)(*:1100)'
                            .')'
                            .'|_delivery_plan/(?'
                                .'|inputs/([^/]++)(*:1143)'
                                .'|new/([^/]++)(*:1164)'
                                .'|([^/]++)(?'
                                    .'|(*:1184)'
                                    .'|/edit(*:1198)'
                                    .'|(*:1207)'
                                .')'
                            .')'
                        .')'
                    .')'
                .')'
                .'|/lighting/(?'
                    .'|new/([^/]++)/([^/]++)(*:1255)'
                    .'|correct/([^/]++)/([^/]++)(*:1289)'
                    .'|([^/]++)(*:1306)'
                .')'
                .'|/p(?'
                    .'|lan(?'
                        .'|s(?'
                            .'|_(?'
                                .'|breeder/(?'
                                    .'|([^/]++)(*:1354)'
                                    .'|week/([^/]++)(*:1376)'
                                .')'
                                .'|hatching_date/(?'
                                    .'|([^/]++)(*:1411)'
                                    .'|week/([^/]++)(*:1433)'
                                .')'
                            .')'
                            .'|/(?'
                                .'|herd_delivery/([^/]++)(?'
                                    .'|(*:1473)'
                                    .'|/pdf(*:1486)'
                                .')'
                                .'|year_plan(?:/([^/]++))?(*:1519)'
                                .'|week/([^/]++)/([^/]++)(*:1550)'
                            .')'
                        .')'
                        .'|_(?'
                            .'|delivery_(?'
                                .'|chick/(?'
                                    .'|weekFarm/([^/]++)/([^/]++)(*:1612)'
                                    .'|([^/]++)(?'
                                        .'|(*:1632)'
                                        .'|/edit(*:1646)'
                                        .'|(*:1655)'
                                    .')'
                                    .'|customer_plans/(?'
                                        .'|send/([^/]++)(*:1696)'
                                        .'|([^/]++)(*:1713)'
                                    .')'
                                .')'
                                .'|egg/(?'
                                    .'|herd/([^/]++)(*:1744)'
                                    .'|([^/]++)(?'
                                        .'|(*:1764)'
                                        .'|/edit(*:1778)'
                                        .'|(*:1787)'
                                    .')'
                                .')'
                            .')'
                            .'|in(?'
                                .'|dicators/([^/]++)(?'
                                    .'|(*:1824)'
                                    .'|/edit(*:1838)'
                                    .'|(*:1847)'
                                .')'
                                .'|put/([^/]++)(?'
                                    .'|(*:1872)'
                                    .'|/edit(*:1886)'
                                    .'|(*:1895)'
                                .')'
                            .')'
                        .')'
                    .')'
                    .'|roduction/(?'
                        .'|chick_temperature/hatcher/([^/]++)(*:1955)'
                        .'|delivery/herds/([^/]++)(*:1987)'
                        .'|new/([^/]++)(*:2008)'
                        .'|inputs/(?'
                            .'|breeder/([^/]++)(*:2043)'
                            .'|herd/([^/]++)/([^/]++)(*:2074)'
                            .'|new/([^/]++)/([^/]++)(*:2104)'
                        .')'
                        .'|lightings/herd/([^/]++)(*:2137)'
                        .'|selections/(?'
                            .'|farm/([^/]++)(*:2173)'
                            .'|herd/([^/]++)/([^/]++)(*:2204)'
                        .')'
                        .'|transfers/(?'
                            .'|farm/([^/]++)(*:2240)'
                            .'|herd/([^/]++)/([^/]++)(*:2271)'
                        .')'
                    .')'
                .')'
                .'|/reset\\-password/reset(?:/([^/]++))?(*:2319)'
                .'|/s(?'
                    .'|e(?'
                        .'|l(?'
                            .'|ections/(?'
                                .'|new/([^/]++)/([^/]++)/([^/]++)(*:2382)'
                                .'|([^/]++)(?'
                                    .'|(*:2402)'
                                    .'|/edit(*:2416)'
                                    .'|(*:2425)'
                                .')'
                            .')'
                            .'|ling_egg/([^/]++)(?'
                                .'|(*:2456)'
                                .'|/edit(*:2470)'
                                .'|(*:2479)'
                            .')'
                        .')'
                        .'|tters/([^/]++)(?'
                            .'|(*:2507)'
                            .'|/edit(*:2521)'
                            .'|(*:2530)'
                        .')'
                    .')'
                    .'|upplier/([^/]++)(?'
                        .'|(*:2560)'
                        .'|/edit(*:2574)'
                        .'|(*:2583)'
                    .')'
                .')'
                .'|/trans(?'
                    .'|fers/(?'
                        .'|new/([^/]++)/([^/]++)/([^/]++)(*:2641)'
                        .'|([^/]++)(?'
                            .'|(*:2661)'
                            .'|/edit(*:2675)'
                            .'|(*:2684)'
                        .')'
                    .')'
                    .'|port_list/([^/]++)(?'
                        .'|(*:2716)'
                        .'|/edit(*:2730)'
                        .'|(*:2739)'
                    .')'
                .')'
                .'|/user/([^/]++)(?'
                    .'|(*:2767)'
                    .'|/edit(*:2781)'
                    .'|(*:2790)'
                .')'
                .'|/vaccination/([^/]++)(?'
                    .'|(*:2824)'
                    .'|/edit(*:2838)'
                    .'|(*:2847)'
                .')'
                .'|/audit/(?'
                    .'|transaction/([^/]++)(*:2887)'
                    .'|([^/]++)(?:/([^/]++))?(*:2918)'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        28 => [[['_route' => 'breed_show', '_controller' => 'App\\Controller\\BreedController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        40 => [[['_route' => 'breed_edit', '_controller' => 'App\\Controller\\BreedController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        47 => [[['_route' => 'breed_delete', '_controller' => 'App\\Controller\\BreedController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        76 => [[['_route' => 'breed_standard_show', '_controller' => 'App\\Controller\\BreedStandardController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        88 => [[['_route' => 'breed_standard_edit', '_controller' => 'App\\Controller\\BreedStandardController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        95 => [[['_route' => 'breed_standard_delete', '_controller' => 'App\\Controller\\BreedStandardController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        123 => [[['_route' => 'car_show', '_controller' => 'App\\Controller\\CarController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        136 => [[['_route' => 'car_edit', '_controller' => 'App\\Controller\\CarController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        144 => [[['_route' => 'car_delete', '_controller' => 'App\\Controller\\CarController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        187 => [[['_route' => 'chick_integration_show', '_controller' => 'App\\Controller\\ChickIntegrationController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        200 => [[['_route' => 'chick_integration_edit', '_controller' => 'App\\Controller\\ChickIntegrationController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        208 => [[['_route' => 'chick_integration_delete', '_controller' => 'App\\Controller\\ChickIntegrationController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        263 => [[['_route' => 'chick_temperature_new', 'input' => null, 'hatcher' => null, '_controller' => 'App\\Controller\\ChickTemperatureController::new'], ['input', 'hatcher'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        282 => [[['_route' => 'chick_temperature_show', '_controller' => 'App\\Controller\\ChickTemperatureController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        295 => [[['_route' => 'chick_temperature_edit', '_controller' => 'App\\Controller\\ChickTemperatureController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        303 => [[['_route' => 'chick_temperature_delete', '_controller' => 'App\\Controller\\ChickTemperatureController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        346 => [[['_route' => 'chick_recipient_customer_index', '_controller' => 'App\\Controller\\ChicksRecipientController::customerIndex'], ['id'], ['GET' => 0], null, false, true, null]],
        371 => [[['_route' => 'chicks_recipient_new', 'id' => null, '_controller' => 'App\\Controller\\ChicksRecipientController::new'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        390 => [[['_route' => 'chicks_recipient_show', '_controller' => 'App\\Controller\\ChicksRecipientController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        403 => [[['_route' => 'chicks_recipient_edit', '_controller' => 'App\\Controller\\ChicksRecipientController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        411 => [[['_route' => 'chicks_recipient_delete', '_controller' => 'App\\Controller\\ChicksRecipientController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        445 => [[['_route' => 'contact_info_show', '_controller' => 'App\\Controller\\ContactInfoController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        458 => [[['_route' => 'contact_info_edit', '_controller' => 'App\\Controller\\ContactInfoController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        466 => [[['_route' => 'contact_info_delete', '_controller' => 'App\\Controller\\ContactInfoController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        497 => [[['_route' => 'customer_show', '_controller' => 'App\\Controller\\CustomerController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        510 => [[['_route' => 'customer_edit', '_controller' => 'App\\Controller\\CustomerController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        518 => [[['_route' => 'customer_delete', '_controller' => 'App\\Controller\\CustomerController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        554 => [[['_route' => 'customer_phone_new', 'customer' => null, '_controller' => 'App\\Controller\\CustomerPhoneController::new'], ['customer'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        573 => [[['_route' => 'customer_phone_show', '_controller' => 'App\\Controller\\CustomerPhoneController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        586 => [[['_route' => 'customer_phone_edit', '_controller' => 'App\\Controller\\CustomerPhoneController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        594 => [[['_route' => 'customer_phone_delete', '_controller' => 'App\\Controller\\CustomerPhoneController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        630 => [[['_route' => 'eggs_delivery_show', '_controller' => 'App\\Controller\\DeliveryController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        646 => [[['_route' => 'eggs_delivery_edit', '_controller' => 'App\\Controller\\DeliveryController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        657 => [[['_route' => 'eggs_delivery_add', '_controller' => 'App\\Controller\\DeliveryController::addPartIndex'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        666 => [[['_route' => 'eggs_delivery_delete', '_controller' => 'App\\Controller\\DeliveryController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        692 => [[['_route' => 'driver_show', '_controller' => 'App\\Controller\\DriverController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        705 => [[['_route' => 'driver_edit', '_controller' => 'App\\Controller\\DriverController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        713 => [[['_route' => 'driver_delete', '_controller' => 'App\\Controller\\DriverController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        747 => [[['_route' => 'hatchers_show', '_controller' => 'App\\Controller\\HatchersController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        760 => [[['_route' => 'hatchers_edit', '_controller' => 'App\\Controller\\HatchersController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        768 => [[['_route' => 'hatchers_delete', '_controller' => 'App\\Controller\\HatchersController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        801 => [[['_route' => 'herds_breeder_index', '_controller' => 'App\\Controller\\HerdsController::breeder'], ['id'], ['GET' => 0], null, false, true, null]],
        820 => [[['_route' => 'herds_show', '_controller' => 'App\\Controller\\HerdsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        836 => [[['_route' => 'herds_edit', '_controller' => 'App\\Controller\\HerdsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        850 => [[['_route' => 'herds_edit_active', '_controller' => 'App\\Controller\\HerdsController::active'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        859 => [[['_route' => 'herds_delete', '_controller' => 'App\\Controller\\HerdsController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        900 => [[['_route' => 'input_delivery_show', '_controller' => 'App\\Controller\\InputDeliveryController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        913 => [[['_route' => 'input_delivery_edit', '_controller' => 'App\\Controller\\InputDeliveryController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        921 => [[['_route' => 'input_delivery_delete', '_controller' => 'App\\Controller\\InputDeliveryController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        946 => [[['_route' => 'eggs_inputs_show', '_controller' => 'App\\Controller\\InputsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        959 => [[['_route' => 'eggs_inputs_edit', '_controller' => 'App\\Controller\\InputsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        967 => [[['_route' => 'eggs_inputs_delete', '_controller' => 'App\\Controller\\InputsController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1003 => [[['_route' => 'inputs_farm_new', '_controller' => 'App\\Controller\\InputsFarmController::new'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1026 => [[['_route' => 'inputs_farm_plan_new', '_controller' => 'App\\Controller\\InputsFarmController::newPlan'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1047 => [[['_route' => 'inputs_farm_show', '_controller' => 'App\\Controller\\InputsFarmController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        1061 => [[['_route' => 'inputs_farm_edit', '_controller' => 'App\\Controller\\InputsFarmController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1070 => [[['_route' => 'inputs_farm_delete', '_controller' => 'App\\Controller\\InputsFarmController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1100 => [[['_route' => 'inputs_farm_plan_delete', '_controller' => 'App\\Controller\\InputsFarmController::deletePlan'], ['id'], ['POST' => 0], null, false, true, null]],
        1143 => [[['_route' => 'eggs_inputs_plan_show', '_controller' => 'App\\Controller\\InputsFarmDeliveryPlanController::inputsShow'], ['id'], ['GET' => 0], null, false, true, null]],
        1164 => [[['_route' => 'inputs_farm_delivery_plan_new', '_controller' => 'App\\Controller\\InputsFarmDeliveryPlanController::new'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1184 => [[['_route' => 'inputs_farm_delivery_plan_show', '_controller' => 'App\\Controller\\InputsFarmDeliveryPlanController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        1198 => [[['_route' => 'inputs_farm_delivery_plan_edit', '_controller' => 'App\\Controller\\InputsFarmDeliveryPlanController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1207 => [[['_route' => 'inputs_farm_delivery_plan_delete', '_controller' => 'App\\Controller\\InputsFarmDeliveryPlanController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1255 => [[['_route' => 'eggs_inputs_lighting_new', '_controller' => 'App\\Controller\\LightingController::new'], ['inputs', 'herd'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1289 => [[['_route' => 'eggs_inputs_lighting_correct', '_controller' => 'App\\Controller\\LightingController::correct'], ['inputs', 'herd'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1306 => [[['_route' => 'eggs_inputs_lighting_delete', '_controller' => 'App\\Controller\\LightingController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1354 => [[['_route' => 'plan_breeder', '_controller' => 'App\\Controller\\PlanBreederController::index'], ['id'], null, null, false, true, null]],
        1376 => [[['_route' => 'plan_breeder_week', '_controller' => 'App\\Controller\\PlanBreederController::week'], ['id'], null, null, false, true, null]],
        1411 => [[['_route' => 'plan_hatching_date_day', '_controller' => 'App\\Controller\\PlanHatchingDateController::indexDay'], ['date'], null, null, false, true, null]],
        1433 => [[['_route' => 'plan_hatching_week', '_controller' => 'App\\Controller\\PlanHatchingDateController::week'], ['date'], null, null, false, true, null]],
        1473 => [[['_route' => 'herd_delivery_plan_week', '_controller' => 'App\\Controller\\PlanController::herdDeliveryIndex'], ['id'], ['GET' => 0], null, false, true, null]],
        1486 => [[['_route' => 'herd_delivery_plan_week_pdf', '_controller' => 'App\\Controller\\PlanController::herdDeliveryPdf'], ['id'], ['GET' => 0], null, false, false, null]],
        1519 => [[['_route' => 'plan_year_plan', 'yearN' => null, '_controller' => 'App\\Controller\\PlanController::showYearPlans'], ['yearN'], ['GET' => 0], null, false, true, null]],
        1550 => [[['_route' => 'plan_week_detail', '_controller' => 'App\\Controller\\PlanController::showWeek'], ['year', 'week'], ['GET' => 0], null, false, true, null]],
        1612 => [[['_route' => 'plan_week_farm', '_controller' => 'App\\Controller\\PlanDeliveryChickController::weekCustomer'], ['date', 'farm'], null, null, false, true, null]],
        1632 => [[['_route' => 'plan_delivery_chick_show', '_controller' => 'App\\Controller\\PlanDeliveryChickController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        1646 => [[['_route' => 'plan_delivery_chick_edit', '_controller' => 'App\\Controller\\PlanDeliveryChickController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1655 => [[['_route' => 'plan_delivery_chick_delete', '_controller' => 'App\\Controller\\PlanDeliveryChickController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1696 => [[['_route' => 'customer_plans_send', '_controller' => 'App\\Controller\\PlanDeliveryChickController::sendEmail'], ['id'], ['GET' => 0], null, false, true, null]],
        1713 => [[['_route' => 'customer_plans', '_controller' => 'App\\Controller\\PlanDeliveryChickController::sendPlan'], ['id'], ['GET' => 0], null, false, true, null]],
        1744 => [[['_route' => 'plan_delivery_egg_herd', '_controller' => 'App\\Controller\\PlanDeliveryEggController::herd'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1764 => [[['_route' => 'plan_delivery_egg_show', '_controller' => 'App\\Controller\\PlanDeliveryEggController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        1778 => [[['_route' => 'plan_delivery_egg_edit', '_controller' => 'App\\Controller\\PlanDeliveryEggController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1787 => [[['_route' => 'plan_delivery_egg_delete', '_controller' => 'App\\Controller\\PlanDeliveryEggController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1824 => [[['_route' => 'plan_indicators_show', '_controller' => 'App\\Controller\\PlanIndicatorsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        1838 => [[['_route' => 'plan_indicators_edit', '_controller' => 'App\\Controller\\PlanIndicatorsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1847 => [[['_route' => 'plan_indicators_delete', '_controller' => 'App\\Controller\\PlanIndicatorsController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1872 => [[['_route' => 'plan_input_show', '_controller' => 'App\\Controller\\PlanInputController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        1886 => [[['_route' => 'plan_input_edit', '_controller' => 'App\\Controller\\PlanInputController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1895 => [[['_route' => 'plan_input_delete', '_controller' => 'App\\Controller\\PlanInputController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        1955 => [[['_route' => 'production_chick_temperature_hatcher', '_controller' => 'App\\Controller\\Production\\ProductionChickTemperatureController::chickTemperatureHatcher'], ['input'], null, null, false, true, null]],
        1987 => [[['_route' => 'production_delivery_herd', '_controller' => 'App\\Controller\\Production\\ProductionDeliveryController::deliveryHerd'], ['id'], null, null, false, true, null]],
        2008 => [[['_route' => 'production_delivery_new', '_controller' => 'App\\Controller\\Production\\ProductionDeliveryController::deliveryNew'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        2043 => [[['_route' => 'production_inputs_breeder', '_controller' => 'App\\Controller\\Production\\ProductionInputsController::inputsBreeder'], ['id'], ['GET' => 0], null, false, true, null]],
        2074 => [[['_route' => 'production_inputs_herd', '_controller' => 'App\\Controller\\Production\\ProductionInputsController::inputsHerd'], ['inputs', 'supplier'], ['GET' => 0], null, false, true, null]],
        2104 => [[['_route' => 'production_inputs_new', '_controller' => 'App\\Controller\\Production\\ProductionInputsController::inputNew'], ['herd', 'input'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        2137 => [[['_route' => 'production_lighting_herd', '_controller' => 'App\\Controller\\Production\\ProductionLightingController::lightingHerd'], ['id'], null, null, false, true, null]],
        2173 => [[['_route' => 'production_selections_farm', '_controller' => 'App\\Controller\\Production\\ProductionSelectionController::selectionsFarm'], ['id'], null, null, false, true, null]],
        2204 => [[['_route' => 'production_selections_herd', '_controller' => 'App\\Controller\\Production\\ProductionSelectionController::selectionsHerd'], ['farm', 'inputs'], null, null, false, true, null]],
        2240 => [[['_route' => 'production_transfer_farm', '_controller' => 'App\\Controller\\Production\\ProductionTransferController::transferFarm'], ['id'], null, null, false, true, null]],
        2271 => [[['_route' => 'production_transfer_herd', '_controller' => 'App\\Controller\\Production\\ProductionTransferController::transferHerd'], ['farm', 'inputs'], null, null, false, true, null]],
        2319 => [[['_route' => 'app_reset_password', 'token' => null, '_controller' => 'App\\Controller\\ResetPasswordController::reset'], ['token'], null, null, false, true, null]],
        2382 => [[['_route' => 'eggs_selections_new', '_controller' => 'App\\Controller\\SelectionsController::new'], ['inputs', 'farm', 'herd'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        2402 => [[['_route' => 'eggs_selections_show', '_controller' => 'App\\Controller\\SelectionsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2416 => [[['_route' => 'eggs_selections_edit', '_controller' => 'App\\Controller\\SelectionsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2425 => [[['_route' => 'eggs_selections_delete', '_controller' => 'App\\Controller\\SelectionsController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2456 => [[['_route' => 'selling_egg_show', '_controller' => 'App\\Controller\\SellingEggController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2470 => [[['_route' => 'selling_egg_edit', '_controller' => 'App\\Controller\\SellingEggController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2479 => [[['_route' => 'selling_egg_delete', '_controller' => 'App\\Controller\\SellingEggController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2507 => [[['_route' => 'setters_show', '_controller' => 'App\\Controller\\SettersController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2521 => [[['_route' => 'setters_edit', '_controller' => 'App\\Controller\\SettersController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2530 => [[['_route' => 'setters_delete', '_controller' => 'App\\Controller\\SettersController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2560 => [[['_route' => 'egg_supplier_show', '_controller' => 'App\\Controller\\SupplierController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2574 => [[['_route' => 'egg_supplier_edit', '_controller' => 'App\\Controller\\SupplierController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2583 => [[['_route' => 'egg_supplier_delete', '_controller' => 'App\\Controller\\SupplierController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2641 => [[['_route' => 'eggs_inputs_transfers_new', '_controller' => 'App\\Controller\\TransfersController::new'], ['inputs', 'farm', 'herd'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        2661 => [[['_route' => 'eggs_inputs_transfers_show', '_controller' => 'App\\Controller\\TransfersController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2675 => [[['_route' => 'eggs_inputs_transfers_edit', '_controller' => 'App\\Controller\\TransfersController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2684 => [[['_route' => 'eggs_inputs_transfers_delete', '_controller' => 'App\\Controller\\TransfersController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2716 => [[['_route' => 'transport_list_show', '_controller' => 'App\\Controller\\TransportListController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2730 => [[['_route' => 'transport_list_edit', '_controller' => 'App\\Controller\\TransportListController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2739 => [[['_route' => 'transport_list_delete', '_controller' => 'App\\Controller\\TransportListController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2767 => [[['_route' => 'user_show', '_controller' => 'App\\Controller\\UserController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2781 => [[['_route' => 'user_edit', '_controller' => 'App\\Controller\\UserController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2790 => [[['_route' => 'user_delete', '_controller' => 'App\\Controller\\UserController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2824 => [[['_route' => 'vaccination_show', '_controller' => 'App\\Controller\\VaccinationController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        2838 => [[['_route' => 'vaccination_edit', '_controller' => 'App\\Controller\\VaccinationController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        2847 => [[['_route' => 'vaccination_delete', '_controller' => 'App\\Controller\\VaccinationController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        2887 => [[['_route' => 'dh_auditor_show_transaction', '_controller' => 'DH\\AuditorBundle\\Controller\\ViewerController::showTransactionAction'], ['hash'], ['GET' => 0], null, false, true, null]],
        2918 => [
            [['_route' => 'dh_auditor_show_entity_history', 'id' => null, '_controller' => 'DH\\AuditorBundle\\Controller\\ViewerController::showEntityHistoryAction'], ['entity', 'id'], ['GET' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
