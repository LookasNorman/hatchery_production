<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/show_week/index.html.twig */
class __TwigTemplate_28feecb7bf9f95a762551aa24f38ce953cd725b064f58473c7b0bcd5713e6d28 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "plans/show_week/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .card {
            max-width: 450px;
            min-width: 380px;
            padding: 6px 6px;
        }
    </style>
    <h1>";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.show_week.title", [], "messages");
        echo ": ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, ($context["date"] ?? null), "W"), "html", null, true);
        echo " / ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, ($context["date"] ?? null), "Y"), "html", null, true);
        echo "
        - ";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["breed"] ?? null), "name", [], "any", false, false, false, 12), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["breed"] ?? null), "type", [], "any", false, false, false, 12), "html", null, true);
        echo "</h1>
    <div class=\"card-group\">
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["plans"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
            // line 15
            echo "            ";
            if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["day"], "chicks", [], "any", false, false, false, 15))) {
                // line 16
                echo "                <div class=\"card border-primary m-2\">
                    <div class=\"card-header bg-transparent border-success\">
                        ";
                // line 18
                ((twig_get_attribute($this->env, $this->source, $context["day"], "date", [], "any", false, false, false, 18)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["day"], "date", [], "any", false, false, false, 18), "full", "none", "", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
                echo "<br/>
                        ";
                // line 19
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.show_week.index.card.title.chicks", [], "messages");
                // line 20
                echo "                    </div>
                    <div class=\"card-body\">
                        ";
                // line 22
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["day"], "chicks", [], "any", false, false, false, 22));
                foreach ($context['_seq'] as $context["_key"] => $context["plan"]) {
                    // line 23
                    echo "                            <h6 class=\"card-title\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan"], "chickFarm", [], "any", false, false, false, 23), "customer", [], "any", false, false, false, 23), "name", [], "any", false, false, false, 23), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan"], "chickFarm", [], "any", false, false, false, 23), "name", [], "any", false, false, false, 23), "html", null, true);
                    echo "</h6>
                            <dl class=\"row\">
                                <dd class=\"col-sm-6\">";
                    // line 25
                    echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.show_week.index.chicks_number", [], "messages");
                    echo "</dd>
                                <dt class=\"col-sm-6\">";
                    // line 26
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plan"], "chickNumber", [], "any", false, false, false, 26), 0, ",", " "), "html", null, true);
                    echo "</dt>
                                <dd class=\"col-sm-6\">";
                    // line 27
                    echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.show_week.index.chicks_delivery_date", [], "messages");
                    echo "</dd>
                                <dt class=\"col-sm-6\">";
                    // line 28
                    ((twig_get_attribute($this->env, $this->source, $context["plan"], "deliveryDate", [], "any", false, false, false, 28)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["plan"], "deliveryDate", [], "any", false, false, false, 28), "medium", "none", "", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
                    echo "</dt>
                            </dl>
                            <hr/>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plan'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 32
                echo "                    </div>
                </div>
            ";
            }
            // line 35
            echo "            ";
            if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["day"], "eggs", [], "any", false, false, false, 35))) {
                // line 36
                echo "                <div class=\"card border-primary m-2\">
                    <div class=\"card-header bg-transparent border-success\">
                        ";
                // line 38
                ((twig_get_attribute($this->env, $this->source, $context["day"], "date", [], "any", false, false, false, 38)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["day"], "date", [], "any", false, false, false, 38), "full", "none", "", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
                echo "<br/>
                        ";
                // line 39
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.show_week.index.card.title.eggs", [], "messages");
                // line 40
                echo "                    </div>
                    <div class=\"card-body\">
                        ";
                // line 42
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["day"], "eggs", [], "any", false, false, false, 42));
                foreach ($context['_seq'] as $context["_key"] => $context["plan"]) {
                    // line 43
                    echo "                            <h6 class=\"card-title\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan"], "herd", [], "any", false, false, false, 43), "breeder", [], "any", false, false, false, 43), "name", [], "any", false, false, false, 43), "html", null, true);
                    echo " - ";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan"], "herd", [], "any", false, false, false, 43), "name", [], "any", false, false, false, 43), "html", null, true);
                    echo "</h6>
                            <dl class=\"row\">
                                <dd class=\"col-sm-6\">";
                    // line 45
                    echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.show_week.index.eggs_number", [], "messages");
                    echo "</dd>
                                <dt class=\"col-sm-6\">";
                    // line 46
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plan"], "eggsNumber", [], "any", false, false, false, 46), 0, ",", " "), "html", null, true);
                    echo "</dt>
                            </dl>
                            <hr/>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plan'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 50
                echo "                    </div>
                </div>
            ";
            }
            // line 53
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['day'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "plans/show_week/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 54,  182 => 53,  177 => 50,  167 => 46,  163 => 45,  155 => 43,  151 => 42,  147 => 40,  145 => 39,  141 => 38,  137 => 36,  134 => 35,  129 => 32,  119 => 28,  115 => 27,  111 => 26,  107 => 25,  99 => 23,  95 => 22,  91 => 20,  89 => 19,  85 => 18,  81 => 16,  78 => 15,  74 => 14,  67 => 12,  59 => 11,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/show_week/index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/show_week/index.html.twig");
    }
}
