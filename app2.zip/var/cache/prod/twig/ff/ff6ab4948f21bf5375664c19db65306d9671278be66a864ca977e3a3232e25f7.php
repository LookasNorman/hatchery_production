<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* customer/customer_detail_card.html.twig */
class __TwigTemplate_a9c5a56a72cc5a6831b20ffd2d7a0a943544318d6a55c60bf95c285334b101cd extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $this->loadTemplate("layout/cards/chead.html.twig", "customer/customer_detail_card.html.twig", 1)->display($context);
        // line 2
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.show.header", [], "messages");
        echo " - <span class=\"h3\">";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "name", [], "any", false, false, false, 2), "html", null, true);
        echo "</span>
";
        // line 3
        $this->loadTemplate("layout/cards/cbody.html.twig", "customer/customer_detail_card.html.twig", 3)->display($context);
        // line 4
        echo "<h5 class=\"card-title\"></h5>
<dl class=\"row d-print-none\">
    <dt class=\"col-sm-5\">";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.show.email", [], "messages");
        echo ":</dt>
    <dd class=\"col-sm-7\">";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "email", [], "any", false, false, false, 7), "html", null, true);
        echo "</dd>
    <dt class=\"col-sm-5\">";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.show.phone_number", [], "messages");
        echo ":</dt>
    <dd class=\"col-sm-7\">";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "phoneNumber", [], "any", false, false, false, 9), "html", null, true);
        echo "</dd>
</dl>
<hr class=\"d-print-none\"/>
<dl class=\"row d-print-none\">
    <dt class=\"col-sm-5\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.show.street", [], "messages");
        echo "</dt>
    <dd class=\"col-sm-7\">";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "street", [], "any", false, false, false, 14), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "streetNumber", [], "any", false, false, false, 14), "html", null, true);
        echo "</dd>
    <dt class=\"col-sm-5\">";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.show.city", [], "messages");
        echo "</dt>
    <dd class=\"col-sm-7\">";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "postCode", [], "any", false, false, false, 16), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "city", [], "any", false, false, false, 16), "html", null, true);
        echo "</dd>
</dl>
";
        // line 18
        $this->loadTemplate("layout/cards/cfooter.html.twig", "customer/customer_detail_card.html.twig", 18)->display($context);
        // line 19
        echo "    ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 20
            echo "        ";
            echo twig_include($this->env, $context, "customer/_delete_form.html.twig");
            echo "
    ";
        }
        // line 22
        echo "    ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
            // line 23
            echo "        ";
            echo twig_include($this->env, $context, "layout/buttons/edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_edit", ["id" => twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 23)]), "text" => "customer.show.button.edit"]);
            echo "
    ";
        }
        // line 25
        echo "        ";
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chick_recipient_customer_index", ["id" => twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 25)]), "text" => "customer.show.button.farm"]);
        echo "
";
        // line 26
        $this->loadTemplate("layout/cards/cend.html.twig", "customer/customer_detail_card.html.twig", 26)->display($context);
    }

    public function getTemplateName()
    {
        return "customer/customer_detail_card.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 26,  112 => 25,  106 => 23,  103 => 22,  97 => 20,  94 => 19,  92 => 18,  85 => 16,  81 => 15,  75 => 14,  71 => 13,  64 => 9,  60 => 8,  56 => 7,  52 => 6,  48 => 4,  46 => 3,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "customer/customer_detail_card.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/customer/customer_detail_card.html.twig");
    }
}
