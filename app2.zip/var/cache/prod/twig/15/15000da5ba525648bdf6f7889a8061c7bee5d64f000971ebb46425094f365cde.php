<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* chick_temperature/table_list.html.twig */
class __TwigTemplate_8076906fcc9decc818cfe28e1aed1177bd8a0606dcac311ca913be3ffd84f3ac extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $this->loadTemplate("layout/tables/thead.html.twig", "chick_temperature/table_list.html.twig", 1)->display($context);
        // line 2
        echo "<tr>
    <th>";
        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.table.id", [], "messages");
        echo "</th>
    <th>";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.table.input", [], "messages");
        echo "</th>
    <th>";
        // line 5
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.table.hatcher", [], "messages");
        echo "</th>
    <th>";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.table.date", [], "messages");
        echo "</th>
    <th>";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.table.temperature", [], "messages");
        echo "</th>
    <th>";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.table.actions", [], "messages");
        echo "</th>
</tr>
";
        // line 10
        $this->loadTemplate("layout/tables/tbody.html.twig", "chick_temperature/table_list.html.twig", 10)->display($context);
        // line 11
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["chick_temperatures"] ?? null));
        $context['_iterated'] = false;
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["chick_temperature"]) {
            // line 12
            echo "            <tr>
                <td>";
            // line 13
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["chick_temperature"], "id", [], "any", false, false, false, 13), "html", null, true);
            echo "</td>
                <td>";
            // line 14
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["chick_temperature"], "input", [], "any", false, false, false, 14), "name", [], "any", false, false, false, 14), "html", null, true);
            echo "</td>
                <td>";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["chick_temperature"], "hatcher", [], "any", false, false, false, 15), "name", [], "any", false, false, false, 15), "html", null, true);
            echo "</td>
                <td>";
            // line 16
            ((twig_get_attribute($this->env, $this->source, $context["chick_temperature"], "date", [], "any", false, false, false, 16)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["chick_temperature"], "date", [], "any", false, false, false, 16), "Y-m-d"), "html", null, true))) : (print ("")));
            echo "</td>
                <td>";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["chick_temperature"], "temperature", [], "any", false, false, false, 17), "html", null, true);
            echo "</td>
                <td>
                    ";
            // line 19
            echo twig_include($this->env, $context, "layout/buttons/list_show.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chick_temperature_show", ["id" => twig_get_attribute($this->env, $this->source,             // line 20
$context["chick_temperature"], "id", [], "any", false, false, false, 20)])]);
            echo "
                    ";
            // line 21
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
                // line 22
                echo "                        ";
                echo twig_include($this->env, $context, "layout/buttons/list_edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chick_temperature_edit", ["id" => twig_get_attribute($this->env, $this->source,                 // line 23
$context["chick_temperature"], "id", [], "any", false, false, false, 23)])]);
                echo "
                    ";
            }
            // line 25
            echo "                </td>
            </tr>
        ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 28
            echo "            <tr>
                <td colspan=\"6\">";
            // line 29
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.table.no_found", [], "messages");
            echo "</td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['chick_temperature'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "    ";
        $this->loadTemplate("layout/tables/tfooter.html.twig", "chick_temperature/table_list.html.twig", 32)->display($context);
        // line 33
        echo "    ";
        $this->loadTemplate("layout/tables/tend.html.twig", "chick_temperature/table_list.html.twig", 33)->display($context);
    }

    public function getTemplateName()
    {
        return "chick_temperature/table_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 33,  153 => 32,  144 => 29,  141 => 28,  126 => 25,  121 => 23,  119 => 22,  117 => 21,  113 => 20,  112 => 19,  107 => 17,  103 => 16,  99 => 15,  95 => 14,  91 => 13,  88 => 12,  69 => 11,  67 => 10,  62 => 8,  58 => 7,  54 => 6,  50 => 5,  46 => 4,  42 => 3,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "chick_temperature/table_list.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/chick_temperature/table_list.html.twig");
    }
}
