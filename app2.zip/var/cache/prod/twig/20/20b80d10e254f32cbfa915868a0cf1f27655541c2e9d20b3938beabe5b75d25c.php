<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layout/buttons/list_show.html.twig */
class __TwigTemplate_080d448bc5770140dcd215c928d695376d5008858aeef31dfcaddbad74873bfe extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<a class=\"btn\" href=\"";
        echo twig_escape_filter($this->env, ($context["pathLink"] ?? null), "html", null, true);
        echo "\"><i class=\"fa fa-search\"></i></a>
";
    }

    public function getTemplateName()
    {
        return "layout/buttons/list_show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "layout/buttons/list_show.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/layout/buttons/list_show.html.twig");
    }
}
