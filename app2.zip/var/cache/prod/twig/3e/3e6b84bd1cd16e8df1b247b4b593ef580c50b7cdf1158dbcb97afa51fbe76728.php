<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* egg_supplier/_delete_form.html.twig */
class __TwigTemplate_5745eda4ec729c3724cbccc82be1aa8ff75a596e966505a0cfad737a182d922b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<form method=\"post\" action=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("egg_supplier_delete", ["id" => twig_get_attribute($this->env, $this->source, ($context["egg_supplier"] ?? null), "id", [], "any", false, false, false, 1)]), "html", null, true);
        echo "\"
      onsubmit=\"return confirm('";
        // line 2
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("egg_supplier.delete.title", [], "messages");
        echo "');\">
    <input type=\"hidden\" name=\"_token\" value=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken(("delete" . twig_get_attribute($this->env, $this->source, ($context["egg_supplier"] ?? null), "id", [], "any", false, false, false, 3))), "html", null, true);
        echo "\">
    ";
        // line 4
        echo twig_include($this->env, $context, "layout/buttons/delete.html.twig", ["text" => "egg_supplier.delete.button.delete"]);
        echo "
</form>
";
    }

    public function getTemplateName()
    {
        return "egg_supplier/_delete_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 4,  46 => 3,  42 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "egg_supplier/_delete_form.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/egg_supplier/_delete_form.html.twig");
    }
}
