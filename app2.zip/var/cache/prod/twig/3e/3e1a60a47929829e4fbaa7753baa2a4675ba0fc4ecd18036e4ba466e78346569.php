<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/weekPlanSite.html.twig */
class __TwigTemplate_8d9e8de3653d1bd1933b334e0fb9edb271603f08bb9ac8ff9283a28c312ea64c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"row row-cols-1 row-cols-md-4 g-4\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["week"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["plans"]) {
            // line 3
            echo "        <div class=\"col\">
            <div class=\"card border-info\">
                <div class=\"card-body\">
                    ";
            // line 6
            $context["selectionWeek"] = ($context["key"] + 3);
            // line 7
            echo "                    <div class=\"container\">
                        <div class=\"row justify-content-between\">
                        <div class=\"col-6\">
                            <h5 class=\"card-title\">
                                ";
            // line 11
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.week_plan_site.week.number", [], "messages");
            echo " ";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo " (";
            echo twig_escape_filter($this->env, ($context["selectionWeek"] ?? null), "html", null, true);
            echo ")
                            </h5>
                        </div>
                        <div class=\"col-3 text-end h5\">
                            <a href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_week_detail", ["week" => $context["key"], "year" => twig_date_format_filter($this->env, ($context["year"] ?? null), "Y")]), "html", null, true);
            echo "\"><i class=\"fas fa-list text-end\"></i></a>
                        </div>
                        </div>
                    </div>
                    <dl class=\"row\">
                        <dd class=\"col-sm-9\">";
            // line 20
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.chicks", [], "messages");
            echo "</dd>
                        <dt class=\"col-sm-3\">
                            <a type=\"button\" class=\"\" data-bs-toggle=\"modal\"
                               data-bs-target=\"#chicks";
            // line 23
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "Modal\">
                                ";
            // line 24
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "chicks", [], "any", false, false, false, 24), 0, ",", " "), "html", null, true);
            echo "
                            </a>
                        </dt>
                        <dd class=\"col-sm-9\">";
            // line 27
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.eggs_delivery", [], "messages");
            echo "</dd>
                        <dt class=\"col-sm-3\">
                            <a type=\"button\" class=\"\" data-bs-toggle=\"modal\"
                               data-bs-target=\"#eggs";
            // line 30
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "Modal\">
                                ";
            // line 31
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "eggs", [], "any", false, false, false, 31), 0, ",", " "), "html", null, true);
            echo "
                            </a>
                        </dt>
                        <dd class=\"col-sm-9\">";
            // line 34
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.eggs_stock", [], "messages");
            echo "</dd>
                        <dt class=\"col-sm-3\">
                            ";
            // line 36
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "eggsInStock", [], "any", false, false, false, 36), 0, ",", " "), "html", null, true);
            echo "
                        </dt>
                    </dl>
                    <div class=\"modal fade\" id=\"chicks";
            // line 39
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "Modal\" tabindex=\"-1\"
                         aria-labelledby=\"chicks";
            // line 40
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "ModalLabel\" aria-hidden=\"true\">
                        <div class=\"modal-dialog\">
                            <div class=\"modal-content\">
                                <div class=\"modal-header\">
                                    <h5 class=\"modal-title\" id=\"chicks";
            // line 44
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "ModalLabel\">
                                        ";
            // line 45
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.chicks", [], "messages");
            // line 46
            echo "                                    </h5>
                                    <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\"
                                            aria-label=\"Close\"></button>
                                </div>
                                <div class=\"modal-body\">
                                    <dl class=\"row\">
                                        ";
            // line 52
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["plans"], "chickPlans", [], "any", false, false, false, 52));
            foreach ($context['_seq'] as $context["_key"] => $context["farm"]) {
                // line 53
                echo "                                            <dd class=\"col-sm-9\">
                                                <a href=\"";
                // line 54
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_week_farm", ["date" => twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "date", [], "any", false, false, false, 54), "Y-m-d"), "farm" => twig_get_attribute($this->env, $this->source, $context["farm"], "id", [], "any", false, false, false, 54)]), "html", null, true);
                echo "\">
                                                    ";
                // line 55
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["farm"], "customer", [], "any", false, false, false, 55), "html", null, true);
                echo " - ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["farm"], "name", [], "any", false, false, false, 55), "html", null, true);
                echo "</a>:
                                            </dd>
                                            <dt class=\"col-sm-3\">";
                // line 57
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["farm"], "chicks", [], "any", false, false, false, 57), 0, ",", " "), "html", null, true);
                echo "</dt>
                                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['farm'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 59
            echo "                                    </dl>
                                </div>
                                <div class=\"modal-footer\">
                                    <button type=\"button\" class=\"btn btn-secondary\" data-bs-dismiss=\"modal\">Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=\"modal fade\" id=\"eggs";
            // line 68
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "Modal\" tabindex=\"-1\"
                         aria-labelledby=\"eggs";
            // line 69
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "ModalLabel\" aria-hidden=\"true\">
                        <div class=\"modal-dialog\">
                            <div class=\"modal-content\">
                                <div class=\"modal-header\">
                                    <h5 class=\"modal-title\" id=\"eggs";
            // line 73
            echo twig_escape_filter($this->env, ($context["breed"] ?? null), "html", null, true);
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "ModalLabel\">
                                        ";
            // line 74
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.chicks", [], "messages");
            // line 75
            echo "                                    </h5>
                                    <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\"
                                            aria-label=\"Close\"></button>
                                </div>
                                <div class=\"modal-body\">
                                    <dl class=\"row\">
                                        ";
            // line 81
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["plans"], "eggPlans", [], "any", false, false, false, 81));
            foreach ($context['_seq'] as $context["_key"] => $context["herd"]) {
                // line 82
                echo "                                            <dd class=\"col-sm-9\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["herd"], "name", [], "any", false, false, false, 82), "html", null, true);
                echo ":</dd>
                                            <dt class=\"col-sm-3\">";
                // line 83
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["herd"], "eggs", [], "any", false, false, false, 83), 0, ",", " "), "html", null, true);
                echo "</dt>
                                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['herd'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 85
            echo "                                    </dl>
                                </div>
                                <div class=\"modal-footer\">
                                    <button type=\"button\" class=\"btn btn-secondary\" data-bs-dismiss=\"modal\">Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['plans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "plans/weekPlanSite.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  249 => 98,  231 => 85,  223 => 83,  218 => 82,  214 => 81,  206 => 75,  204 => 74,  199 => 73,  191 => 69,  186 => 68,  175 => 59,  167 => 57,  160 => 55,  156 => 54,  153 => 53,  149 => 52,  141 => 46,  139 => 45,  134 => 44,  126 => 40,  121 => 39,  115 => 36,  110 => 34,  104 => 31,  99 => 30,  93 => 27,  87 => 24,  82 => 23,  76 => 20,  68 => 15,  57 => 11,  51 => 7,  49 => 6,  44 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/weekPlanSite.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/weekPlanSite.html.twig");
    }
}
