<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* car/edit.html.twig */
class __TwigTemplate_6ebe106d19562bbf580f656ffb60ed2122756b716b04bbd9eb4c9514729bcc88 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "car/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .card {
            max-width: 500px;
            min-width: 380px;
            padding: 6px 6px;
        }
    </style>
    <h1>";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("car.edit.title", [], "messages");
        echo "</h1>

    <div class=\"d-flex justify-content-center card-group\">
        ";
        // line 14
        $this->loadTemplate("layout/cards/chead.html.twig", "car/edit.html.twig", 14)->display($context);
        // line 15
        echo "        <i class=\"fa fa-pencil\" aria-hidden=\"true\"></i>
        <i class=\"fa fa-car\" aria-hidden=\"true\"></i> ";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("car.edit.title", [], "messages");
        // line 17
        echo "        ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "car/edit.html.twig", 17)->display($context);
        // line 18
        echo "        ";
        echo twig_include($this->env, $context, "car/_form.html.twig", ["button_label" => "car.edit.button.update"]);
        echo "
        ";
        // line 19
        $this->loadTemplate("layout/cards/cfooter.html.twig", "car/edit.html.twig", 19)->display($context);
        // line 20
        echo "        ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 21
            echo "            ";
            echo twig_include($this->env, $context, "car/_delete_form.html.twig");
            echo "
        ";
        }
        // line 23
        echo "        ";
        $this->loadTemplate("layout/cards/cend.html.twig", "car/edit.html.twig", 23)->display($context);
        // line 24
        echo "    </div>
    ";
        // line 25
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("car_index"), "text" => "car.new.button.back"]);
        echo "

";
    }

    public function getTemplateName()
    {
        return "car/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 25,  94 => 24,  91 => 23,  85 => 21,  82 => 20,  80 => 19,  75 => 18,  72 => 17,  70 => 16,  67 => 15,  65 => 14,  59 => 11,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "car/edit.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/car/edit.html.twig");
    }
}
