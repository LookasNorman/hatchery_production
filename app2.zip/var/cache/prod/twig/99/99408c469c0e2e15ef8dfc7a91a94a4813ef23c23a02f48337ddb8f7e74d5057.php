<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* driver/show.html.twig */
class __TwigTemplate_d30b9f155f9d2f234adfc1dff16ccbfad542d89b03322858c37fcd2a74b17c2c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "driver/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"d-flex justify-content-center card-group\">
        ";
        // line 5
        $this->loadTemplate("layout/cards/chead.html.twig", "driver/show.html.twig", 5)->display($context);
        // line 6
        echo "        ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("driver.show.title", [], "messages");
        // line 7
        echo "        ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "driver/show.html.twig", 7)->display($context);
        // line 8
        echo "        <h5 class=\"card-title\">";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["driver"] ?? null), "firstname", [], "any", false, false, false, 8), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["driver"] ?? null), "lastname", [], "any", false, false, false, 8), "html", null, true);
        echo "</h5>
        <p class=\"card-text\">
            ";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("driver.show.phone_number", [], "messages");
        echo ": ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["driver"] ?? null), "phoneNumber", [], "any", false, false, false, 10), "html", null, true);
        echo "
        </p>
        ";
        // line 12
        $this->loadTemplate("layout/cards/cfooter.html.twig", "driver/show.html.twig", 12)->display($context);
        // line 13
        echo "        ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 14
            echo "            ";
            echo twig_include($this->env, $context, "driver/_delete_form.html.twig");
            echo "
        ";
        }
        // line 16
        echo "        ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
            // line 17
            echo "            ";
            echo twig_include($this->env, $context, "layout/buttons/edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("driver_edit", ["id" => twig_get_attribute($this->env, $this->source, ($context["driver"] ?? null), "id", [], "any", false, false, false, 17)]), "text" => "driver.show.button.edit"]);
            echo "
        ";
        }
        // line 19
        echo "        ";
        $this->loadTemplate("layout/cards/cend.html.twig", "driver/show.html.twig", 19)->display($context);
        // line 20
        echo "    </div>
    ";
        // line 21
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("driver_index"), "text" => "driver.show.button.back"]);
        echo "

";
    }

    public function getTemplateName()
    {
        return "driver/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 21,  99 => 20,  96 => 19,  90 => 17,  87 => 16,  81 => 14,  78 => 13,  76 => 12,  69 => 10,  61 => 8,  58 => 7,  55 => 6,  53 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "driver/show.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/driver/show.html.twig");
    }
}
