<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* chick_temperature/production/index.html.twig */
class __TwigTemplate_14699862b0fc78aa8b87c18400429b4609ed6c34db9e82beab8053f580a7f432 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "chick_temperature/production/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"text-center m-2\">
        <h1>
            ";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.production.inputs.title", [], "messages");
        // line 7
        echo "        </h1>
    </div>
    <div class=\"d-flex justify-content-center flex-wrap\">
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["inputs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["input"]) {
            // line 11
            echo "            ";
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_PRODUCTION")) {
                // line 12
                echo "                <a class=\"btn btn-secondary p-2 m-2 col-sm-3\"
                   href=\"";
                // line 13
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("production_chick_temperature_hatcher", ["input" => twig_get_attribute($this->env, $this->source, $context["input"], "id", [], "any", false, false, false, 13)]), "html", null, true);
                echo "\">
                    <span class=\"m-4\"><i class=\"fas fa-thermometer fa-2x\"></i></span>
                    <span class=\"h1\">";
                // line 15
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["input"], "name", [], "any", false, false, false, 15), "html", null, true);
                echo " - ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, twig_get_attribute($this->env, $this->source, $context["input"], "inputDate", [], "any", false, false, false, 15), "+21 day"), "Y-m-d"), "html", null, true);
                echo "</span>
                </a>
            ";
            }
            // line 18
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['input'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "chick_temperature/production/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 19,  84 => 18,  76 => 15,  71 => 13,  68 => 12,  65 => 11,  61 => 10,  56 => 7,  54 => 6,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "chick_temperature/production/index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/chick_temperature/production/index.html.twig");
    }
}
