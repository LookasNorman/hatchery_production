<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/weekPlansWeekly.html.twig */
class __TwigTemplate_d41237b89d86a476b3c822cf22fbeb66ef85ff4937ed2993a3874f93adbdf6b6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<dl class=\"row\">
    <dt class=\"col-sm-6\">";
        // line 2
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.chicks", [], "messages");
        echo "</dt>
    <dd class=\"col-sm-6\">";
        // line 3
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["weekPlans"] ?? null), "weekPlans", [], "any", false, false, false, 3), "chicks", [], "any", false, false, false, 3), 0, ",", " "), "html", null, true);
        echo "</dd>
    <dt class=\"col-sm-6\">";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.eggs_delivery", [], "messages");
        echo "</dt>
    <dd class=\"col-sm-6\">";
        // line 5
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["weekPlans"] ?? null), "weekPlans", [], "any", false, false, false, 5), "eggs", [], "any", false, false, false, 5), 0, ",", " "), "html", null, true);
        echo "</dd>
    <dt class=\"col-sm-6\">";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.eggs_warehouse", [], "messages");
        echo "</dt>
    <dd class=\"col-sm-6\">";
        // line 7
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["weekPlans"] ?? null), "weekPlans", [], "any", false, false, false, 7), "eggsOnWarehouse", [], "any", false, false, false, 7), 0, ",", " "), "html", null, true);
        echo "</dd>
</dl>
";
    }

    public function getTemplateName()
    {
        return "plans/weekPlansWeekly.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 7,  56 => 6,  52 => 5,  48 => 4,  44 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/weekPlansWeekly.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/weekPlansWeekly.html.twig");
    }
}
