<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* customer/show.html.twig */
class __TwigTemplate_2641505ee43f0a89cf8a2f7f75364d12bb9c84e9e7f78a9d5add3920708770a4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "customer/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <h1 class=\"d-print-none\">";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.show.title", [], "messages");
        echo "</h1>

        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 22
        echo twig_include($this->env, $context, "customer/customer_detail_card.html.twig");
        echo "
            <div class=\"maps\">
                <iframe
                        width=\"480\"
                        height=\"480\"
                        style=\"border:0\"
                        src=\"https://www.google.com/maps/embed/v1/place?key=";
        // line 28
        echo twig_escape_filter($this->env, ($context["maps_api"] ?? null), "html", null, true);
        echo "&q=Poland+";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "postcode", [], "any", false, false, false, 28), "html", null, true);
        echo "+";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "city", [], "any", false, false, false, 28), "html", null, true);
        echo "+";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "street", [], "any", false, false, false, 28), "html", null, true);
        echo "+";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "streetNumber", [], "any", false, false, false, 28), "html", null, true);
        echo "&maptype=satellite\"
                        allowfullscreen>
                </iframe>
            </div>
        </div>
        ";
        // line 33
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_index"), "text" => "customer.show.button.back"]);
        echo "
        ";
        // line 34
        echo twig_include($this->env, $context, "layout/buttons/add.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chicks_recipient_new", ["id" => twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 34)]), "text" => "customer.show.button.add"]);
        echo "
        ";
        // line 35
        echo twig_include($this->env, $context, "layout/buttons/add.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_delivery_chick_new"), "text" => "customer.show.button.add_plan"]);
        echo "
        ";
        // line 36
        echo twig_include($this->env, $context, "layout/buttons/add.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_phone_new", ["customer" => twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 36)]), "text" => "customer.show.button.add_phone"]);
        echo "
        <a type=\"btn\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_phone_new", ["customer" => twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 37)]), "html", null, true);
        echo "\">
            <i class=\"fas fa-plus\"></i><i class=\"fas fa-phone-square\"></i>
        </a>
        <hr>
        <div class=\"accordion accordion-flush\" id=\"accordionFlushShow\">
            <div class=\"accordion-item\">
                <h2 class=\"accordion-header\" id=\"flush-headingOne\">
                    <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\"
                            data-bs-target=\"#flush-collapseOne\" aria-expanded=\"false\" aria-controls=\"flush-collapseOne\">
                        ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chicks_recipient.show.accordion.inputs", [], "messages");
        // line 47
        echo "                    </button>
                </h2>
                <div id=\"flush-collapseOne\" class=\"accordion-collapse collapse\" aria-labelledby=\"flush-headingOne\"
                     data-bs-parent=\"#accordionFlushShow\">
                    <div class=\"accordion-body\">
                        ";
        // line 53
        echo "                    </div>
                </div>
            </div>
            <div class=\"accordion-item\">
                <h2 class=\"accordion-header\" id=\"flush-headingTwo\">
                    <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\"
                            data-bs-target=\"#flush-collapseTwo\" aria-expanded=\"false\" aria-controls=\"flush-collapseTwo\">
                        ";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chicks_recipient.show.accordion.chicks_plan", [], "messages");
        // line 61
        echo "                    </button>
                </h2>
                <div id=\"flush-collapseTwo\" class=\"accordion-collapse collapse\" aria-labelledby=\"flush-headingTwo\"
                     data-bs-parent=\"#accordionFlushShow\">
                    <div class=\"accordion-body\">
                        ";
        // line 66
        $this->loadTemplate("plan_delivery_chick/list_plan_chick.html.twig", "customer/show.html.twig", 66)->display($context);
        // line 67
        echo "                    </div>
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "customer/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  155 => 67,  153 => 66,  146 => 61,  144 => 60,  135 => 53,  128 => 47,  126 => 46,  114 => 37,  110 => 36,  106 => 35,  102 => 34,  98 => 33,  82 => 28,  73 => 22,  67 => 19,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "customer/show.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/customer/show.html.twig");
    }
}
