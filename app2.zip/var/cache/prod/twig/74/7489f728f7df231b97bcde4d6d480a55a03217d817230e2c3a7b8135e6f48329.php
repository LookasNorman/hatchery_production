<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* eggs_inputs/show.html.twig */
class __TwigTemplate_317dc480b3c86beaf0432d0323b639094ec3deb46546dd897f708f7de0c72f5d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "eggs_inputs/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <h1>";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.show.title", [], "messages");
        echo "</h1>
        ";
        // line 20
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("eggs_inputs_index"), "text" => "eggs_inputs.show.button.back"]);
        echo "

        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 23
        $this->loadTemplate("layout/cards/chead.html.twig", "eggs_inputs/show.html.twig", 23)->display($context);
        // line 24
        echo "            ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["eggs_input"] ?? null), "name", [], "any", false, false, false, 24), "html", null, true);
        echo "
            ";
        // line 25
        $this->loadTemplate("layout/cards/cbody.html.twig", "eggs_inputs/show.html.twig", 25)->display($context);
        // line 26
        echo "            <p class=\"card-text\">
                ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.show.input_date", [], "messages");
        // line 28
        echo "                : ";
        ((twig_get_attribute($this->env, $this->source, ($context["eggs_input"] ?? null), "inputDate", [], "any", false, false, false, 28)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["eggs_input"] ?? null), "inputDate", [], "any", false, false, false, 28), "Y-m-d"), "html", null, true))) : (print ("")));
        echo "
            </p>
            ";
        // line 30
        $this->loadTemplate("layout/cards/cfooter.html.twig", "eggs_inputs/show.html.twig", 30)->display($context);
        // line 31
        echo "            <ul>
                ";
        // line 32
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
            // line 33
            echo "                    <li class=\"d-flex\">
                        ";
            // line 34
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
                // line 35
                echo "                            ";
                echo twig_include($this->env, $context, "eggs_inputs/_delete_form.html.twig");
                echo "
                        ";
            }
            // line 37
            echo "                        ";
            echo twig_include($this->env, $context, "layout/buttons/edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("eggs_inputs_edit", ["id" => twig_get_attribute($this->env, $this->source,             // line 38
($context["eggs_input"] ?? null), "id", [], "any", false, false, false, 38)]), "text" => "eggs_inputs.show.button.edit"]);
            echo "
                        ";
            // line 39
            echo twig_include($this->env, $context, "layout/buttons/add.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("inputs_farm_new", ["id" => twig_get_attribute($this->env, $this->source,             // line 40
($context["eggs_input"] ?? null), "id", [], "any", false, false, false, 40)]), "text" => "eggs_inputs.show.button.add_farm"]);
            echo "
                    </li>
                    <hr>
                    <li class=\"d-flex\">";
            // line 43
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.show.card.footer.add", [], "messages");
            echo "</li>
                    <li class=\"d-flex\">
                        ";
            // line 45
            echo twig_include($this->env, $context, "layout/buttons/edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("production_lighting_herd", ["id" => twig_get_attribute($this->env, $this->source,             // line 46
($context["eggs_input"] ?? null), "id", [], "any", false, false, false, 46)]), "text" => "eggs_inputs.show.button.lighting.new"]);
            echo "
                        ";
            // line 47
            echo twig_include($this->env, $context, "layout/modals/production_modal.html.twig", ["title" => "eggs_inputs.show.button.lighting.correct", "body" =>             // line 49
($context["herdsEggs"] ?? null), "pathLink" => "eggs_inputs_lighting_correct", "class" => "btn-warning"]);
            echo "
                    </li>
                ";
        }
        // line 52
        echo "            </ul>
            ";
        // line 53
        $this->loadTemplate("layout/cards/cend.html.twig", "eggs_inputs/show.html.twig", 53)->display($context);
        // line 54
        echo "        </div>
        <hr>
        <div class=\"accordion\" id=\"InputsDetails\">
            <div class=\"accordion-item\">
                <h2 class=\"accordion-header\" id=\"flush-headingChicks\">
                    <button class=\"accordion-button\" type=\"button\" data-bs-toggle=\"collapse\"
                            data-bs-target=\"#flush-collapseChicks\" aria-expanded=\"false\"
                            aria-controls=\"flush-collapseChicks\">
                        ";
        // line 62
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.show.accordion.chick", [], "messages");
        // line 63
        echo "                    </button>
                </h2>
                <div id=\"flush-collapseChicks\" class=\"accordion-collapse collapse show\" aria-labelledby=\"flush-headingChicks\"
                     data-bs-parent=\"#InputsDetails\">
                    <div class=\"accordion-body\">
                        ";
        // line 68
        $this->loadTemplate("eggs_inputs/show_customer_delivery.html.twig", "eggs_inputs/show.html.twig", 68)->display($context);
        // line 69
        echo "                    </div>
                </div>
            </div>
            <div class=\"accordion-item\">
                <h2 class=\"accordion-header\" id=\"flush-headingEggs\">
                    <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\"
                            data-bs-target=\"#flush-collapseEggs\" aria-expanded=\"false\"
                            aria-controls=\"flush-collapseEggs\">
                        ";
        // line 77
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.show.accordion.production", [], "messages");
        // line 78
        echo "                    </button>
                </h2>
                <div id=\"flush-collapseEggs\" class=\"accordion-collapse collapse\" aria-labelledby=\"flush-headingEggs\"
                     data-bs-parent=\"#InputsDetails\">
                    <div class=\"accordion-body\">
                        ";
        // line 83
        $this->loadTemplate("eggs_inputs/show_supplier_delivery.html.twig", "eggs_inputs/show.html.twig", 83)->display($context);
        // line 84
        echo "                    </div>
                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "eggs_inputs/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  192 => 84,  190 => 83,  183 => 78,  181 => 77,  171 => 69,  169 => 68,  162 => 63,  160 => 62,  150 => 54,  148 => 53,  145 => 52,  139 => 49,  138 => 47,  134 => 46,  133 => 45,  128 => 43,  122 => 40,  121 => 39,  117 => 38,  115 => 37,  109 => 35,  107 => 34,  104 => 33,  102 => 32,  99 => 31,  97 => 30,  91 => 28,  89 => 27,  86 => 26,  84 => 25,  79 => 24,  77 => 23,  71 => 20,  67 => 19,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "eggs_inputs/show.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/eggs_inputs/show.html.twig");
    }
}
