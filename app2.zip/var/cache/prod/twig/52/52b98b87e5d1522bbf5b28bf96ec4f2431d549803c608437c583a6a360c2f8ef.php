<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/tables/deliveries.html.twig */
class __TwigTemplate_5afa6e7b0d9c5108b01d2ba1814c5369a06ca9056aa6258a2442af9dd10467e7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<hr/>
<div class=\"accordion accordion-flush\" id=\"accordionFlushDeliveries\">
    <div class=\"accordion-item\">
        <h2 class=\"accordion-header\" id=\"flush-headingOne\">
            <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\"
                    data-bs-target=\"#flush-collapseOne\" aria-expanded=\"false\" aria-controls=\"flush-collapseOne\">
                ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.modal.title.eggs", [], "messages");
        // line 8
        echo "            </button>
        </h2>
        <div id=\"flush-collapseOne\" class=\"accordion-collapse collapse\" aria-labelledby=\"flush-headingOne\"
             data-bs-parent=\"#accordionFlushDeliveries\">
            <div class=\"accordion-body\">
                <table class=\"table table-sm\">
                    <thead>
                    <tr>
                        <th>";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.herd.name", [], "messages");
        echo "</th>
                        <th>";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.herd.age", [], "messages");
        echo "</th>
                        <th>";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.deliveryEggsNumber", [], "messages");
        echo "</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["dayPlans"] ?? null), "dayDeliveries", [], "any", false, false, false, 22));
        foreach ($context['_seq'] as $context["_key"] => $context["plans"]) {
            // line 23
            echo "                        <tr>
                            <td>";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plans"], "herd", [], "any", false, false, false, 24), "name", [], "any", false, false, false, 24), "html", null, true);
            echo "</td>
                            ";
            // line 25
            $context["difference"] = twig_get_attribute($this->env, $this->source, twig_date_converter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "deliveryDate", [], "any", false, false, false, 25)), "diff", [0 => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plans"], "herd", [], "any", false, false, false, 25), "hatchingDate", [], "any", false, false, false, 25)], "method", false, false, false, 25);
            // line 26
            echo "                            ";
            $context["days"] = twig_get_attribute($this->env, $this->source, ($context["difference"] ?? null), "days", [], "any", false, false, false, 26);
            // line 27
            echo "                            ";
            $context["weeks"] = (($context["days"] ?? null) / 7);
            // line 28
            echo "                            <td>
                                ";
            // line 29
            echo twig_escape_filter($this->env, ($context["days"] ?? null), "html", null, true);
            echo " ";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.herd.day", [], "messages");
            // line 30
            echo "                                ";
            echo twig_escape_filter($this->env, twig_round(($context["weeks"] ?? null), 0, "floor"), "html", null, true);
            echo " ";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.herd.week", [], "messages");
            // line 31
            echo "                            </td>
                            <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "eggsNumber", [], "any", false, false, false, 32), "html", null, true);
            echo "</td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "plans/tables/deliveries.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 35,  106 => 32,  103 => 31,  98 => 30,  94 => 29,  91 => 28,  88 => 27,  85 => 26,  83 => 25,  79 => 24,  76 => 23,  72 => 22,  65 => 18,  61 => 17,  57 => 16,  47 => 8,  45 => 7,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/tables/deliveries.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/tables/deliveries.html.twig");
    }
}
