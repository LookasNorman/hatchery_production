<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/year.html.twig */
class __TwigTemplate_15cb0c82519133f82a66926d18c527adcdf43d312c42e8efa5c254a54a646dd7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"row row-cols-1 row-cols-md-4 g-4\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["weeksPlans"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["weekPlans"]) {
            // line 3
            echo "        <div class=\"col\">
            <div class=\"card border-info\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">";
            // line 6
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.week", [], "messages");
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["weekPlans"], "week", [], "any", false, false, false, 6), "html", null, true);
            echo "</h5>
                    ";
            // line 7
            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["weekPlans"], "weekPlans", [], "any", false, true, false, 7), "chicks", [], "any", true, true, false, 7)) {
                // line 8
                echo "                        ";
                $this->loadTemplate("plans/weekPlansWeekly.html.twig", "plans/year.html.twig", 8)->display($context);
                // line 9
                echo "                    ";
            } else {
                // line 10
                echo "                        ";
                $this->loadTemplate("plans/weekPlansDaily.html.twig", "plans/year.html.twig", 10)->display($context);
                // line 11
                echo "                    ";
            }
            // line 12
            echo "                </div>
            </div>
        </div>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['weekPlans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "plans/year.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 16,  82 => 12,  79 => 11,  76 => 10,  73 => 9,  70 => 8,  68 => 7,  62 => 6,  57 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/year.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/year.html.twig");
    }
}
