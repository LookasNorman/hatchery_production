<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* eggs_delivery/production/_form.html.twig */
class __TwigTemplate_82a3eb69cb046d78f63bd0e83319d99076cf3b197024a7e7c79dcb702c98e13b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        echo "
<div class=\"form-group\">
    <label>";
        // line 3
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "deliveryDate", [], "any", false, false, false, 3), 'label');
        echo "</label>
    ";
        // line 4
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "deliveryDate", [], "any", false, false, false, 4), 'widget');
        echo "
    <small>";
        // line 5
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "deliveryDate", [], "any", false, false, false, 5), 'help');
        echo "</small>
    <div class=\"form-text text-danger\">
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "deliveryDate", [], "any", false, false, false, 7), 'errors');
        echo "
    </div>
</div>
<div class=\"form-group\">
    <label>";
        // line 11
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "eggsNumber", [], "any", false, false, false, 11), 'label');
        echo "</label>
    ";
        // line 12
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "eggsNumber", [], "any", false, false, false, 12), 'widget');
        echo "
    <small>";
        // line 13
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "eggsNumber", [], "any", false, false, false, 13), 'help');
        echo "</small>
    <div class=\"form-text text-danger\">
        ";
        // line 15
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "eggsNumber", [], "any", false, false, false, 15), 'errors');
        echo "
    </div>
</div>
<div class=\"form-group\">
    <label>";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "herd", [], "any", false, false, false, 19), 'label');
        echo "</label>
    ";
        // line 20
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "herd", [], "any", false, false, false, 20), 'widget');
        echo "
    <small>";
        // line 21
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "herd", [], "any", false, false, false, 21), 'help');
        echo "</small>
    <div class=\"form-text text-danger\">
        ";
        // line 23
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "herd", [], "any", false, false, false, 23), 'errors');
        echo "
    </div>
</div>
";
        // line 26
        echo twig_include($this->env, $context, "layout/buttons/create.html.twig", ["text" => "eggs_delivery.form.button.save"]);
        echo "
";
        // line 27
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        echo "
";
    }

    public function getTemplateName()
    {
        return "eggs_delivery/production/_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 27,  101 => 26,  95 => 23,  90 => 21,  86 => 20,  82 => 19,  75 => 15,  70 => 13,  66 => 12,  62 => 11,  55 => 7,  50 => 5,  46 => 4,  42 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "eggs_delivery/production/_form.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/eggs_delivery/production/_form.html.twig");
    }
}
