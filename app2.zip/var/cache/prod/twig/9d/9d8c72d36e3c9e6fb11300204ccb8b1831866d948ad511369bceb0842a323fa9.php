<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* chick_temperature/edit.html.twig */
class __TwigTemplate_3437db574815cda68121e1f711694cfd3dd21aec85458298441438e7b2f55a0f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "chick_temperature/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 20
        $this->loadTemplate("layout/cards/chead.html.twig", "chick_temperature/edit.html.twig", 20)->display($context);
        // line 21
        echo "            ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.edit.title", [], "messages");
        // line 22
        echo "            ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "chick_temperature/edit.html.twig", 22)->display($context);
        // line 23
        echo "            ";
        echo twig_include($this->env, $context, "chick_temperature/_form.html.twig", ["button_label" => "Update"]);
        echo "
            ";
        // line 24
        $this->loadTemplate("layout/cards/cfooter.html.twig", "chick_temperature/edit.html.twig", 24)->display($context);
        // line 25
        echo "            ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 26
            echo "                ";
            echo twig_include($this->env, $context, "chick_temperature/_delete_form.html.twig");
            echo "
            ";
        }
        // line 28
        echo "            ";
        $this->loadTemplate("layout/cards/cend.html.twig", "chick_temperature/edit.html.twig", 28)->display($context);
        // line 29
        echo "        </div>
        ";
        // line 30
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chick_temperature_index"), "text" => "chick_temperature.edit.button.back"]);
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "chick_temperature/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 30,  95 => 29,  92 => 28,  86 => 26,  83 => 25,  81 => 24,  76 => 23,  73 => 22,  70 => 21,  68 => 20,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "chick_temperature/edit.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/chick_temperature/edit.html.twig");
    }
}
