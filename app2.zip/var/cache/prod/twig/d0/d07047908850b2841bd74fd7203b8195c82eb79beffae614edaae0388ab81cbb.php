<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/inputs/index.html.twig */
class __TwigTemplate_c4f95712807dee198a342d455eb6d21cadacbb7fbc5ec1801f5537e07999cf78 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "plans/inputs/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .card {
            max-width: 500px;
            min-width: 380px;
            padding: 6px 6px;
        }
    </style>
    <div class=\"row m-2\">
        <div class=\"col-sm-6\">
            <div class=\"card\">
                ";
        // line 14
        $context["hatcher"] = 0;
        // line 15
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["deliveriesChicks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["deliveryChicks"]) {
            // line 16
            echo "                ";
            $context["hatcher"] = (($context["hatcher"] ?? null) + ((twig_get_attribute($this->env, $this->source, $context["deliveryChicks"], "chickNumber", [], "any", false, false, false, 16) / (twig_get_attribute($this->env, $this->source, ($context["indicators"] ?? null), "transferHatchability", [], "any", false, false, false, 16) / 100)) / twig_get_attribute($this->env, $this->source, ($context["indicators"] ?? null), "hatchersCapacity", [], "any", false, false, false, 16)));
            // line 17
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['deliveryChicks'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "                ";
        $context["hatchersColor"] = (((1 === twig_compare(($context["hatcher"] ?? null), twig_get_attribute($this->env, $this->source, ($context["indicators"] ?? null), "hatchersNumber", [], "any", false, false, false, 18)))) ? ("text-danger") : ("text-dark"));
        // line 19
        echo "                <h5 class=\"card-header\">Poniedziałek
                    <span class=\"";
        // line 20
        echo twig_escape_filter($this->env, ($context["hatchersColor"] ?? null), "html", null, true);
        echo "\">KK - ";
        echo twig_escape_filter($this->env, twig_round(($context["hatcher"] ?? null), 1), "html", null, true);
        echo " z ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["indicators"] ?? null), "hatchersNumber", [], "any", false, false, false, 20), "html", null, true);
        echo "</span>
                </h5>
                <div class=\"card-body\">
                    <div class=\"card\">
                        <div class=\"accordion accordion-flush\" id=\"accordionFlushExample\">
                            ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["deliveriesChicks"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["deliveryChicks"]) {
            // line 26
            echo "                            <div class=\"accordion-item\">
                                <h2 class=\"accordion-header\" id=\"flush-heading";
            // line 27
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\">
                                    <button
                                            class=\"accordion-button collapsed\"
                                            type=\"button\"
                                            data-bs-toggle=\"collapse\"
                                            data-bs-target=\"#flush-collapse";
            // line 32
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\"
                                            aria-expanded=\"false\"
                                            aria-controls=\"flush-collapse";
            // line 34
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\"
                                    >
                                        ";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["deliveryChicks"], "chickFarm", [], "any", false, false, false, 36), "name", [], "any", false, false, false, 36), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["deliveryChicks"], "chickNumber", [], "any", false, false, false, 36), "html", null, true);
            echo "
                                    </button>
                                </h2>
                                <div
                                        id=\"flush-collapse";
            // line 40
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\"
                                        class=\"accordion-collapse collapse\"
                                        aria-labelledby=\"flush-heading";
            // line 42
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\"
                                        data-bs-parent=\"#accordionFlushExample\"
                                >
                                    <div class=\"accordion-body\">
                                        <dl class=\"row\">
                                            <dt class=\"col-sm-9\">Czaplin 9-14</dt>
                                            <dd class=\"col-sm-3\">48000</dd>
                                        </dl>
                                    </div>
                                </div>
                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['deliveryChicks'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "                        </div>
                    </div>
                    <a href=\"#\" class=\"btn btn-primary\">Zatwierdź nakład</a>
                </div>
            </div>
        </div>
        <div class=\"col-sm-6\">
            <div class=\"card\">
                <h5 class=\"card-header\">Wtorek KK - 14 z 14</h5>
                <div class=\"card-body\">
                    <h5 class=\"card-title\"></h5>
                    <p class=\"card-text\">With supporting text below as a natural lead-in to additional content.</p>
                    <a href=\"#\" class=\"btn btn-primary\">Go somewhere</a>
                </div>
            </div>
        </div>
    </div>

    <div class=\"row m-2\">
        <div class=\"col-sm-6\">
            <div class=\"card\">
                <h5 class=\"card-header\">Czwartek</h5>
                <div class=\"card-body\">
                    <h5 class=\"card-title\">KK - 11</h5>
                    <p class=\"card-text\">With supporting text below as a natural lead-in to additional content.</p>
                    <a href=\"#\" class=\"btn btn-primary\">Go somewhere</a>
                </div>
            </div>
        </div>
        <div class=\"col-sm-6\">
            <div class=\"card\">
                <h5 class=\"card-header\">Piątek</h5>
                <div class=\"card-body\">
                    <h5 class=\"card-title\">KK - 11</h5>
                    <p class=\"card-text\">With supporting text below as a natural lead-in to additional content.</p>
                    <a href=\"#\" class=\"btn btn-primary\">Go somewhere</a>
                </div>
            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "plans/inputs/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 54,  135 => 42,  130 => 40,  121 => 36,  116 => 34,  111 => 32,  103 => 27,  100 => 26,  96 => 25,  84 => 20,  81 => 19,  78 => 18,  72 => 17,  69 => 16,  64 => 15,  62 => 14,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/inputs/index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/inputs/index.html.twig");
    }
}
