<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plan_delivery_chick/list_plan_chick.html.twig */
class __TwigTemplate_85813e1105195a9aec1a17203cdb46ad0f4de27e57ad75acc41a90a16d61dd09 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $this->loadTemplate("layout/tables/thead.html.twig", "plan_delivery_chick/list_plan_chick.html.twig", 1)->display($context);
        // line 2
        echo "<tr>
    <th>";
        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.breed", [], "messages");
        echo "</th>
    <th>";
        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.chick_farm", [], "messages");
        echo "</th>
    <th>";
        // line 5
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.chick_number", [], "messages");
        echo "</th>
    <th>";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.delivery_date", [], "messages");
        echo "</th>
    <th>";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.input_date", [], "messages");
        echo "</th>
    <th class=\"d-print-none\">";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.lighting_date", [], "messages");
        echo "</th>
    <th class=\"d-print-none\">";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.transfer_date", [], "messages");
        echo "</th>
    <th class=\"d-print-none\">";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.setters", [], "messages");
        echo "</th>
    <th class=\"d-print-none\">";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.hatchers", [], "messages");
        echo "</th>
    <th class=\"d-print-none\">";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_delivery_chick.list_plan_chick.actions", [], "messages");
        echo "</th>
</tr>
";
        // line 14
        $this->loadTemplate("layout/tables/tbody.html.twig", "plan_delivery_chick/list_plan_chick.html.twig", 14)->display($context);
        // line 15
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["plan_delivery_chicks"] ?? null));
        $context['_iterated'] = false;
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["plan_delivery_chick"]) {
            // line 16
            echo "        <tr>
            <td>
                ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "breed", [], "any", false, false, false, 18));
            foreach ($context['_seq'] as $context["_key"] => $context["breed"]) {
                // line 19
                echo "                    ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["breed"], "name", [], "any", false, false, false, 19), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["breed"], "type", [], "any", false, false, false, 19), "html", null, true);
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['breed'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 21
            echo "            </td>
            <td>
                <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chicks_recipient_show", ["id" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "chickFarm", [], "any", false, false, false, 23), "id", [], "any", false, false, false, 23)]), "html", null, true);
            echo "\">
                    ";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "chickFarm", [], "any", false, false, false, 24), "customer", [], "any", false, false, false, 24), "name", [], "any", false, false, false, 24), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "chickFarm", [], "any", false, false, false, 24), "name", [], "any", false, false, false, 24), "html", null, true);
            echo "
                </a>
            </td>
            <td class=\"text-nowrap\">";
            // line 27
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "chickNumber", [], "any", false, false, false, 27), 0, ",", " "), "html", null, true);
            echo "</td>
            <td>";
            // line 28
            ((twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "deliveryDate", [], "any", false, false, false, 28)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "deliveryDate", [], "any", false, false, false, 28), "full", "short", "", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
            echo "</td>
            <td>";
            // line 29
            ((twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "inputDate", [], "any", false, false, false, 29)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "inputDate", [], "any", false, false, false, 29), "full", "short", "", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
            echo "</td>
            <td class=\"d-print-none\">";
            // line 30
            ((twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "lightingDate", [], "any", false, false, false, 30)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "lightingDate", [], "any", false, false, false, 30), "long", "none", "", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
            echo "</td>
            <td class=\"d-print-none\">";
            // line 31
            ((twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "transferDate", [], "any", false, false, false, 31)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "transferDate", [], "any", false, false, false, 31), "long", "none", "", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
            echo "</td>
            <td class=\"d-print-none\">
                ";
            // line 33
            $context["setterNumber"] = ((twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "chickNumber", [], "any", false, false, false, 33) / (twig_get_attribute($this->env, $this->source, ($context["plan_indicators"] ?? null), "hatchability", [], "any", false, false, false, 33) / 100)) / 57600);
            // line 34
            echo "                ";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["setterNumber"] ?? null), 1, ",", " "), "html", null, true);
            echo "
            </td>
            <td class=\"d-print-none\">
                ";
            // line 37
            $context["hatcherNumber"] = ((twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "chickNumber", [], "any", false, false, false, 37) / (twig_get_attribute($this->env, $this->source, ($context["plan_indicators"] ?? null), "transferHatchability", [], "any", false, false, false, 37) / 100)) / 19200);
            // line 38
            echo "                ";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["hatcherNumber"] ?? null), 1, ",", " "), "html", null, true);
            echo "
            </td>
            <td class=\"d-print-none\">
                <span class=\"btn-group\">
                    ";
            // line 42
            echo twig_include($this->env, $context, "layout/buttons/list_show.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_delivery_chick_show", ["id" => twig_get_attribute($this->env, $this->source,             // line 43
$context["plan_delivery_chick"], "id", [], "any", false, false, false, 43)])]);
            echo "
                    ";
            // line 44
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_PRODUCTION")) {
                // line 45
                echo "                        ";
                echo twig_include($this->env, $context, "layout/buttons/list_edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_delivery_chick_edit", ["id" => twig_get_attribute($this->env, $this->source,                 // line 46
$context["plan_delivery_chick"], "id", [], "any", false, false, false, 46)])]);
                echo "
                    ";
            }
            // line 48
            echo "                    ";
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
                // line 49
                echo "                        ";
                echo twig_include($this->env, $context, "plan_delivery_chick/_delete_trash_form.html.twig", ["id" => twig_get_attribute($this->env, $this->source, $context["plan_delivery_chick"], "id", [], "any", false, false, false, 49)]);
                echo "
                    ";
            }
            // line 51
            echo "                </span>
            </td>
        </tr>
    ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 55
            echo "        <tr>
            <td colspan=\"7\">no records found</td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plan_delivery_chick'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        $this->loadTemplate("layout/tables/tfooter.html.twig", "plan_delivery_chick/list_plan_chick.html.twig", 59)->display($context);
        // line 60
        $this->loadTemplate("layout/tables/tend.html.twig", "plan_delivery_chick/list_plan_chick.html.twig", 60)->display($context);
    }

    public function getTemplateName()
    {
        return "plan_delivery_chick/list_plan_chick.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 60,  227 => 59,  218 => 55,  202 => 51,  196 => 49,  193 => 48,  188 => 46,  186 => 45,  184 => 44,  180 => 43,  179 => 42,  171 => 38,  169 => 37,  162 => 34,  160 => 33,  155 => 31,  151 => 30,  147 => 29,  143 => 28,  139 => 27,  131 => 24,  127 => 23,  123 => 21,  112 => 19,  108 => 18,  104 => 16,  85 => 15,  83 => 14,  78 => 12,  74 => 11,  70 => 10,  66 => 9,  62 => 8,  58 => 7,  54 => 6,  50 => 5,  46 => 4,  42 => 3,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plan_delivery_chick/list_plan_chick.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plan_delivery_chick/list_plan_chick.html.twig");
    }
}
