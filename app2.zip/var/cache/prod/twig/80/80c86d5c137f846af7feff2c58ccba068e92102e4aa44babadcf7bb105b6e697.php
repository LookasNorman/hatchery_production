<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* driver/new.html.twig */
class __TwigTemplate_8ce3e7f921970063d49ef30bd6030fa26c60a13f5af7d138ebf46437c8c8df2e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "driver/new.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"d-flex justify-content-center card-group\">
        ";
        // line 5
        $this->loadTemplate("layout/cards/chead.html.twig", "driver/new.html.twig", 5)->display($context);
        // line 6
        echo "        <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>
        <i class=\"fa fa-user\" aria-hidden=\"true\"></i> ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("driver.new.title", [], "messages");
        // line 8
        echo "        ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "driver/new.html.twig", 8)->display($context);
        // line 9
        echo "        ";
        echo twig_include($this->env, $context, "driver/_form.html.twig");
        echo "
        ";
        // line 10
        $this->loadTemplate("layout/cards/cfooter.html.twig", "driver/new.html.twig", 10)->display($context);
        // line 11
        echo "        ";
        $this->loadTemplate("layout/cards/cend.html.twig", "driver/new.html.twig", 11)->display($context);
        // line 12
        echo "    </div>
    ";
        // line 13
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("driver_index"), "text" => "driver.new.button.back"]);
        echo "

";
    }

    public function getTemplateName()
    {
        return "driver/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 13,  73 => 12,  70 => 11,  68 => 10,  63 => 9,  60 => 8,  58 => 7,  55 => 6,  53 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "driver/new.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/driver/new.html.twig");
    }
}
