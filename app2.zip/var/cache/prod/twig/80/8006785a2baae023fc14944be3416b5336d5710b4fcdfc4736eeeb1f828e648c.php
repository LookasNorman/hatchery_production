<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* eggs_inputs_transfers/new.html.twig */
class __TwigTemplate_ae7044b0a6faed81a2582ce339ff4bb39a5d38370d22d1553a71cc316ab84a06 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "eggs_inputs_transfers/new.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 20
        $this->loadTemplate("layout/cards/chead.html.twig", "eggs_inputs_transfers/new.html.twig", 20)->display($context);
        // line 21
        echo "            ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.new.title", [], "messages");
        echo ": <span
                    class=\"fw-bold fs-4\">";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["input"] ?? null), "name", [], "any", false, false, false, 22), "html", null, true);
        echo "</span><br/>
            ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.new.farm", [], "messages");
        echo ": <span
                    class=\"fw-bold fs-4\">";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["farm"] ?? null), "chicksFarm", [], "any", false, false, false, 24), "name", [], "any", false, false, false, 24), "html", null, true);
        echo "</span><br/>
            ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.new.herd", [], "messages");
        echo ": <span class=\"fw-bold fs-4\">";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["herd"] ?? null), "name", [], "any", false, false, false, 25), "html", null, true);
        echo "</span>
            ";
        // line 26
        $this->loadTemplate("layout/cards/cbody.html.twig", "eggs_inputs_transfers/new.html.twig", 26)->display($context);
        // line 27
        echo "            ";
        echo twig_include($this->env, $context, "eggs_inputs_transfers/production/_form_production.html.twig");
        echo "
            ";
        // line 28
        $this->loadTemplate("layout/cards/cfooter.html.twig", "eggs_inputs_transfers/new.html.twig", 28)->display($context);
        // line 29
        echo "            ";
        $this->loadTemplate("layout/cards/cend.html.twig", "eggs_inputs_transfers/new.html.twig", 29)->display($context);
        // line 30
        echo "        </div>
        ";
        // line 31
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("eggs_inputs_show", ["id" => twig_get_attribute($this->env, $this->source,         // line 32
($context["input"] ?? null), "id", [], "any", false, false, false, 32)]), "text" => "eggs_inputs_transfer.new.button.back"]);
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "eggs_inputs_transfers/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 32,  108 => 31,  105 => 30,  102 => 29,  100 => 28,  95 => 27,  93 => 26,  87 => 25,  83 => 24,  79 => 23,  75 => 22,  70 => 21,  68 => 20,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "eggs_inputs_transfers/new.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/eggs_inputs_transfers/new.html.twig");
    }
}
