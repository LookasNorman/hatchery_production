<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/breed.html.twig */
class __TwigTemplate_d46d54d1c7a3c63dd4f36b3a88851551aa944e1058fdbb0110850bf2fe71d6d7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<ul class=\"nav nav-tabs\" id=\"yearTab\" role=\"tablist\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "yearsPlans", [], "any", false, false, false, 2));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["weeksPlans"]) {
            // line 3
            echo "        <li class=\"nav-item\" role=\"presentation\">
            ";
            // line 4
            if (twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 4)) {
                // line 5
                echo "                <button class=\"nav-link active\" id=\"year-tab_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 5), "id", [], "any", false, false, false, 5), "html", null, true);
                echo "\" data-bs-toggle=\"tab\"
                        data-bs-target=\"#year_";
                // line 6
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 6), "id", [], "any", false, false, false, 6), "html", null, true);
                echo "\"
                        type=\"button\"
                        role=\"tab\" aria-controls=\"year_";
                // line 8
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" aria-selected=\"true\">";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["key"]), "html", null, true);
                echo "
                </button>
            ";
            } else {
                // line 11
                echo "                <button class=\"nav-link\" id=\"year-tab_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" data-bs-toggle=\"tab\"
                        data-bs-target=\"#year_";
                // line 12
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 12), "id", [], "any", false, false, false, 12), "html", null, true);
                echo "\"
                        type=\"button\"
                        role=\"tab\" aria-controls=\"year_";
                // line 14
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 14), "id", [], "any", false, false, false, 14), "html", null, true);
                echo "\" aria-selected=\"true\">";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "
                </button>
            ";
            }
            // line 17
            echo "        </li>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['weeksPlans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "</ul>
<div class=\"tab-content\" id=\"yearTabContent\">
    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "yearsPlans", [], "any", false, false, false, 21));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["weeksPlans"]) {
            // line 22
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 22)) {
                // line 23
                echo "            <div class=\"tab-pane fade show active\" id=\"year_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 23), "id", [], "any", false, false, false, 23), "html", null, true);
                echo "\" role=\"tabpanel\"
                 aria-labelledby=\"year-tab_";
                // line 24
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 24), "id", [], "any", false, false, false, 24), "html", null, true);
                echo "\">
                ";
                // line 25
                $this->loadTemplate("plans/year.html.twig", "plans/breed.html.twig", 25)->display($context);
                // line 26
                echo "            </div>
        ";
            } else {
                // line 28
                echo "            <div class=\"tab-pane fade show\" id=\"year_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 28), "id", [], "any", false, false, false, 28), "html", null, true);
                echo "\" role=\"tabpanel\"
                 aria-labelledby=\"year-tab_";
                // line 29
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 29), "id", [], "any", false, false, false, 29), "html", null, true);
                echo "\">
                ";
                // line 30
                $this->loadTemplate("plans/year.html.twig", "plans/breed.html.twig", 30)->display($context);
                // line 31
                echo "            </div>
        ";
            }
            // line 33
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['weeksPlans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "plans/breed.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  189 => 34,  175 => 33,  171 => 31,  169 => 30,  164 => 29,  158 => 28,  154 => 26,  152 => 25,  147 => 24,  141 => 23,  138 => 22,  121 => 21,  117 => 19,  102 => 17,  93 => 14,  87 => 12,  82 => 11,  74 => 8,  68 => 6,  62 => 5,  60 => 4,  57 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/breed.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/breed.html.twig");
    }
}
