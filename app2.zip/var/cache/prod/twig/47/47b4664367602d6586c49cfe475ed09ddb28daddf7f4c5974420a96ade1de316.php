<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* input_delivery/production/herd.html.twig */
class __TwigTemplate_cecfde204bf109771ac238eb3422f5a4d20fda7d82de738f5daef50dc94565ac extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "input_delivery/production/herd.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"text-center m-2\">
        <h1>
            ";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.production.herd.title", [], "messages");
        // line 7
        echo "        </h1>
        <h3>
            ";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.production.herd.input", [], "messages");
        echo ": ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["input"] ?? null), "name", [], "any", false, false, false, 9), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["input"] ?? null), "inputDate", [], "any", false, false, false, 9), "Y-m-d"), "html", null, true);
        echo "
        </h3>
        <h3>";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs.production.herd.breeder", [], "messages");
        echo ": ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["breeder"] ?? null), "name", [], "any", false, false, false, 11), "html", null, true);
        echo "</h3>
    </div>
    <div class=\"d-flex justify-content-center flex-wrap\">
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["herds"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["herd"]) {
            // line 15
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("production_inputs_new", ["herd" => twig_get_attribute($this->env, $this->source, $context["herd"], "id", [], "any", false, false, false, 15), "input" => twig_get_attribute($this->env, $this->source, ($context["input"] ?? null), "id", [], "any", false, false, false, 15)]), "html", null, true);
            echo "\" class=\"btn btn-info p-2 m-2 col-sm-3\">
                <span class=\"m-4\"><i class=\"fas fa-egg fa-2x\"></i></span>
                <span class=\"h1\">";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["herd"], "name", [], "any", false, false, false, 17), "html", null, true);
            echo "</span>
            </a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['herd'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "input_delivery/production/herd.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 20,  87 => 17,  81 => 15,  77 => 14,  69 => 11,  60 => 9,  56 => 7,  54 => 6,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "input_delivery/production/herd.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/input_delivery/production/herd.html.twig");
    }
}
