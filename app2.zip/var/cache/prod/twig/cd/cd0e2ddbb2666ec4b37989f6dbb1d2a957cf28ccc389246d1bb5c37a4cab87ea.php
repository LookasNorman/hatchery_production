<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* customer/edit.html.twig */
class __TwigTemplate_d60eb0ff6028857f492f5e38caea24fcd7410f9efe474342733d93ded7cf62c1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "customer/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <h1>";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.edit.title", [], "messages");
        echo "</h1>

        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 22
        $this->loadTemplate("layout/cards/chead.html.twig", "customer/edit.html.twig", 22)->display($context);
        // line 23
        echo "            ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("customer.edit.header", [], "messages");
        // line 24
        echo "            ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "customer/edit.html.twig", 24)->display($context);
        // line 25
        echo "            ";
        echo twig_include($this->env, $context, "customer/_form.html.twig", ["button_label" => "customer.edit.button.update"]);
        echo "
            ";
        // line 26
        $this->loadTemplate("layout/cards/cfooter.html.twig", "customer/edit.html.twig", 26)->display($context);
        // line 27
        echo "            ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 28
            echo "                ";
            echo twig_include($this->env, $context, "customer/_delete_form.html.twig");
            echo "
            ";
        }
        // line 30
        echo "            ";
        $this->loadTemplate("layout/cards/cend.html.twig", "customer/edit.html.twig", 30)->display($context);
        // line 31
        echo "        </div>
        ";
        // line 32
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_index"), "text" => "customer.edit.button.back"]);
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "customer/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 32,  100 => 31,  97 => 30,  91 => 28,  88 => 27,  86 => 26,  81 => 25,  78 => 24,  75 => 23,  73 => 22,  67 => 19,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "customer/edit.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/customer/edit.html.twig");
    }
}
