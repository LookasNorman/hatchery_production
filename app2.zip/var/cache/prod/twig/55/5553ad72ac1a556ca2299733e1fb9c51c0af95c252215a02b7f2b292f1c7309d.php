<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* eggs_inputs_transfers/index.html.twig */
class __TwigTemplate_2472d549d78fe243d1b13f105246723aab4f9d5064630db55ef2bd730e750e45 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "eggs_inputs_transfers/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">

        <h1>
            ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.title", [], "messages");
        // line 22
        echo "        </h1>
        ";
        // line 23
        $this->loadTemplate("layout/tables/thead.html.twig", "eggs_inputs_transfers/index.html.twig", 23)->display($context);
        // line 24
        echo "        <tr>
            <th>";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.id", [], "messages");
        echo "</th>
            <th class=\"text-center\">";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.transfers_egg", [], "messages");
        echo "</th>
            <th class=\"text-center\">";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.transfer_date", [], "messages");
        echo "</th>
            <th class=\"text-center\">";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.herd", [], "messages");
        echo "</th>
            <th class=\"text-center\">";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.farm", [], "messages");
        echo "</th>
            <th class=\"text-center\">";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.input", [], "messages");
        echo "</th>
            <th class=\"text-center\">";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.action", [], "messages");
        echo "</th>
        </tr>
        ";
        // line 33
        $this->loadTemplate("layout/tables/tbody.html.twig", "eggs_inputs_transfers/index.html.twig", 33)->display($context);
        // line 34
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["eggs_inputs_transfers"] ?? null));
        $context['_iterated'] = false;
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["eggs_inputs_transfer"]) {
            // line 35
            echo "            <tr>
                <td>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "id", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
                <td class=\"text-center\">";
            // line 37
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "transfersEgg", [], "any", false, false, false, 37), 0, ",", " "), "html", null, true);
            echo "</td>
                <td class=\"text-center\">";
            // line 38
            ((twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "transferDate", [], "any", false, false, false, 38)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "transferDate", [], "any", false, false, false, 38), "Y-m-d"), "html", null, true))) : (print ("")));
            echo "</td>
                <td class=\"text-center\">";
            // line 39
            ((twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "herd", [], "any", false, false, false, 39)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "herd", [], "any", false, false, false, 39), "breeder", [], "any", false, false, false, 39), "name", [], "any", false, false, false, 39), "html", null, true))) : (print ("")));
            echo "
                    - ";
            // line 40
            ((twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "herd", [], "any", false, false, false, 40)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "herd", [], "any", false, false, false, 40), "name", [], "any", false, false, false, 40), "html", null, true))) : (print ("")));
            echo "</td>
                <td class=\"text-center\">";
            // line 41
            ((twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "farm", [], "any", false, false, false, 41)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "farm", [], "any", false, false, false, 41), "chicksFarm", [], "any", false, false, false, 41), "customer", [], "any", false, false, false, 41), "name", [], "any", false, false, false, 41), "html", null, true))) : (print ("")));
            echo "
                    - ";
            // line 42
            ((twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "farm", [], "any", false, false, false, 42)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "farm", [], "any", false, false, false, 42), "chicksFarm", [], "any", false, false, false, 42), "name", [], "any", false, false, false, 42), "html", null, true))) : (print ("")));
            echo "</td>
                <td class=\"text-center\">";
            // line 43
            ((twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "input", [], "any", false, false, false, 43)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["eggs_inputs_transfer"], "input", [], "any", false, false, false, 43), "name", [], "any", false, false, false, 43), "html", null, true))) : (print ("")));
            echo "</td>
                <td class=\"text-center\">
                    <span class=\"btn-group\">
                    ";
            // line 46
            echo twig_include($this->env, $context, "layout/buttons/list_show.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("eggs_inputs_transfers_show", ["id" => twig_get_attribute($this->env, $this->source,             // line 47
$context["eggs_inputs_transfer"], "id", [], "any", false, false, false, 47)])]);
            echo "
                        ";
            // line 48
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
                // line 49
                echo "                            ";
                echo twig_include($this->env, $context, "layout/buttons/list_edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("eggs_inputs_transfers_edit", ["id" => twig_get_attribute($this->env, $this->source,                 // line 50
$context["eggs_inputs_transfer"], "id", [], "any", false, false, false, 50)])]);
                echo "
                        ";
            }
            // line 52
            echo "                        ";
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
                // line 53
                echo "                            ";
                echo twig_include($this->env, $context, "eggs_inputs_transfers/_delete_trash_form.html.twig");
                echo "
                        ";
            }
            // line 55
            echo "                    </span>
                </td>
            </tr>
        ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 59
            echo "            <tr>
                <td colspan=\"7\">
                    ";
            // line 61
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_inputs_transfer.index.table.no_found", [], "messages");
            // line 62
            echo "                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['eggs_inputs_transfer'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 65
        echo "        ";
        $this->loadTemplate("layout/tables/tfooter.html.twig", "eggs_inputs_transfers/index.html.twig", 65)->display($context);
        // line 66
        echo "        ";
        $this->loadTemplate("layout/tables/tend.html.twig", "eggs_inputs_transfers/index.html.twig", 66)->display($context);
        // line 67
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "eggs_inputs_transfers/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  225 => 67,  222 => 66,  219 => 65,  211 => 62,  209 => 61,  205 => 59,  189 => 55,  183 => 53,  180 => 52,  175 => 50,  173 => 49,  171 => 48,  167 => 47,  166 => 46,  160 => 43,  156 => 42,  152 => 41,  148 => 40,  144 => 39,  140 => 38,  136 => 37,  132 => 36,  129 => 35,  110 => 34,  108 => 33,  103 => 31,  99 => 30,  95 => 29,  91 => 28,  87 => 27,  83 => 26,  79 => 25,  76 => 24,  74 => 23,  71 => 22,  69 => 21,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "eggs_inputs_transfers/index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/eggs_inputs_transfers/index.html.twig");
    }
}
