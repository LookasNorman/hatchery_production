<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* customer/phone_modal_body.html.twig */
class __TwigTemplate_06c0cfddf2745a1da020891560363ff4de36f76c2e32efafa88ae455f5a24aa5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<style>
    .card {
        max-width: 350px;
        min-width: 300px;
        padding: 6px 6px;
    }
</style>
<div class=\"card-group\">
";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["customer"] ?? null), 0, [], "any", false, false, false, 9), "customerPhones", [], "any", false, false, false, 9));
        foreach ($context['_seq'] as $context["_key"] => $context["customer_phone"]) {
            // line 10
            echo "    <div class=\"card mb-3 m-2 border-dark shadow-sm p-3 mb-5 bg-body rounded\" style=\"max-width: 540px;\">
        <div class=\"row g-0\">
            <div class=\"col-md-4\">
                <img src=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/emptyPhoto.png"), "html", null, true);
            echo "\" sizes=\"\" class=\"img-fluid rounded-start\" alt=\"...\">
            </div>
            <div class=\"col-md-8\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["customer_phone"], "person", [], "any", false, false, false, 17), "html", null, true);
            echo "</h5>
                    <p class=\"card-text\">";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["customer_phone"], "phoneNumber", [], "any", false, false, false, 18), "html", null, true);
            echo "</p>
                </div>
            </div>
        </div>
    </div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['customer_phone'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "customer/phone_modal_body.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 24,  67 => 18,  63 => 17,  56 => 13,  51 => 10,  47 => 9,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "customer/phone_modal_body.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/customer/phone_modal_body.html.twig");
    }
}
