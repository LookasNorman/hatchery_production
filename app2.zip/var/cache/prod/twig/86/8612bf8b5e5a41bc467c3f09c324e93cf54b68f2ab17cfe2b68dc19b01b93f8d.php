<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* emails/inputReminder.html.twig */
class __TwigTemplate_72ebb3a85e3062f8f302a7a17a67331347408c3495716ee78b646c2df3f2bcfe extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
        \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>
    <title>ZWD Malec</title>
    <style type=\"text/css\">
        body {
            margin: 10px;
            padding: 10px;
            min-width: 100% !important;
            background-color: #FFFFFF;
        }

        .content {
            width: 100%;
            max-width: 600px;
        }
    </style>
</head>
<body>
<div class=\"card\">
    <h1 style=\"text-align: center\">";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.header", [], "messages");
        echo "</h1>
    ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["inputs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["input"]) {
            // line 25
            echo "        <h3>
            ";
            // line 26
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.input", [], "messages");
            echo ": ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["input"], "name", [], "any", false, false, false, 26), "html", null, true);
            echo "
            ";
            // line 27
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.delivery_date", [], "messages");
            echo ": ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, twig_get_attribute($this->env, $this->source, $context["input"], "inputDate", [], "any", false, false, false, 27), "+21 days"), "Y-m-d"), "html", null, true);
            echo "
            ";
            // line 28
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.slaughter_date", [], "messages");
            echo ": ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, twig_get_attribute($this->env, $this->source, $context["input"], "inputDate", [], "any", false, false, false, 28), "+63 days"), "Y-m-d"), "html", null, true);
            echo "
        </h3>
    <table class=\"content\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" border=\"1\"
           style=\"background-color: #ffffff; text-align: center\">
        <tr>
            <td style=\"padding-top: 10px\"><h3>";
            // line 33
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.farm", [], "messages");
            echo "</h3></td>
            <td style=\"padding-top: 10px\"><h3>";
            // line 34
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.chick", [], "messages");
            echo "</h3></td>
            <td style=\"padding-top: 10px\"><h3>";
            // line 35
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.next.input_date", [], "messages");
            echo "</h3></td>
            <td style=\"padding-top: 10px\"><h3>";
            // line 36
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("emails.input_reminder.next.delivery_date", [], "messages");
            echo "</h3></td>
        </tr>
        ";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["input"], "inputsFarms", [], "any", false, false, false, 38));
            foreach ($context['_seq'] as $context["_key"] => $context["farm"]) {
                // line 39
                echo "        <tr>
            <td style=\"padding-bottom: 10px\">";
                // line 40
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["farm"], "chicksFarm", [], "any", false, false, false, 40), "name", [], "any", false, false, false, 40), "html", null, true);
                echo "</td>
            <td style=\"padding-bottom: 10px\">";
                // line 41
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["farm"], "chickNumber", [], "any", false, false, false, 41), "html", null, true);
                echo "</td>
            <td style=\"padding-bottom: 10px\">";
                // line 42
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, twig_get_attribute($this->env, $this->source, $context["input"], "inputDate", [], "any", false, false, false, 42), "+59 days"), "Y-m-d"), "html", null, true);
                echo "</td>
            <td style=\"padding-bottom: 10px\">";
                // line 43
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, twig_get_attribute($this->env, $this->source, $context["input"], "inputDate", [], "any", false, false, false, 43), "+80 days"), "Y-m-d"), "html", null, true);
                echo "</td>
        </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['farm'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "    </table>
    <hr/>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['input'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "</div>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "emails/inputReminder.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 49,  139 => 46,  130 => 43,  126 => 42,  122 => 41,  118 => 40,  115 => 39,  111 => 38,  106 => 36,  102 => 35,  98 => 34,  94 => 33,  84 => 28,  78 => 27,  72 => 26,  69 => 25,  65 => 24,  61 => 23,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "emails/inputReminder.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/emails/inputReminder.html.twig");
    }
}
