<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/yearPlanSite.html.twig */
class __TwigTemplate_32dad43cf530dd4da5c84348b781670a9f13596e454a3f7aa009fa0038c105f0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "plans/yearPlanSite.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\">
        ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["links"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 6
            echo "            <a type=\"button\" href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_year_plan", ["yearN" => $context["link"]]), "html", null, true);
            echo "\" class=\"btn btn-primary m-2\">";
            echo twig_escape_filter($this->env, $context["link"], "html", null, true);
            echo "</a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "    </div>
    <h1>";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.year_plan_site.title", [], "messages");
        echo ": ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, ($context["year"] ?? null), "Y"), "html", null, true);
        echo "</h1>
    <nav>
        <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
            ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["plans"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["breed"] => $context["week"]) {
            // line 13
            echo "                ";
            if (twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 13)) {
                // line 14
                echo "                    <button class=\"nav-link active\" id=\"nav-";
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "-tab\" data-bs-toggle=\"tab\"
                            data-bs-target=\"#nav-";
                // line 15
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "\"
                            type=\"button\" role=\"tab\" aria-controls=\"nav-";
                // line 16
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "\" aria-selected=\"true\">";
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "
                    </button>
                ";
            } else {
                // line 19
                echo "                    <button class=\"nav-link\" id=\"nav-";
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "-tab\" data-bs-toggle=\"tab\"
                            data-bs-target=\"#nav-";
                // line 20
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "\"
                            type=\"button\" role=\"tab\" aria-controls=\"nav-";
                // line 21
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "\" aria-selected=\"false\">";
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "
                    </button>
                ";
            }
            // line 24
            echo "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['breed'], $context['week'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "        </div>
    </nav>
    <div class=\"tab-content\" id=\"nav-tabContent\">
        ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["plans"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["breed"] => $context["week"]) {
            // line 29
            echo "            ";
            if (twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 29)) {
                // line 30
                echo "                <div class=\"tab-pane fade show active\" id=\"nav-";
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "\" role=\"tabpanel\"
                     aria-labelledby=\"nav-";
                // line 31
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "-tab\">
                    ";
                // line 32
                $this->loadTemplate("plans/weekPlanSite.html.twig", "plans/yearPlanSite.html.twig", 32)->display($context);
                // line 33
                echo "                </div>
            ";
            } else {
                // line 35
                echo "                <div class=\"tab-pane fade\" id=\"nav-";
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "\" role=\"tabpanel\" aria-labelledby=\"nav-";
                echo twig_escape_filter($this->env, $context["breed"], "html", null, true);
                echo "-tab\">
                    ";
                // line 36
                $this->loadTemplate("plans/weekPlanSite.html.twig", "plans/yearPlanSite.html.twig", 36)->display($context);
                // line 37
                echo "                </div>
            ";
            }
            // line 39
            echo "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['breed'], $context['week'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "plans/yearPlanSite.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  214 => 40,  200 => 39,  196 => 37,  194 => 36,  187 => 35,  183 => 33,  181 => 32,  177 => 31,  172 => 30,  169 => 29,  152 => 28,  147 => 25,  133 => 24,  125 => 21,  121 => 20,  116 => 19,  108 => 16,  104 => 15,  99 => 14,  96 => 13,  79 => 12,  71 => 9,  68 => 8,  57 => 6,  53 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/yearPlanSite.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/yearPlanSite.html.twig");
    }
}
