<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/weekPlansDaily.html.twig */
class __TwigTemplate_bca0a61c4a6c1335d1a611e24f39b4d4b2185ba01fa5e971c649c28e7337b015 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["weekPlans"] ?? null), "weekPlans", [], "any", false, false, false, 1));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["dayPlans"]) {
            // line 2
            echo "    <h6 class=\"card-subtitle mb-2 text-muted\">
        ";
            // line 3
            ((twig_get_attribute($this->env, $this->source, $context["dayPlans"], "date", [], "any", false, false, false, 3)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "date", [], "any", false, false, false, 3), "medium", "medium", "eeee", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
            echo "
    </h6>
    <dl class=\"row\">
        <dt class=\"col-sm-6\">";
            // line 6
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.chicks", [], "messages");
            echo "</dt>
        <dd class=\"col-sm-6\">";
            // line 7
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "chicks", [], "any", false, false, false, 7), 0, ",", " "), "html", null, true);
            echo " </dd>
        <dt class=\"col-sm-6\">";
            // line 8
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.eggs_delivery", [], "messages");
            echo "</dt>
        <dd class=\"col-sm-6\">";
            // line 9
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "eggs", [], "any", false, false, false, 9), 0, ",", " "), "html", null, true);
            echo "</dd>
        <dt class=\"col-sm-6\">";
            // line 10
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.eggs_warehouse", [], "messages");
            echo "</dt>
        <dd class=\"col-sm-6\">";
            // line 11
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "eggsOnWarehouse", [], "any", false, false, false, 11), 0, ",", " "), "html", null, true);
            echo "</dd>
    </dl>

    <a href=\"#myModal";
            // line 14
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "date", [], "any", false, false, false, 14), "Y-m-d"), "html", null, true);
            echo "_";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["breedPlans"] ?? null), "breed", [], "any", false, false, false, 14), "name", [], "any", false, false, false, 14), "html", null, true);
            echo "\" data-bs-toggle=\"modal\"
       data-bs-target=\"#myModal";
            // line 15
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "date", [], "any", false, false, false, 15), "Y-m-d"), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.details", [], "messages");
            echo "</a>

    <!-- Modal -->
    <div class=\"modal fade\" id=\"myModal";
            // line 18
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "date", [], "any", false, false, false, 18), "Y-m-d"), "html", null, true);
            echo "\"
         data-bs-backdrop=\"static\" data-bs-keyboard=\"false\" tabindex=\"-1\"
         aria-labelledby=\"staticBackdropLabel\" aria-hidden=\"true\">
        <div class=\"modal-dialog modal-fullscreen\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\"
                        id=\"staticBackdropLabel\">";
            // line 25
            ((twig_get_attribute($this->env, $this->source, $context["dayPlans"], "date", [], "any", false, false, false, 25)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayPlans"], "date", [], "any", false, false, false, 25), "Y-m-d"), "html", null, true))) : (print ("")));
            echo "</h5>
                    <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\"
                            aria-label=\"Close\"></button>
                </div>
                <div class=\"modal-body\">
                    ";
            // line 30
            $this->loadTemplate("plans/tables/chicks.html.twig", "plans/weekPlansDaily.html.twig", 30)->display($context);
            // line 31
            echo "                    ";
            $this->loadTemplate("plans/tables/deliveries.html.twig", "plans/weekPlansDaily.html.twig", 31)->display($context);
            // line 32
            echo "                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-secondary\" data-bs-dismiss=\"modal\">
                        ";
            // line 35
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.modal.close", [], "messages");
            // line 36
            echo "                    </button>
                </div>
            </div>
        </div>
    </div>
    <hr/>
";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['dayPlans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "plans/weekPlansDaily.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 36,  131 => 35,  126 => 32,  123 => 31,  121 => 30,  113 => 25,  103 => 18,  95 => 15,  89 => 14,  83 => 11,  79 => 10,  75 => 9,  71 => 8,  67 => 7,  63 => 6,  57 => 3,  54 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/weekPlansDaily.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/weekPlansDaily.html.twig");
    }
}
