<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/tables/chicks.html.twig */
class __TwigTemplate_61b9a0597353a78fb7ae0152c452e4ebc52984dab9d80af57fda69526163e85d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"accordion accordion-flush\" id=\"accordionFlushChicks\">
    <div class=\"accordion-item\">
        <h2 class=\"accordion-header\" id=\"flush-headingTwo\">
            <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\"
                    data-bs-target=\"#flush-collapseTwo\" aria-expanded=\"false\" aria-controls=\"flush-collapseTwo\">
                ";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.modal.title.chicks", [], "messages");
        // line 7
        echo "            </button>
        </h2>
        <div id=\"flush-collapseTwo\" class=\"accordion-collapse collapse\" aria-labelledby=\"flush-headingTwo\"
             data-bs-parent=\"#accordionFlushChicks\">
            <div class=\"accordion-body\">
                <table class=\"table table-sm\">
                    <thead>
                    <tr>
                        <th>";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.farm", [], "messages");
        echo "</th>
                        <th>";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.chickNumber", [], "messages");
        echo "</th>
                        <th>";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.inputDate", [], "messages");
        echo "</th>
                        <th>";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.lightingDate", [], "messages");
        echo "</th>
                        <th>";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.transferDate", [], "messages");
        echo "</th>
                        <th>";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.selectionDate", [], "messages");
        echo "</th>
                        <th>";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.table.eggsForInput", [], "messages");
        echo "</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["dayPlans"] ?? null), "dayPlans", [], "any", false, false, false, 25));
        foreach ($context['_seq'] as $context["_key"] => $context["plans"]) {
            // line 26
            echo "                        <tr>
                            <td>";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plans"], "chickFarm", [], "any", false, false, false, 27), "name", [], "any", false, false, false, 27), "html", null, true);
            echo "</td>
                            <td>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "chickNumber", [], "any", false, false, false, 28), "html", null, true);
            echo "</td>
                            <td>";
            // line 29
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "inputDate", [], "any", false, false, false, 29), "Y-m-d"), "html", null, true);
            echo "</td>
                            <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "lightingDate", [], "any", false, false, false, 30), "Y-m-d"), "html", null, true);
            echo "</td>
                            <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "transferDate", [], "any", false, false, false, 31), "Y-m-d"), "html", null, true);
            echo "</td>
                            <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plans"], "deliveryDate", [], "any", false, false, false, 32), "Y-m-d"), "html", null, true);
            echo "</td>
                            ";
            // line 33
            $context["eggsNumber"] = (twig_get_attribute($this->env, $this->source, $context["plans"], "chickNumber", [], "any", false, false, false, 33) / (twig_get_attribute($this->env, $this->source, ($context["indicators"] ?? null), "hatchability", [], "any", false, false, false, 33) / 100));
            // line 34
            echo "                            <td>";
            echo twig_escape_filter($this->env, ($context["eggsNumber"] ?? null), "html", null, true);
            echo "</td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "plans/tables/chicks.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 37,  120 => 34,  118 => 33,  114 => 32,  110 => 31,  106 => 30,  102 => 29,  98 => 28,  94 => 27,  91 => 26,  87 => 25,  80 => 21,  76 => 20,  72 => 19,  68 => 18,  64 => 17,  60 => 16,  56 => 15,  46 => 7,  44 => 6,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/tables/chicks.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/tables/chicks.html.twig");
    }
}
