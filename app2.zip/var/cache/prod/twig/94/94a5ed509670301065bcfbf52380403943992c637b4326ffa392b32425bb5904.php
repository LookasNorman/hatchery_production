<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* security/login.html.twig */
class __TwigTemplate_bc119b109818e56bf3ddfe79d53c3e38c120fb869048f0d44616223c9c4b28d2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Log in!";
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "    <style>
        .card {
            max-width: 500px;
            min-width: 380px;
            padding: 6px 6px;
        }
    </style>
    <div class=\"d-flex justify-content-center card-group\">
    <form method=\"post\">
        <div class=\"card text-center\">
            <div class=\"card-header bg-success text-white\">
                ";
        // line 17
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 17)) {
            // line 18
            echo "                    <h1 class=\"h3 mb-3 font-weight-normal\">
                        ";
            // line 19
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.logged", [], "messages");
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 19), "username", [], "any", false, false, false, 19), "html", null, true);
            echo ",
                        <a class=\"btn btn-warning\" href=\"";
            // line 20
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">
                            ";
            // line 21
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.logout", [], "messages");
            // line 22
            echo "                        </a>
                    </h1>
                ";
        } else {
            // line 25
            echo "                    <h1 class=\"h3 mb-3 font-weight-normal\">
                        ";
            // line 26
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.header", [], "messages");
            // line 27
            echo "                    </h1>
                ";
        }
        // line 29
        echo "
            </div>
            <div class=\"card-body\">
                <div class=\"form-group\">
                    <label for=\"inputEmail\">
                        ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.email", [], "messages");
        // line 35
        echo "                    </label>
                    <input
                            type=\"email\"
                            class=\"form-control\"
                            value=\"";
        // line 39
        echo twig_escape_filter($this->env, ($context["last_username"] ?? null), "html", null, true);
        echo "\"
                            name=\"email\"
                            id=\"inputEmail\"
                            required
                            autofocus
                            aria-describedby=\"emailHelp\"
                            placeholder=\"";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.placeholder.email", [], "messages");
        echo "\"
                    >
                    <small id=\"emailHelp\" class=\"form-text text-muted\">
                        ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.help.email", [], "messages");
        // line 49
        echo "                    </small>
                </div>
                <div class=\"form-group\">
                    <label for=\"inputPassword\">
                        ";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.password", [], "messages");
        // line 54
        echo "                    </label>
                    <input
                            type=\"password\"
                            class=\"form-control\"
                            name=\"password\"
                            id=\"inputPassword\"
                            placeholder=\"";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.placeholder.password", [], "messages");
        echo "\"
                            required
                    >
                </div>
                <div class=\"form-group\">
                    <input type=\"hidden\" name=\"_csrf_token\"
                           value=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"
                    >
                </div>
                ";
        // line 70
        echo "                ";
        // line 71
        echo "
";
        // line 86
        echo "                <button class=\"btn btn-lg btn-primary\" type=\"submit\">
                    ";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.form.button.send", [], "messages");
        // line 88
        echo "                </button>
            </div>
            ";
        // line 90
        if (($context["error"] ?? null)) {
            // line 91
            echo "                <div class=\"card-footer text-muted alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, ($context["error"] ?? null), "messageKey", [], "any", false, false, false, 91), twig_get_attribute($this->env, $this->source, ($context["error"] ?? null), "messageData", [], "any", false, false, false, 91), "security"), "html", null, true);
            echo "</div>
            ";
        }
        // line 93
        echo "        </div>
    </form>
    </div>
";
    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 93,  181 => 91,  179 => 90,  175 => 88,  173 => 87,  170 => 86,  167 => 71,  165 => 70,  159 => 66,  150 => 60,  142 => 54,  140 => 53,  134 => 49,  132 => 48,  126 => 45,  117 => 39,  111 => 35,  109 => 34,  102 => 29,  98 => 27,  96 => 26,  93 => 25,  88 => 22,  86 => 21,  82 => 20,  76 => 19,  73 => 18,  71 => 17,  58 => 6,  54 => 5,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "security/login.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/security/login.html.twig");
    }
}
