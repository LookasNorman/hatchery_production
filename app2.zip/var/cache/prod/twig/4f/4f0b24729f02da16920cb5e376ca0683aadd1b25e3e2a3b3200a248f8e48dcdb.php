<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/index.html.twig */
class __TwigTemplate_2a0263a21c4d5b90f30829b9814772a3b138b09bdce764d7babfdcac03e2c541 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "plans/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <h1>";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.title", [], "messages");
        echo "</h1>

    <ul class=\"nav nav-tabs\" id=\"breedTab\" role=\"tablist\">
        ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["breedsPlans"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["breedPlans"]) {
            // line 8
            echo "            <li class=\"nav-item\" role=\"presentation\">
                ";
            // line 9
            if (twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 9)) {
                // line 10
                echo "                    <button class=\"nav-link active\" id=\"breed-tab_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" data-bs-toggle=\"tab\"
                            data-bs-target=\"#breed_";
                // line 11
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\"
                            type=\"button\"
                            role=\"tab\" aria-controls=\"breed_";
                // line 13
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" aria-selected=\"true\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["breedPlans"], "breed", [], "any", false, false, false, 13), "name", [], "any", false, false, false, 13), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["breedPlans"], "breed", [], "any", false, false, false, 13), "type", [], "any", false, false, false, 13), "html", null, true);
                echo "
                    </button>
                ";
            } else {
                // line 16
                echo "                    <button class=\"nav-link\" id=\"breed-tab_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" data-bs-toggle=\"tab\"
                            data-bs-target=\"#breed_";
                // line 17
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\"
                            type=\"button\"
                            role=\"tab\" aria-controls=\"breed_";
                // line 19
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" aria-selected=\"true\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["breedPlans"], "breed", [], "any", false, false, false, 19), "name", [], "any", false, false, false, 19), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["breedPlans"], "breed", [], "any", false, false, false, 19), "type", [], "any", false, false, false, 19), "html", null, true);
                echo "
                    </button>
                ";
            }
            // line 22
            echo "            </li>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['breedPlans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "    </ul>
    <div class=\"tab-content\" id=\"breedTabContent\">
        ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["breedsPlans"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["breedPlans"]) {
            // line 27
            echo "            ";
            if (twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 27)) {
                // line 28
                echo "                <div class=\"tab-pane fade show active\" id=\"breed_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" role=\"tabpanel\"
                     aria-labelledby=\"breed-tab_";
                // line 29
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\">
                    ";
                // line 30
                $this->loadTemplate("plans/breed.html.twig", "plans/index.html.twig", 30)->display($context);
                // line 31
                echo "                </div>
            ";
            } else {
                // line 33
                echo "                <div class=\"tab-pane fade show\" id=\"breed_";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\" role=\"tabpanel\"
                     aria-labelledby=\"breed-tab_";
                // line 34
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "\">
                    ";
                // line 35
                $this->loadTemplate("plans/breed.html.twig", "plans/index.html.twig", 35)->display($context);
                // line 36
                echo "                </div>
            ";
            }
            // line 38
            echo "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['breedPlans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "    </div>

";
    }

    public function getTemplateName()
    {
        return "plans/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  202 => 39,  188 => 38,  184 => 36,  182 => 35,  178 => 34,  173 => 33,  169 => 31,  167 => 30,  163 => 29,  158 => 28,  155 => 27,  138 => 26,  134 => 24,  119 => 22,  109 => 19,  104 => 17,  99 => 16,  89 => 13,  84 => 11,  79 => 10,  77 => 9,  74 => 8,  57 => 7,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/index.html.twig");
    }
}
