<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* chick_temperature/show.html.twig */
class __TwigTemplate_536bce3252c8a3fd653f85675e40b74cbc21144285df54d134687b00fc1f1495 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "chick_temperature/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "ChickTemperature";
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <h1>";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.show.title", [], "messages");
        echo "</h1>
        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 23
        $this->loadTemplate("layout/cards/chead.html.twig", "chick_temperature/show.html.twig", 23)->display($context);
        // line 24
        echo "            <h5 class=\"card-title\">";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["chick_temperature"] ?? null), "input", [], "any", false, false, false, 24), "name", [], "any", false, false, false, 24), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["chick_temperature"] ?? null), "hatcher", [], "any", false, false, false, 24), "name", [], "any", false, false, false, 24), "html", null, true);
        echo "</h5>
            ";
        // line 25
        $this->loadTemplate("layout/cards/cbody.html.twig", "chick_temperature/show.html.twig", 25)->display($context);
        // line 26
        echo "            <dl class=\"row\">
                <dd class=\"col-sm-6\">";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.show.date", [], "messages");
        echo "</dd>
                <dt class=\"col-sm-6\">";
        // line 28
        ((twig_get_attribute($this->env, $this->source, ($context["chick_temperature"] ?? null), "date", [], "any", false, false, false, 28)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["chick_temperature"] ?? null), "date", [], "any", false, false, false, 28), "Y-m-d"), "html", null, true))) : (print ("")));
        echo "</dt>
                <dd class=\"col-sm-6\">";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.show.temperature", [], "messages");
        echo "</dd>
                <dt class=\"col-sm-6\">";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["chick_temperature"] ?? null), "temperature", [], "any", false, false, false, 30), "html", null, true);
        echo "</dt>
            </dl>
            ";
        // line 32
        $this->loadTemplate("layout/cards/cfooter.html.twig", "chick_temperature/show.html.twig", 32)->display($context);
        // line 33
        echo "            ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 34
            echo "                ";
            echo twig_include($this->env, $context, "chick_temperature/_delete_form.html.twig");
            echo "
            ";
        }
        // line 36
        echo "            ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
            // line 37
            echo "                ";
            echo twig_include($this->env, $context, "layout/buttons/edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chick_temperature_edit", ["id" => twig_get_attribute($this->env, $this->source,             // line 38
($context["chick_temperature"] ?? null), "id", [], "any", false, false, false, 38)]), "text" => "chick_temperature.show.button.edit"]);
            echo "
            ";
        }
        // line 40
        echo "            ";
        $this->loadTemplate("layout/cards/cend.html.twig", "chick_temperature/show.html.twig", 40)->display($context);
        // line 41
        echo "        </div>
        ";
        // line 42
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chick_temperature_index"), "text" => "chick_temperature.show.button.back"]);
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "chick_temperature/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 42,  135 => 41,  132 => 40,  127 => 38,  125 => 37,  122 => 36,  116 => 34,  113 => 33,  111 => 32,  106 => 30,  102 => 29,  98 => 28,  94 => 27,  91 => 26,  89 => 25,  82 => 24,  80 => 23,  75 => 21,  58 => 6,  54 => 5,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "chick_temperature/show.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/chick_temperature/show.html.twig");
    }
}
