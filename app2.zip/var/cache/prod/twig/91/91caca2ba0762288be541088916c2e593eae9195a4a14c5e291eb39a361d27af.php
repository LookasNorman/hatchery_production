<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* transport_list/new.html.twig */
class __TwigTemplate_cf02aa78ca8db9932f6cf5ecb58893dc5bb6af82f329235c6888770c5e4532f4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "transport_list/new.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <h1>";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("transport_list.new.title", [], "messages");
        echo "</h1>
        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 21
        $this->loadTemplate("layout/cards/chead.html.twig", "transport_list/new.html.twig", 21)->display($context);
        // line 22
        echo "            <i class=\"fa fa-plus\"></i>
            ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("transport_list.new.header", [], "messages");
        // line 24
        echo "            ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "transport_list/new.html.twig", 24)->display($context);
        // line 25
        echo "            ";
        echo twig_include($this->env, $context, "transport_list/_form.html.twig");
        echo "
            ";
        // line 26
        $this->loadTemplate("layout/cards/cfooter.html.twig", "transport_list/new.html.twig", 26)->display($context);
        // line 27
        echo "            ";
        $this->loadTemplate("layout/cards/cend.html.twig", "transport_list/new.html.twig", 27)->display($context);
        // line 28
        echo "        </div>
        ";
        // line 29
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("transport_list_index"), "text" => "transport_list.new.button.back"]);
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "transport_list/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 29,  92 => 28,  89 => 27,  87 => 26,  82 => 25,  79 => 24,  77 => 23,  74 => 22,  72 => 21,  67 => 19,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "transport_list/new.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/transport_list/new.html.twig");
    }
}
