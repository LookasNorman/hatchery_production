<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plans/herd_index.html.twig */
class __TwigTemplate_94ae0763ca2c51401f5daed467d7cbd6e45db25e69cecf09c2b80490ee4b5521 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "plans/herd_index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <h1>";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.title", [], "messages");
        echo ": ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["herd"] ?? null), "name", [], "any", false, false, false, 4), "html", null, true);
        echo "</h1>
    <a href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("herd_delivery_plan_week_pdf", ["id" => twig_get_attribute($this->env, $this->source, ($context["herd"] ?? null), "id", [], "any", false, false, false, 5)]), "html", null, true);
        echo "\">pdf</a>
    <div class=\"row row-cols-1 row-cols-md-5 g-4\">
        ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["weeksPlans"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["weekPlans"]) {
            // line 8
            echo "            <div class=\"col\">
                <div class=\"card-header text-white bg-info\">
                    ";
            // line 10
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.week", [], "messages");
            echo ":
                    ";
            // line 11
            ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["weekPlans"], "weekPlans", [], "any", false, false, false, 11), "date", [], "any", false, false, false, 11)) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["weekPlans"], "weekPlans", [], "any", false, false, false, 11), "date", [], "any", false, false, false, 11), "medium", "medium", "w / r", null, "gregorian", "pl"), "html", null, true))) : (print ("")));
            echo "
                </div>
                <div class=\"card border-info\">
                    <div class=\"card-body\">
                        <dl class=\"row\">
                            <dt class=\"col-sm-6\">";
            // line 16
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plans.index.herd.eggs_delivery", [], "messages");
            echo "</dt>
                            <dd class=\"col-sm-6\">";
            // line 17
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["weekPlans"], "weekPlans", [], "any", false, false, false, 17), "eggs", [], "any", false, false, false, 17), 0, ",", " "), "html", null, true);
            echo "</dd>
                        </dl>
                    </div>
                </div>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['weekPlans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "plans/herd_index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 23,  86 => 17,  82 => 16,  74 => 11,  70 => 10,  66 => 8,  62 => 7,  57 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plans/herd_index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plans/herd_index.html.twig");
    }
}
