<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plan_input/index.html.twig */
class __TwigTemplate_c04335d499bdf895a8f4bea20aff06a80b36a5c8b3d804537b8fa2e498011610 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "plan_input/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

<div class=\"example-wrapper\">
    <h1>
        ";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.title", [], "messages");
        // line 21
        echo "    </h1>
    ";
        // line 22
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
            // line 23
            echo "        ";
            echo twig_include($this->env, $context, "layout/buttons/new.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_input_new"), "text" => "plan_input.index.button.new"]);
            echo "
    ";
        }
        // line 25
        echo "    ";
        $this->loadTemplate("layout/tables/thead.html.twig", "plan_input/index.html.twig", 25)->display($context);
        // line 26
        echo "    <tr>
        <th>";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.id", [], "messages");
        echo "</th>
        <th>";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.input", [], "messages");
        echo "</th>
        <th>";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.farm", [], "messages");
        echo "</th>
        <th>";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.chick_number", [], "messages");
        echo "</th>
        <th>";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.herd", [], "messages");
        echo "</th>
        <th>";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.egg_number", [], "messages");
        echo "</th>
        <th>";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.actions", [], "messages");
        echo "</th>
    </tr>
    ";
        // line 35
        $this->loadTemplate("layout/tables/tbody.html.twig", "plan_input/index.html.twig", 35)->display($context);
        // line 36
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["plan_inputs"] ?? null));
        $context['_iterated'] = false;
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["plan_input"]) {
            // line 37
            echo "        <tr>
            <td>";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plan_input"], "id", [], "any", false, false, false, 38), "html", null, true);
            echo "</td>
            <td>";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_input"], "input", [], "any", false, false, false, 39), "name", [], "any", false, false, false, 39), "html", null, true);
            echo "</td>
            <td>";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_input"], "farm", [], "any", false, false, false, 40), "customer", [], "any", false, false, false, 40), "name", [], "any", false, false, false, 40), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_input"], "farm", [], "any", false, false, false, 40), "name", [], "any", false, false, false, 40), "html", null, true);
            echo "</td>
            <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plan_input"], "chickNumber", [], "any", false, false, false, 41), "html", null, true);
            echo "</td>
            <td>";
            // line 42
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_input"], "herd", [], "any", false, false, false, 42), "breeder", [], "any", false, false, false, 42), "name", [], "any", false, false, false, 42), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["plan_input"], "herd", [], "any", false, false, false, 42), "name", [], "any", false, false, false, 42), "html", null, true);
            echo "</td>
            <td>";
            // line 43
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["plan_input"], "eggNumber", [], "any", false, false, false, 43), 0, ",", " "), "html", null, true);
            echo "</td>
            <td>
                ";
            // line 45
            echo twig_include($this->env, $context, "layout/buttons/list_show.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_input_show", ["id" => twig_get_attribute($this->env, $this->source,             // line 46
$context["plan_input"], "id", [], "any", false, false, false, 46)])]);
            echo "
                ";
            // line 47
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
                // line 48
                echo "                    ";
                echo twig_include($this->env, $context, "layout/buttons/list_edit.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("plan_input_edit", ["id" => twig_get_attribute($this->env, $this->source,                 // line 49
$context["plan_input"], "id", [], "any", false, false, false, 49)])]);
                echo "
                ";
            }
            // line 51
            echo "            </td>
        </tr>
    ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 54
            echo "        <tr>
            <td colspan=\"7\">";
            // line 55
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("plan_input.index.table.no_found", [], "messages");
            echo "</td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plan_input'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "    ";
        $this->loadTemplate("layout/tables/tfooter.html.twig", "plan_input/index.html.twig", 58)->display($context);
        // line 59
        echo "    ";
        $this->loadTemplate("layout/tables/tend.html.twig", "plan_input/index.html.twig", 59)->display($context);
        // line 60
        echo "
</div>
";
    }

    public function getTemplateName()
    {
        return "plan_input/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 60,  213 => 59,  210 => 58,  201 => 55,  198 => 54,  183 => 51,  178 => 49,  176 => 48,  174 => 47,  170 => 46,  169 => 45,  164 => 43,  158 => 42,  154 => 41,  148 => 40,  144 => 39,  140 => 38,  137 => 37,  118 => 36,  116 => 35,  111 => 33,  107 => 32,  103 => 31,  99 => 30,  95 => 29,  91 => 28,  87 => 27,  84 => 26,  81 => 25,  75 => 23,  73 => 22,  70 => 21,  68 => 20,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "plan_input/index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/plan_input/index.html.twig");
    }
}
