<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* main_page/recipient.html.twig */
class __TwigTemplate_b6b61585435d1cfdc5e3fae8b72cb26fb83aa8f3075c1f563d794cba8f7f0d75 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $this->displayBlock('body', $context, $blocks);
    }

    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "    <style>
        .card {
            max-width: 500px;
            min-width: 400px;
            padding: 6px 6px;
        }
    </style>
    <div class=\"card m-2 shadow p-3 mb-5 bg-body rounded\">
        <h4 class=\"card-header\">
            ";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("main_page.recipient.title", [], "messages");
        // line 12
        echo "        </h4>
        <div class=\"card-horizontal\">
            <div class=\"card-body\">
                <table class=\"table table-hover\">
                    <tbody>
                    <tr>
                        <th scope=\"row\">";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("main_page.recipient.body.recipient_number", [], "messages");
        echo "</th>
                        <td>";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["recipients"] ?? null), "recipientsNumber", [], "any", false, false, false, 19), "html", null, true);
        echo "</td>
                    </tr>
                    <tr>
                        <th scope=\"row\">";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("main_page.recipient.body.farm_number", [], "messages");
        echo "</th>
                        <td>";
        // line 23
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["farms"] ?? null), "farmNumber", [], "any", false, false, false, 23), "html", null, true);
        echo "</td>
                    </tr>
                    <tr>
                        <th scope=\"row\">";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("main_page.recipient.body.chicks_number", [], "messages");
        echo "</th>
                        <td>";
        // line 27
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["inputs"] ?? null), "chicks", [], "any", false, false, false, 27), 0, ",", " "), "html", null, true);
        echo "</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class=\"card-footer\">
            ";
        // line 34
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chicks_recipient_index"), "text" => "main_page.recipient.list"]);
        // line 35
        echo "
            ";
        // line 36
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
            // line 37
            echo "                ";
            echo twig_include($this->env, $context, "layout/buttons/create.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chicks_recipient_new"), "text" => "main_page.recipient.new"]);
            // line 38
            echo "
            ";
        }
        // line 40
        echo "        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "main_page/recipient.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  114 => 40,  110 => 38,  107 => 37,  105 => 36,  102 => 35,  100 => 34,  90 => 27,  86 => 26,  80 => 23,  76 => 22,  70 => 19,  66 => 18,  58 => 12,  56 => 11,  45 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "main_page/recipient.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/main_page/recipient.html.twig");
    }
}
