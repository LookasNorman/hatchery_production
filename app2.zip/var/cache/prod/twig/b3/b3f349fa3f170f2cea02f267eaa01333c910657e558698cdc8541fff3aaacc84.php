<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* egg_supplier/new.html.twig */
class __TwigTemplate_e5514b25dadbf4308394c6fcbad37502fc9eb2827400565c748f80d7b7231f90 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "egg_supplier/new.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">

        <div class=\"d-flex justify-content-center card-group\">
            ";
        // line 21
        $this->loadTemplate("layout/cards/chead.html.twig", "egg_supplier/new.html.twig", 21)->display($context);
        // line 22
        echo "            ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("egg_supplier.new.title", [], "messages");
        // line 23
        echo "            ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "egg_supplier/new.html.twig", 23)->display($context);
        // line 24
        echo "            ";
        echo twig_include($this->env, $context, "egg_supplier/_form.html.twig");
        echo "
            ";
        // line 25
        $this->loadTemplate("layout/cards/cfooter.html.twig", "egg_supplier/new.html.twig", 25)->display($context);
        // line 26
        echo "            ";
        $this->loadTemplate("layout/cards/cend.html.twig", "egg_supplier/new.html.twig", 26)->display($context);
        // line 27
        echo "        </div>
        ";
        // line 28
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("egg_supplier_index"), "text" => "egg_supplier.new.button.back"]);
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "egg_supplier/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 28,  87 => 27,  84 => 26,  82 => 25,  77 => 24,  74 => 23,  71 => 22,  69 => 21,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "egg_supplier/new.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/egg_supplier/new.html.twig");
    }
}
