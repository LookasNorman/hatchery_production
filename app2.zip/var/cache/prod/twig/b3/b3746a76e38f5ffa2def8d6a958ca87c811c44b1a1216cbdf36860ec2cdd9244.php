<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* eggs_delivery/edit.html.twig */
class __TwigTemplate_ac4fd528ae372c34f10d9828c545de5b7ee1debed8a263505572f9c95baa122d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "eggs_delivery/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"d-flex justify-content-center card-group\">
        ";
        // line 5
        $this->loadTemplate("layout/cards/chead.html.twig", "eggs_delivery/edit.html.twig", 5)->display($context);
        // line 6
        echo "        ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("eggs_delivery.edit.title", [], "messages");
        // line 7
        echo "        ";
        $this->loadTemplate("layout/cards/cbody.html.twig", "eggs_delivery/edit.html.twig", 7)->display($context);
        // line 8
        echo "        ";
        echo twig_include($this->env, $context, "eggs_delivery/_form.html.twig", ["button_label" => "eggs_delivery.edit.button.update"]);
        echo "
        ";
        // line 9
        $this->loadTemplate("layout/cards/cfooter.html.twig", "eggs_delivery/edit.html.twig", 9)->display($context);
        // line 10
        echo "        ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 11
            echo "            ";
            echo twig_include($this->env, $context, "eggs_delivery/_delete_form.html.twig");
            echo "
        ";
        }
        // line 13
        echo "        ";
        $this->loadTemplate("layout/cards/cend.html.twig", "eggs_delivery/edit.html.twig", 13)->display($context);
        // line 14
        echo "    </div>
    ";
        // line 15
        echo twig_include($this->env, $context, "layout/buttons/back.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("eggs_delivery_index"), "text" => "eggs_delivery.new.button.back"]);
        echo "

";
    }

    public function getTemplateName()
    {
        return "eggs_delivery/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 15,  80 => 14,  77 => 13,  71 => 11,  68 => 10,  66 => 9,  61 => 8,  58 => 7,  55 => 6,  53 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "eggs_delivery/edit.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/eggs_delivery/edit.html.twig");
    }
}
