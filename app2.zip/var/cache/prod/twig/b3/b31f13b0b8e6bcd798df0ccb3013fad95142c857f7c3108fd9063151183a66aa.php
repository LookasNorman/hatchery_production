<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* chick_temperature/index.html.twig */
class __TwigTemplate_3ba13cbf8f536103dd9586250c9117952338034b9554a6bc20f4014c92816866 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "chick_temperature/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <style>
        .example-wrapper {
            margin: 1em auto;
            max-width: 1920px;
            width: 95%;
            font: 18px/1.5 sans-serif;
        }

        .example-wrapper code {
            background: #F5F5F5;
            padding: 2px 6px;
        }
    </style>

    <div class=\"example-wrapper\">
        <h1>";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("chick_temperature.index.title", [], "messages");
        echo "</h1>
        ";
        // line 20
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_MANAGER")) {
            // line 21
            echo "            ";
            echo twig_include($this->env, $context, "layout/buttons/new.html.twig", ["pathLink" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("chick_temperature_new"), "text" => "chick_temperature.index.button.new"]);
            echo "
        ";
        }
        // line 23
        echo "        ";
        echo twig_include($this->env, $context, "chick_temperature/table_list.html.twig");
        echo "
    </div>
";
    }

    public function getTemplateName()
    {
        return "chick_temperature/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 23,  73 => 21,  71 => 20,  67 => 19,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "chick_temperature/index.html.twig", "/home/lookas/Workspace/GitHub/hatchery_production/templates/chick_temperature/index.html.twig");
    }
}
